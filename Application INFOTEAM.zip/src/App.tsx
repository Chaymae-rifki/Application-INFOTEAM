/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Lock, Check, Sparkles, BookOpen, Terminal, Code2, ShieldAlert, 
  HelpCircle, Archive, Landmark, Compass, Eye, Users, RefreshCcw, RefreshCw, LogOut, Plus, Trash2, CheckCircle2, Shield, Activity, FileJson,
  Camera, ChevronLeft, AlertTriangle, ShieldCheck, Award, Stamp, UserCheck, FileText, Image as ImageIcon
} from 'lucide-react';

import { PRESET_PAGES, getPresetPool } from './data';
import { PageScan, ActeType, UserAccount, WorkLog } from './types';

// Step components
import WorkflowPreparation from './components/WorkflowPreparation';
import IaEngineMorocco from './components/IaEngineMorocco';
import RegistryDoubleEntry from './components/RegistryDoubleEntry';
import RejectionSupervisor from './components/RejectionSupervisor';
import ControleSaisie from './components/ControleSaisie';
import ValidationLot from './components/ValidationLot';
import RescanCorrectWorkspace from './components/RescanCorrectWorkspace';

export default function App() {
  // Global accounts persistence state
  const [accounts, setAccounts] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('civil_accounts');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return [
      { id: "ACC-01", name: "Chaymae Rifki", email: "chaymae.rifki@usmba.ac.ma", username: "admin", role: "Administrateur", status: "Actif", dailyQuota: 0 },
      { id: "ACC-02", name: "Youssef El Marraki", email: "youssef@civil.gov.ma", username: "youssef", role: "AgentSaisie", status: "Actif", dailyQuota: 50 },
      { id: "ACC-03", name: "Fatima El Fassi", email: "fatima@civil.gov.ma", username: "fatima", role: "AgentSaisie", status: "Actif", dailyQuota: 50 }
    ];
  });

  // Global daily logs state
  const [logs, setLogs] = useState<WorkLog[]>(() => {
    const saved = localStorage.getItem('civil_work_logs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return [
      { id: "LOG-101", agentId: "ACC-02", agentName: "Youssef El Marraki", timestamp: "23/06/2026 09:30", action: "Validation Double Saisie - Fès", lotId: "FES-B12", count: 18, status: "Approuvé" },
      { id: "LOG-102", agentId: "ACC-03", agentName: "Fatima El Fassi", timestamp: "22/06/2026 15:45", action: "Chargement JSON État Civil", lotId: "21951001191102", count: 35, status: "En attente" }
    ];
  });

  // Session state
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('civil_current_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return null;
  });

  // Login Form States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('agent123'); // seed a default
  const [loginError, setLoginError] = useState<string | null>(null);

  // New Account states
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newRole, setNewRole] = useState<'Administrateur' | 'AgentSaisie'>('AgentSaisie');
  const [newQuota, setNewQuota] = useState(50);
  const [accountSuccess, setAccountSuccess] = useState(false);

  // Scanned pages state
  const [scannedPages, setScannedPages] = useState<PageScan[]>(() => {
    const savedCounter = localStorage.getItem('civil_reset_counter');
    const counter = savedCounter ? parseInt(savedCounter, 10) : 0;
    return getPresetPool(counter);
  });
  
  // Track reset count to load different preset lots on reset
  const [resetCounter, setResetCounter] = useState<number>(() => {
    const saved = localStorage.getItem('civil_reset_counter');
    return saved ? parseInt(saved, 10) : 0;
  });

  useEffect(() => {
    localStorage.setItem('civil_reset_counter', String(resetCounter));
  }, [resetCounter]);
  
  // Navigation for simpler Agent workspace
  // Tabs representing the active sub-category or step
  const [agentTab, setAgentTab] = useState<'scan' | 'rejets' | 'rescan_correct' | 'identification' | 'ia_injection' | 'double_entry' | 'controle_saisie' | 'validation_lot' | 'ocr' | 'postgres'>('scan');

  // Selected task path for Agent (null when choosing, or 8 sequential steps)
  const [selectedPart, setSelectedPart] = useState<'scan' | 'rejets' | 'rescan_correct' | 'identification' | 'ia_injection' | 'double_entry' | 'controle_saisie' | 'validation_lot' | null>(() => {
    const saved = localStorage.getItem('civil_agent_selected_part');
    if (saved && ['scan', 'rejets', 'rescan_correct', 'identification', 'ia_injection', 'double_entry', 'controle_saisie', 'validation_lot'].includes(saved)) {
      return saved as any;
    }
    return null;
  });

  // Track currently active page index for correction rescan
  const [selectedRescanPageIndex, setSelectedRescanPageIndex] = useState<number | null>(null);

  // Validation status states for step locking (8 Parts)
  const [isPart1Validated, setIsPart1Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part1_validated') === 'true';
  });
  const [isPart2Validated, setIsPart2Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part2_validated') === 'true';
  });
  const [isPart3Validated, setIsPart3Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part3_validated') === 'true';
  });
  const [isPart4Validated, setIsPart4Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part4_validated') === 'true';
  });
  const [isPart5Validated, setIsPart5Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part5_validated') === 'true';
  });
  const [isPart6Validated, setIsPart6Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part6_validated') === 'true';
  });
  const [isPart7Validated, setIsPart7Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part7_validated') === 'true';
  });
  const [isPart8Validated, setIsPart8Validated] = useState<boolean>(() => {
    return localStorage.getItem('is_part8_validated') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('is_part1_validated', String(isPart1Validated));
    localStorage.setItem('is_part2_validated', String(isPart2Validated));
    localStorage.setItem('is_part3_validated', String(isPart3Validated));
    localStorage.setItem('is_part4_validated', String(isPart4Validated));
    localStorage.setItem('is_part5_validated', String(isPart5Validated));
    localStorage.setItem('is_part6_validated', String(isPart6Validated));
    localStorage.setItem('is_part7_validated', String(isPart7Validated));
    localStorage.setItem('is_part8_validated', String(isPart8Validated));
  }, [isPart1Validated, isPart2Validated, isPart3Validated, isPart4Validated, isPart5Validated, isPart6Validated, isPart7Validated, isPart8Validated]);

  // Reactive return/redirect only when attempting to skip to Indexing/IA while unresolved anomalies are present
  useEffect(() => {
    const hasImageIssues = scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough || (p.wasRescanned && !p.isRescanApproved));
    if (hasImageIssues) {
      const advancedSteps = ['identification', 'ia_injection', 'double_entry', 'controle_saisie', 'validation_lot'];
      if (selectedPart && advancedSteps.includes(selectedPart)) {
        setSelectedPart('rescan_correct');
        setAgentTab('rescan_correct');
        alert("🚨 Des anomalies d'image (Image floue / Pliure Twya / Acte barré) subsistent sur ce lot. Vous avez été redirigé vers l'Atelier Correctif (Rescan & Correction) pour pouvoir les re-scanner et approuver leur qualité de manière réglementaire.");
      }
    }
  }, [scannedPages, selectedPart]);

  const triggerResetProgress = () => {
    const nextCounter = resetCounter + 1;
    setResetCounter(nextCounter);
    
    // Retrieve different lot based on nextCounter
    const newPool = getPresetPool(nextCounter);
    setScannedPages(JSON.parse(JSON.stringify(newPool)));
    
    // Reset all step validations
    setIsPart1Validated(false);
    setIsPart2Validated(false);
    setIsPart3Validated(false);
    setIsPart4Validated(false);
    setIsPart5Validated(false);
    setIsPart6Validated(false);
    setIsPart7Validated(false);
    setIsPart8Validated(false);
    
    // Return to first step
    setSelectedPart(null);
    setAgentTab('scan');

    // Human-friendly lot identifier for notification
    const lotName = nextCounter % 3 === 0 ? "Lot A (Fès & Marrakech d'Origine)" : 
                    nextCounter % 3 === 1 ? "Lot B (Fès Médina - Tome 15)" : 
                    "Lot C (Fès Médina - Tome 22)";

    alert(`🔄 Progression réinitialisée avec succès !\n\n🎯 Un tout NOUVEAU lot d'actes d'État Civil a été chargé :\n👉 ${lotName}\n\nVous pouvez recommencer le traitement de ces nouveaux actes.`);
  };

  // Track part validation success info
  const [completedPartInfo, setCompletedPartInfo] = useState<{
    partNum: number;
    title: string;
    details: string;
    icon: string;
  } | null>(null);

  // Navigation for Admin space
  // Views: 'dashboard' | 'accounts' | 'logs'
  const [adminView, setAdminView] = useState<'dashboard' | 'accounts' | 'logs'>('dashboard');

  // Time simulation clock
  const [timeStr, setTimeStr] = useState<string>("09:12:00");

  useEffect(() => {
    localStorage.setItem('civil_accounts', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem('civil_work_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('civil_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('civil_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    if (selectedPart) {
      localStorage.setItem('civil_agent_selected_part', selectedPart);
    } else {
      localStorage.removeItem('civil_agent_selected_part');
    }
  }, [selectedPart]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('fr-FR'));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const emailClean = loginEmail.trim().toLowerCase();
    
    // Validate email format
    if (!emailClean.includes('@')) {
      setLoginError("Format invalide. Veuillez saisir une adresse e-mail valide (e.g. votre@email.com) et non un simple identifiant ou nom.");
      return;
    }

    const user = accounts.find(acc => acc.email.toLowerCase() === emailClean);

    if (!user) {
      setLoginError("Email ou Nom d'utilisateur introuvable. Veuillez utiliser un raccourci ci-dessous pour tester.");
      return;
    }

    if (user.status === 'Suspendu') {
      setLoginError("Ce compte d'intervenant a été suspendu par l'administration.");
      return;
    }

    // Success Simulation
    setCurrentUser(user);
    setLoginError(null);
    setSelectedPart(null); // Force selection screen for Agent
    setAgentTab('ocr'); // default tab
    setAdminView('dashboard'); // default admin tab
  };

  const handleQuickLogin = (email: string) => {
    const user = accounts.find(acc => acc.email === email);
    if (user) {
      setCurrentUser(user);
      setLoginError(null);
      setSelectedPart(null); // Force selection screen for Agent
      setAgentTab('ocr');
      setAdminView('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setSelectedPart(null);
  };

  // Log action from agent
  const handleAgentLoggedAction = (count: number, actionName: string, lotId: string) => {
    if (!currentUser) return;

    const newLog: WorkLog = {
      id: "LOG-" + Date.now(),
      agentId: currentUser.id,
      agentName: currentUser.name,
      timestamp: new Date().toLocaleString('fr-FR'),
      action: actionName,
      lotId: lotId,
      count: count,
      status: 'En attente'
    };

    setLogs(prev => [newLog, ...prev]);
  };

  // Create new account admin action
  const handleCreateAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail || !newUsername) return;

    const newAcc: UserAccount = {
      id: "ACC-" + Date.now(),
      name: newName,
      email: newEmail,
      username: newUsername,
      role: newRole,
      status: 'Actif',
      dailyQuota: newRole === 'Administrateur' ? 0 : newQuota
    };

    setAccounts(prev => [...prev, newAcc]);
    setNewName('');
    setNewEmail('');
    setNewUsername('');
    setAccountSuccess(true);
    setTimeout(() => setAccountSuccess(false), 2000);
  };

  const handleDeleteAccount = (accId: string) => {
    if (accId === "ACC-01") return; // cannot delete superadmin
    setAccounts(prev => prev.filter(acc => acc.id !== accId));
  };

  const toggleAccountStatus = (accId: string) => {
    if (accId === "ACC-01") return;
    setAccounts(prev => prev.map(acc => {
      if (acc.id === accId) {
        return { ...acc, status: acc.status === 'Actif' ? 'Suspendu' : 'Actif' };
      }
      return acc;
    }));
  };

  const handleApproveLog = (logId: string) => {
    setLogs(prev => prev.map(lg => {
      if (lg.id === logId) {
        return { ...lg, status: 'Approuvé' };
      }
      return lg;
    }));
  };

  // Calculate stats for admin dashboard
  const totalActsProcessedVal = logs.reduce((acc, l) => acc + (l.status === 'Approuvé' ? l.count : 0), 0);
  const pendingValidationCount = logs.filter(l => l.status === 'En attente').length;

  return (
    <div className="min-h-screen bg-pastel-pink-light/30 text-stone-800 flex flex-col font-sans select-none">
      
      {/* Upper Brand bar */}
      <header className="bg-pastel-pink-light border-b border-pastel-pink px-6 py-4 sticky top-0 z-40 shadow-xs flex justify-between items-center backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-deep-pink rounded-xl flex items-center justify-center text-white shadow-clay-sm animate-heartbeat-pink shrink-0">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-[10px] bg-bubble-pink text-deep-pink font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full border border-pastel-pink">
              💖 INFOTEAM • DIVISION DE L'ÉTAT CIVIL
            </span>
            <h1 className="font-display font-black text-stone-900 text-lg tracking-tight leading-none mt-1">
              Portail National de Numérisation & d'Indexation de l'État Civil (INFOTEAM)
            </h1>
          </div>
        </div>

        {/* Dynamic header widgets */}
        <div className="flex items-center gap-3">
          <div className="bg-bubble-pink border border-pastel-pink px-4 py-1 rounded-xl text-center shadow-inner">
            <span className="block text-[8px] text-deep-pink font-bold uppercase">Heures National</span>
            <span className="font-mono text-xs font-bold text-stone-800 tracking-wider">{timeStr}</span>
          </div>

          {currentUser && (
            <div className="flex items-center gap-2 border-l border-pastel-pink pl-3">
              <div className="text-right">
                <span className="block text-xs font-bold text-stone-900 leading-none">{currentUser.name}</span>
                <span className="text-[9px] text-deep-pink uppercase font-black tracking-wider bg-bubble-pink border border-pastel-pink px-1.5 py-0.5 rounded mt-0.5 block max-w-fit ml-auto">
                  {currentUser.role === 'Administrateur' ? 'Administrateur 🌸' : 'Agent de Saisie 🎀'}
                </span>
              </div>
              <button 
                onClick={handleLogout}
                className="w-8 h-8 rounded-lg bg-white hover:bg-bubble-pink hover:text-deep-pink border border-pastel-pink flex items-center justify-center text-stone-500 transition-all cursor-pointer"
                title="Se Déconnecter"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Core Router View */}
      {!currentUser ? (
        
        /* -------------------------------------- */
        /* SPLIT SCREEN / NO-LOGIN ROOT PORTAL     */
        /* -------------------------------------- */
        <div className="flex-1 flex items-center justify-center p-6 bg-radial from-bubble-pink to-pastel-pink-light/30">
          <div className="w-full max-w-md bg-white border border-pastel-pink rounded-3xl p-8 shadow-clay-lg space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-pastel-pink-medium/40 rounded-full filter blur-xl opacity-35 -mr-6 -mt-6"></div>
            
            {/* Header logo */}
            <div className="text-center space-y-2 relative z-10">
              <div className="w-16 h-16 bg-deep-pink rounded-2xl mx-auto flex items-center justify-center text-white shadow-clay-md animate-heartbeat-pink">
                <Shield className="w-8 h-8" />
              </div>
              <p className="text-[10px] text-deep-pink font-extrabold tracking-widest uppercase">✨ SOCIÉTÉ INFOTEAM — ACCÈS SÉCURISÉ ✨</p>
              <h2 className="font-display font-black text-2xl text-stone-950">Accès Authentifié 🌸</h2>
              <p className="text-xs text-stone-500 font-medium">
                Connectez-vous pour accéder à la plateforme d'État Civil d'INFOTEAM.
              </p>
            </div>

            {/* Elegant Credentials Memo Card */}
            <div className="bg-bubble-pink border border-pastel-pink p-4 rounded-2xl space-y-2 relative z-10">
              <span className="text-[10px] uppercase font-bold tracking-wider text-deep-pink block">🗝️ Identifiants & Comptes de Test (E-mail obligatoire)</span>
              <div className="grid grid-cols-2 gap-3 text-[11px] font-sans">
                <div className="space-y-0.5 border-r border-pastel-pink-medium pr-1.5 font-sans">
                  <span className="font-bold text-stone-800 block">Administrateur</span>
                  <p className="text-stone-500 text-[10px] font-mono leading-tight">
                    E-mail: <span className="text-stone-900 font-bold block overflow-x-auto">chaymae.rifki@usmba.ac.ma</span>
                    Mot de passe: <span className="text-stone-900 font-bold block">agent123</span>
                  </p>
                </div>
                <div className="space-y-0.5 font-sans">
                  <span className="font-bold text-stone-800 block">Agent de Saisie</span>
                  <p className="text-stone-500 text-[10px] font-mono leading-tight">
                    E-mail: <span className="text-stone-900 font-bold block overflow-x-auto">youssef@civil.gov.ma</span>
                    Mot de passe: <span className="text-stone-900 font-bold block">agent123</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Login form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4 relative z-10">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Adresse E-mail
                </label>
                <input 
                  type="text" 
                  required
                  placeholder="votre@email.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full bg-pastel-pink-light/30 border border-pastel-pink rounded-xl px-4 py-2.5 text-xs text-stone-900 font-medium focus:outline-hidden focus:border-deep-pink transition-all font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Mot de passe de session
                </label>
                <input 
                  type="password" 
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-pastel-pink-light/30 border border-pastel-pink rounded-xl px-4 py-2.5 text-xs text-stone-900 focus:outline-hidden focus:border-deep-pink transition-all font-mono font-bold"
                />
              </div>

              {loginError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2 text-red-800 text-[10.5px] leading-relaxed">
                  <ShieldAlert className="w-4 h-4 text-red-700 shrink-0" />
                  <p>{loginError}</p>
                </div>
              )}

              <button 
                type="submit"
                className="w-full py-3 bg-deep-pink hover:bg-deep-pink/90 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-clay-sm cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" /> Se Connecter au Système
              </button>
            </form>

            {/* Practical Quick Selector (Teacher/QA Assist) */}
            <div className="border-t border-stone-150 pt-5 space-y-3">
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest block text-center">
                Comptes de test rapides (Simulation) :
              </span>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                
                {/* Admin Quick Login */}
                <button
                  type="button"
                  onClick={() => handleQuickLogin('chaymae.rifki@usmba.ac.ma')}
                  className="p-3 bg-red-50/50 hover:bg-red-50 border border-red-100 rounded-2xl text-left hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span className="font-bold text-red-900 block flex items-center gap-1">
                    <Shield className="w-3 h-3 text-red-700" /> Administrateur
                  </span>
                  <span className="text-red-700 text-[9px] block font-mono mt-0.5">Mlle. Chaymae</span>
                </button>

                {/* Operator Quick Login */}
                <button
                  type="button"
                  onClick={() => handleQuickLogin('youssef@civil.gov.ma')}
                  className="p-3 bg-green-50/50 hover:bg-green-50 border border-green-100 rounded-2xl text-left hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span className="font-bold text-green-900 block flex items-center gap-1">
                    <Users className="w-3 h-3 text-green-700" /> Agent de Saisie
                  </span>
                  <span className="text-green-700 text-[9px] block font-mono mt-0.5">Youssef (Youssef El Marraki)</span>
                </button>

              </div>
            </div>

          </div>
        </div>

      ) : currentUser.role === 'Administrateur' ? (
        
        /* -------------------------------------- */
        /* ADMINISTRATOR SPACE                     */
        /* -------------------------------------- */
        <div className="flex-1 flex flex-col lg:flex-row items-stretch select-none">
          
          {/* Admin Sidebar Navigation */}
          <aside className="w-full lg:w-[280px] bg-white border-r border-stone-200 p-6 flex flex-col justify-between space-y-8 h-full">
            <div className="space-y-6">
              <div className="pb-3 border-b border-stone-200">
                <span className="text-[10px] bg-red-50 text-red-800 font-bold px-2 py-0.5 rounded border border-red-100 uppercase font-mono mr-1.5 inline-block">SYSTEM</span>
                <h3 className="font-display font-black text-stone-900 text-xs uppercase tracking-wider inline-block">Supervision</h3>
              </div>

              {/* Navigation Menu */}
              <div className="space-y-2">
                
                {/* Admin Dashboard */}
                <button
                  onClick={() => setAdminView('dashboard')}
                  className={`w-full p-4 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                    adminView === 'dashboard' 
                      ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold' 
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <Activity className="w-4 h-4 text-rose-800" />
                  <div>
                    <h4 className="text-xs tracking-tight block">Tableau de Bord</h4>
                    <span className="text-[9px] opacity-70 block">Performance & Activités</span>
                  </div>
                </button>

                {/* Account Management */}
                <button
                  onClick={() => setAdminView('accounts')}
                  className={`w-full p-4 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                    adminView === 'accounts' 
                      ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold' 
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <Users className="w-4 h-4 text-rose-800" />
                  <div>
                    <h4 className="text-xs tracking-tight block">Gestion des Comptes</h4>
                    <span className="text-[9px] opacity-70 block">{accounts.length} opérateurs actifs</span>
                  </div>
                </button>

                {/* Daily Work Checker */}
                <button
                  onClick={() => setAdminView('logs')}
                  className={`w-full p-4 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                    adminView === 'logs' 
                      ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold' 
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <Eye className="w-4 h-4 text-rose-800" />
                  <div>
                    <h4 className="text-xs tracking-tight block">Contrôle Quotidien</h4>
                    <span className="text-[9px] opacity-70 block">
                      {pendingValidationCount > 0 ? `${pendingValidationCount} lots en attente` : "Tout est validé"}
                    </span>
                  </div>
                </button>

              </div>
            </div>

            {/* Quick reminder box */}
            <div className="bg-stone-50 border border-stone-200 p-4 rounded-2xl text-[10px] text-stone-500 leading-relaxed font-sans font-medium">
              <span className="block font-bold text-stone-800 mb-1">ℹ️ Rôle Administrateur</span>
              Vous gardez un oeil sur le travail national. Vous validez l'indexation, gérez les comptes, et certifiez les injecteurs.
            </div>
          </aside>

          {/* Admin Live Dashboard View */}
          <main className="flex-1 p-6 md:p-8 xl:p-10 max-w-7xl mx-auto w-full">
            
            {/* View: Dashboard */}
            {adminView === 'dashboard' && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display font-black text-2xl text-stone-900">Performance et Quotas Quotidiens</h2>
                  <p className="text-xs text-stone-500 mt-1">Surveillez l'activité des agents d'indexation civil en temps réel.</p>
                </div>

                {/* Big Info Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-white border border-stone-200 p-5 rounded-2xl flex items-center gap-4 shadow-2xs">
                    <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center text-green-700">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Actes Certifiés</span>
                      <span className="text-xl font-display font-black text-stone-900">{totalActsProcessedVal}</span>
                    </div>
                  </div>

                  <div className="bg-white border border-stone-200 p-5 rounded-2xl flex items-center gap-4 shadow-2xs">
                    <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-700">
                      <RefreshCcw className="w-5 h-5 animate-spin-slow" />
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Validation Requise</span>
                      <span className="text-xl font-display font-black text-stone-900">{pendingValidationCount} lots</span>
                    </div>
                  </div>

                  <div className="bg-white border border-stone-200 p-5 rounded-2xl flex items-center gap-4 shadow-2xs">
                    <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center text-red-700">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Agents Actifs</span>
                      <span className="text-xl font-display font-black text-stone-900">
                        {accounts.filter(a => a.role === 'AgentSaisie' && a.status === 'Actif').length}
                      </span>
                    </div>
                  </div>

                  <div className="bg-stone-900 text-stone-100 border border-stone-850 p-5 rounded-2xl flex items-center gap-4 shadow-md">
                    <div className="w-10 h-10 bg-rose-800 text-stone-100 rounded-xl flex items-center justify-center">
                      <Terminal className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Statut d'Injection</span>
                      <span className="text-xs font-mono font-bold text-green-400">PostgreSQL OPÉRATIONNEL</span>
                    </div>
                  </div>
                </div>

                {/* Quotas Progress visualizer */}
                <div className="bg-white border border-stone-200 p-6 rounded-3xl space-y-4 shadow-2xs">
                  <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wide">Suivi des Quotas d'Indexation Quotidiens</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {accounts.filter(acc => acc.role === 'AgentSaisie').map(acc => {
                      // Sum of approved or pending acts for this agent from log
                      const userInjected = logs
                        .filter(l => l.agentId === acc.id)
                        .reduce((accS, l) => accS + l.count, 0);

                      const percentage = Math.min(100, Math.round((userInjected / acc.dailyQuota) * 100)) || 0;

                      return (
                        <div key={acc.id} className="p-4 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                          <div className="flex justify-between items-center text-xs">
                            <div>
                              <span className="font-bold text-stone-900 block">{acc.name}</span>
                              <span className="text-[10px] font-mono text-stone-500">{acc.email}</span>
                            </div>
                            <span className="font-mono text-stone-700 font-bold">
                              {userInjected} / {acc.dailyQuota} actes ({percentage}%)
                            </span>
                          </div>

                          <div className="w-full bg-stone-200 h-3 rounded-full overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${
                                percentage >= 100 
                                  ? "bg-green-600" 
                                  : percentage >= 50 
                                    ? "bg-rose-800" 
                                    : "bg-amber-600"
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>

                          <div className="flex justify-between items-center text-[10px] text-stone-500">
                            <span>Quota Actuel : {acc.dailyQuota} / jour</span>
                            <span className="font-bold text-stone-700">
                              {acc.status === 'Actif' ? '🟢 En ligne (Actif)' : '🔴 Suspendu'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Historical logs preview */}
                <div className="bg-white border border-stone-200 rounded-3xl p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wide">Dernières Actions Intervenants</h3>
                    <button onClick={() => setAdminView('logs')} className="text-xs text-rose-800 font-extrabold hover:underline">
                      Voir tout
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-stone-700">
                      <thead>
                        <tr className="bg-stone-50 text-stone-500 font-mono text-[9px] uppercase border-b border-stone-200">
                          <th className="p-3">Opérateur</th>
                          <th className="p-3">Horaires</th>
                          <th className="p-3">Action</th>
                          <th className="p-3">Tome/Lot ID</th>
                          <th className="p-3">Volume</th>
                          <th className="p-3">Contrôle Admin</th>
                        </tr>
                      </thead>
                      <tbody>
                        {logs.slice(0, 4).map(lg => (
                          <tr key={lg.id} className="border-b border-stone-150 hover:bg-stone-50/50">
                            <td className="p-3 font-bold text-stone-900">{lg.agentName}</td>
                            <td className="p-3 text-stone-500 text-[10px] font-mono">{lg.timestamp}</td>
                            <td className="p-3 pr-4">
                              <span className="inline-block bg-stone-100 text-stone-800 text-[10px] font-semibold px-2 py-0.5 rounded border border-stone-200">
                                {lg.action}
                              </span>
                            </td>
                            <td className="p-3 font-mono text-[10px] text-stone-600">{lg.lotId || "N/A"}</td>
                            <td className="p-3 font-bold font-mono text-stone-900">{lg.count} actes</td>
                            <td className="p-3">
                              {lg.status === 'Approuvé' ? (
                                <span className="text-green-700 font-bold text-[10.5px] flex items-center gap-1">
                                  <Check className="w-3.5 h-3.5" /> Approuvé & Archivé
                                </span>
                              ) : (
                                <span className="text-amber-700 font-bold text-[10.5px] flex items-center gap-1 animate-pulse">
                                  ⚠️ Validation Requise
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* View: User Accounts Manager */}
            {adminView === 'accounts' && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display font-black text-2xl text-stone-900">Gestion des Comptes Intervenants</h2>
                  <p className="text-xs text-stone-500 mt-1">Créez, suspendez ou ajustez les quotas des agents de numérisation civile.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                  
                  {/* Account creation panel (1 col) */}
                  <div className="bg-white p-5 rounded-3xl border border-stone-200 space-y-4 shadow-2xs">
                    <h3 className="text-xs font-bold text-stone-900 uppercase tracking-widest pb-2 border-b border-stone-150 flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-rose-800" /> Nouvel Intervenant
                    </h3>

                    <form onSubmit={handleCreateAccountSubmit} className="space-y-3 text-xs">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-600 uppercase mb-1">Nom Complet</label>
                        <input 
                          type="text" 
                          required
                          value={newName}
                          onChange={(e) => setNewName(e.target.value)}
                          placeholder="e.g. Rachid El Idrissi"
                          className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-rose-800 font-medium"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-stone-600 uppercase mb-1">Email Officiel</label>
                        <input 
                          type="email" 
                          required
                          value={newEmail}
                          onChange={(e) => setNewEmail(e.target.value)}
                          placeholder="e.g. rachid@civil.gov.ma"
                          className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-rose-800 font-medium"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-stone-600 uppercase mb-1">Identifiant (Saisie)</label>
                        <input 
                          type="text" 
                          required
                          value={newUsername}
                          onChange={(e) => setNewUsername(e.target.value)}
                          placeholder="e.g. rachid_civil"
                          className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-rose-800 font-medium font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-stone-600 uppercase mb-1">Rôle et Droits</label>
                        <select
                          value={newRole}
                          onChange={(e) => setNewRole(e.target.value as any)}
                          className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 focus:outline-hidden focus:border-rose-800 font-bold"
                        >
                          <option value="AgentSaisie">Agent de Saisie (Opérateur local)</option>
                          <option value="Administrateur">Administrateur (Chef de service)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-stone-600 uppercase mb-1">Quota Journalier (Actes)</label>
                        <input 
                          type="number" 
                          value={newQuota}
                          onChange={(e) => setNewQuota(Number(e.target.value))}
                          className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-rose-800 font-bold font-mono"
                        />
                      </div>

                      {accountSuccess && (
                        <div className="p-2 bg-green-50 border border-green-150 rounded-lg text-green-800 text-[10px] text-center font-bold">
                          ✓ Compte d'indexation créé !
                        </div>
                      )}

                      <button 
                        type="submit"
                        className="w-full py-2 bg-stone-900 hover:bg-stone-950 text-white font-bold rounded-xl transition-all font-sans cursor-pointer"
                      >
                        Enregistrer l'Intervenant
                      </button>
                    </form>
                  </div>

                  {/* Users table listing (2 cols) */}
                  <div className="lg:col-span-2 bg-white p-5 rounded-3xl border border-stone-200 space-y-4 shadow-2xs">
                    <h3 className="text-xs font-bold text-stone-900 uppercase tracking-widest pb-2 border-b border-stone-150">
                      Régistre National des Identifiants Actifs
                    </h3>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="bg-stone-50 text-stone-500 font-mono text-[9px] uppercase border-b border-stone-200">
                            <th className="p-3">Nom / Identifiant</th>
                            <th className="p-3">Rôle</th>
                            <th className="p-3">Quota</th>
                            <th className="p-3">Statut</th>
                            <th className="p-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {accounts.map(acc => (
                            <tr key={acc.id} className="border-b border-stone-150 hover:bg-stone-50/50">
                              <td className="p-3">
                                <span className="font-bold text-stone-900 block">{acc.name}</span>
                                <span className="text-[10px] text-stone-500 font-mono">{acc.email}</span>
                              </td>
                              <td className="p-3">
                                <span className={`inline-block text-[9.5px] font-bold px-2 py-0.5 rounded-full ${
                                  acc.role === 'Administrateur' 
                                    ? 'bg-red-50 text-red-900 border border-red-100' 
                                    : 'bg-green-50 text-green-900 border border-green-100'
                                }`}>
                                  {acc.role === 'Administrateur' ? 'Administrateur' : 'Agent de Saisie'}
                                </span>
                              </td>
                              <td className="p-3 font-mono font-bold text-stone-750 text-xs">
                                {acc.role === 'Administrateur' ? '— (Non applicable)' : `${acc.dailyQuota} actes/j`}
                              </td>
                              <td className="p-3">
                                <button
                                  onClick={() => toggleAccountStatus(acc.id)}
                                  disabled={acc.id === "ACC-01"}
                                  className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border cursor-pointer ${
                                    acc.status === 'Actif'
                                      ? 'bg-green-50 text-green-800 border-green-150 hover:bg-green-100'
                                      : 'bg-red-50 text-red-800 border-red-150 hover:bg-red-100'
                                  }`}
                                  title={acc.id === "ACC-01" ? "Impossible d'opérer sur le superadmin" : "Modifier le statut"}
                                >
                                  {acc.status === 'Actif' ? '🟢 Actif' : '🔴 Suspendu'}
                                </button>
                              </td>
                              <td className="p-3 text-right">
                                <button 
                                  onClick={() => handleDeleteAccount(acc.id)}
                                  disabled={acc.id === "ACC-01"}
                                  className="w-8 h-8 rounded-lg bg-stone-50 hover:bg-red-50 hover:text-red-700 border border-stone-200 flex items-center justify-center text-stone-400 transition-all disabled:opacity-30 disabled:cursor-not-allowed inline-block cursor-pointer"
                                  title="Supprimer définitivement"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* View: Daily logs validator */}
            {adminView === 'logs' && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display font-black text-2xl text-stone-900">Validation Journalière des Enregistrements</h2>
                  <p className="text-xs text-stone-500 mt-1">
                    Examinez les lots de fichiers convertis par les agents et certifiez-les d'un clic pour verrouiller la base PostgreSQL d'État Civil.
                  </p>
                </div>

                <div className="bg-white border border-stone-200 rounded-3xl p-6 space-y-4 shadow-2xs">
                  <div className="flex justify-between items-center pb-2 border-b border-stone-150">
                    <span className="text-xs font-bold text-stone-700 uppercase tracking-widest flex items-center gap-1.5">
                      <Archive className="w-4 h-4 text-rose-800" /> Flux de Livraison en attente de vérification ({pendingValidationCount})
                    </span>
                    <span className="text-[10px] font-mono bg-stone-100 px-2 py-1 rounded text-stone-600 font-bold">
                      Format d'échange : JSON v2
                    </span>
                  </div>

                  {logs.length === 0 ? (
                    <div className="py-12 text-center text-stone-400 font-sans text-xs">
                      Aucune action ou lot n'a été enregistré pour le moment.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {logs.map(lg => {
                        const isApproved = lg.status === 'Approuvé';
                        return (
                          <div 
                            key={lg.id} 
                            className={`p-5 rounded-2xl border transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
                              isApproved 
                                ? "bg-stone-50 border-stone-200" 
                                : "bg-amber-50/60 border-amber-200"
                            }`}
                          >
                            <div className="space-y-2">
                              {/* Agent info & timestamp */}
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-extrabold text-stone-900 text-xs">{lg.agentName}</span>
                                <span className="text-[10px] text-stone-500 font-mono">| {lg.timestamp}</span>
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                  isApproved 
                                    ? "bg-green-100 text-green-800" 
                                    : "bg-amber-100 text-amber-800"
                                }`}>
                                  {lg.status}
                                </span>
                              </div>

                              <div className="flex items-center gap-4 text-xs font-mono">
                                <div>
                                  <span className="text-stone-400 text-[10px] block uppercase font-bold font-sans">Opération</span>
                                  <span className="text-stone-800 font-bold">{lg.action}</span>
                                </div>
                                <div>
                                  <span className="text-stone-400 text-[10px] block uppercase font-bold font-sans">Tome / Lot ID TARGET</span>
                                  <span className="text-rose-800 font-bold">{lg.lotId || "N/A"}</span>
                                </div>
                                <div>
                                  <span className="text-stone-400 text-[10px] block uppercase font-bold font-sans">Compte d'Actes</span>
                                  <span className="text-stone-900 font-black">{lg.count} actes d'Etat Civil</span>
                                </div>
                              </div>
                            </div>

                            {/* Approval actions */}
                            <div className="shrink-0 flex items-center gap-2 w-full md:w-auto">
                              {!isApproved ? (
                                <button
                                  onClick={() => handleApproveLog(lg.id)}
                                  className="w-full md:w-auto py-2 px-4 bg-stone-900 hover:bg-stone-950 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> Certifier l'opération
                                </button>
                              ) : (
                                <div className="text-green-700 font-bold text-xs flex items-center gap-1.5 bg-green-50 px-3 py-1.5 rounded-xl border border-green-100">
                                  <Check className="w-4 h-4" /> Certifié conforme par Mlle. Chaymae
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

          </main>

        </div>

      ) : selectedPart === null ? (
        
        /* -------------------------------------- */
        /* PORTAL SELECTION OF PART / TASK SELECT */
        /* -------------------------------------- */
        <div className="flex-1 bg-stone-55 select-none flex items-center justify-center py-10 px-4 md:px-10 lg:px-12">
          <div className="w-full max-w-5xl space-y-8">
            <div className="text-center space-y-2 max-w-2xl mx-auto">
              <span className="text-[10px] bg-rose-50 text-rose-800 font-bold px-3 py-1 rounded-full border border-rose-100 uppercase tracking-widest font-mono">
                Opérateur Actif • {currentUser.name} ({currentUser.role})
              </span>
              <h2 className="font-display font-black text-3xl text-stone-900 tracking-tight mt-2">
                Sélection de l'Espace de Travail d'État Civil
              </h2>
              <p className="text-xs text-stone-500 leading-relaxed">
                Veuillez sélectionner la partie ou la tâche que vous souhaitez effectuer pour démarrer votre travail quotidien d'indexation nationale.
              </p>
            </div>

            {completedPartInfo && (
              <div className="bg-green-50/90 backdrop-blur-xs border-2 border-green-300 p-6 rounded-3xl space-y-3 relative overflow-hidden shadow-md animate-fade-in pr-12">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-green-100/80 rounded-2xl flex items-center justify-center text-2xl shrink-0 select-none">
                    {completedPartInfo.icon}
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display font-black text-green-950 text-xs md:text-sm leading-snug">
                      {completedPartInfo.title}
                    </h3>
                    <p className="text-xs text-green-800 leading-relaxed font-sans font-medium">
                      {completedPartInfo.details}
                    </p>
                    <div className="pt-2 flex items-center gap-2">
                      <span className="text-[9px] bg-green-200/50 text-green-900 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-tight">Validation Réussie</span>
                      <span className="text-[9px] font-mono font-bold text-green-700">Séance clôturée conjointe</span>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setCompletedPartInfo(null)}
                  className="absolute top-4 right-4 w-7 h-7 rounded-xl border border-green-200 bg-white hover:bg-green-100 text-green-800 text-xs font-bold flex items-center justify-center cursor-pointer transition-colors"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Reset progression button */}
            <div className="flex justify-end pr-1">
              <button
                type="button"
                onClick={triggerResetProgress}
                className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 border border-stone-250 text-stone-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-stone-500" /> Réinitialiser la Progression (Testeur)
              </button>
            </div>

            {/* Core Parts Grid: 9 Clean Columns corresponding to the 9 Steps of Mlle Chaymae's updated workflow */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 font-sans">
              
              {/* Part 1: Saisie & Image Capture (Scan) */}
              <button
                type="button"
                onClick={() => {
                  setSelectedPart('scan');
                  setAgentTab('scan');
                }}
                className="group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs bg-white border-stone-200 hover:border-rose-400 hover:shadow-lg cursor-pointer"
              >
                <div className="space-y-2">
                  <div className="w-9 h-9 bg-rose-50 rounded-xl flex items-center justify-center text-rose-800 group-hover:bg-rose-800 group-hover:text-white transition-all duration-300">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900">
                        1. Capture & Scan
                      </h4>
                      <span className="text-[8px] bg-green-50 text-green-700 font-bold px-1.5 py-0.5 rounded-full border border-green-100 uppercase tracking-tight">P1</span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      التحضير والمسح الضوئي
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal">
                    Ajustez la numérisation zénithale, importez via caméra et contrôlez la binarisation de l'image de l'album d'actes.
                  </p>
                </div>
                <div className="w-full py-1.5 bg-stone-50 group-hover:bg-rose-900 group-hover:text-white rounded-xl text-center text-xs font-bold text-stone-850 border border-stone-150 transition-all duration-300 font-mono">
                  {isPart1Validated ? "Complété ✔" : "Scanner →"}
                </div>
              </button>

              {/* Part 2: Rescanner & Valider */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart1Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 1 (Capture & Scan) avant d'effectuer le rescan correctif.");
                    return;
                  }
                  setSelectedPart('rescan_correct');
                  setAgentTab('rescan_correct');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart1Validated
                    ? "bg-white border-stone-200 hover:border-emerald-500 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart1Validated ? "bg-emerald-50 text-emerald-800 group-hover:bg-emerald-800 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <RefreshCw className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        2. Rescanner & Valider
                      </h4>
                      <span className="text-[8px] bg-emerald-55 text-emerald-800 font-bold px-1.5 py-0.5 rounded-full border border-emerald-100 uppercase tracking-tight">
                        {isPart1Validated ? "P2" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      إعادة المسح والتحقق
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Atelier de re-scan correctif des actes signalés flous, pliés ou barrés. Remplacez l'image et certifiez conformes.
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart1Validated 
                    ? "bg-stone-50 group-hover:bg-emerald-800 group-hover:text-white border-emerald-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart3Validated ? "Complété ✔" : "Rescanner & Valider →"}
                </div>
              </button>

              {/* Part 3: Identification */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart3Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 2 (Rescanner & Valider) sans anomalie résiduelle.");
                    return;
                  }
                  setSelectedPart('identification');
                  setAgentTab('identification');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart3Validated
                    ? "bg-white border-stone-200 hover:border-cyan-400 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart3Validated ? "bg-cyan-50 text-cyan-850 group-hover:bg-cyan-800 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        3. Identification
                      </h4>
                      <span className="text-[8px] bg-cyan-50 text-cyan-700 font-bold px-1.5 py-0.5 rounded-full border border-cyan-100 uppercase tracking-tight">
                        {isPart3Validated ? "P3" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      تعريف السجلات والوثائق
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Identifiez et indexez réglementairement les registres de l'État Civil (RC) et les pièces d'appui d'actes (RP).
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart3Validated 
                    ? "bg-stone-50 group-hover:bg-cyan-800 group-hover:text-white border-stone-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart4Validated ? "Complété ✔" : "Identifier →"}
                </div>
              </button>

              {/* Part 4: Moteur IA & SQL */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart4Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 3 (Identification).");
                    return;
                  }
                  setSelectedPart('ia_injection');
                  setAgentTab('ocr');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart4Validated
                    ? "bg-white border-stone-200 hover:border-purple-400 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart4Validated ? "bg-purple-50 text-purple-700 group-hover:bg-purple-700 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        4. Moteur d'IA & SQL
                      </h4>
                      <span className="text-[8px] bg-purple-50 text-purple-700 font-bold px-1.5 py-0.5 rounded-full border border-purple-100 uppercase tracking-tight">
                        {isPart4Validated ? "P4" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      محرك الذكاء وحقن SQL
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Transcrivez via l'Arab OCR, traduisez et injectez automatiquement les requêtes SQL dans la base relationnelle PostgreSQL.
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart4Validated 
                    ? "bg-stone-50 group-hover:bg-purple-700 group-hover:text-white border-stone-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart5Validated ? "Complété ✔" : "Lancer l'IA →"}
                </div>
              </button>

              {/* Part 5: Double Saisie */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart5Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 4 (Moteur d'IA & Injection SQL bulk).");
                    return;
                  }
                  setSelectedPart('double_entry');
                  setAgentTab('double_entry');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart5Validated
                    ? "bg-white border-stone-200 hover:border-blue-500 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart5Validated ? "bg-blue-50 text-blue-800 group-hover:bg-blue-800 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        5. Double Saisie
                      </h4>
                      <span className="text-[8px] bg-blue-50 text-blue-700 font-bold px-1.5 py-0.5 rounded-full border border-blue-100 uppercase tracking-tight">
                        {isPart5Validated ? "P5" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      المطابقة ومراقبة جودة المدخلات
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Arbitrez les conflits orthographiques Saisie A vs Saisie B, validez la concordance d'actes et certifiez l'index légal.
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart5Validated 
                    ? "bg-stone-50 group-hover:bg-blue-800 group-hover:text-white border-stone-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart6Validated ? "Complété ✔" : "Vérifier Concordance →"}
                </div>
              </button>

              {/* Part 6: Contrôle Saisie */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart6Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 5 (Double Saisie & Arbitrage).");
                    return;
                  }
                  setSelectedPart('controle_saisie');
                  setAgentTab('controle_saisie');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart6Validated
                    ? "bg-white border-stone-200 hover:border-emerald-500 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart6Validated ? "bg-emerald-50 text-emerald-800 group-hover:bg-emerald-800 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        6. Contrôle Saisie
                      </h4>
                      <span className="text-[8px] bg-emerald-55 text-emerald-800 font-bold px-1.5 py-0.5 rounded-full border border-emerald-100 uppercase tracking-tight">
                        {isPart6Validated ? "P6" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      مراقبة ومصادقة البيانات
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Audit qualitatif final des transcrits réglementaires de l'État Civil et contrôle de conformité des images d'appui.
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart6Validated 
                    ? "bg-stone-50 group-hover:bg-emerald-800 group-hover:text-white border-emerald-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart7Validated ? "Complété ✔" : "Vérifier Saisie →"}
                </div>
              </button>

              {/* Part 7: Sceau & Clôture */}
              <button
                type="button"
                onClick={() => {
                  if (!isPart7Validated) {
                    alert("🚫 Accès Bloqué : Veuillez d'abord valider l'Étape 6 (Contrôle Saisie qualitative final).");
                    return;
                  }
                  setSelectedPart('validation_lot');
                  setAgentTab('validation_lot');
                }}
                className={`group p-4 rounded-3xl border text-left transition-all duration-300 flex flex-col justify-between space-y-3 shadow-xs ${
                  isPart7Validated
                    ? "bg-white border-stone-200 hover:border-rose-700 hover:shadow-lg cursor-pointer" 
                    : "bg-stone-50 border-stone-150 opacity-60 cursor-not-allowed"
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isPart7Validated ? "bg-rose-50 text-rose-800 group-hover:bg-rose-800 group-hover:text-white" : "bg-stone-200 text-stone-400"
                  }`}>
                    <Stamp className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-black text-xs text-stone-900 font-bold">
                        7. Sceau & Clôture
                      </h4>
                      <span className="text-[8px] bg-rose-55 text-rose-800 font-bold px-1.5 py-0.5 rounded-full border border-rose-100 uppercase tracking-tight">
                        {isPart7Validated ? "P7" : "Bloqué 🔒"}
                      </span>
                    </div>
                    <span className="font-bold text-stone-400 text-[8px] uppercase font-mono block tracking-wider mt-0.5">
                      الاعتماد القانوني للملف
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-normal font-sans font-medium">
                    Apposez le Sceau Officiel de l'État Civil pour sceller définitivement le lot, verrouiller les registres et exporter l'archive légale.
                  </p>
                </div>
                <div className={`w-full py-1.5 rounded-xl text-center text-xs font-bold font-mono transition-all duration-300 border ${
                  isPart7Validated 
                    ? "bg-stone-50 group-hover:bg-rose-800 group-hover:text-white border-rose-150 text-stone-850" 
                    : "bg-stone-100 border-stone-200 text-stone-400"
                }`}>
                  {isPart8Validated ? "Complété ✔" : "Valider le Lot →"}
                </div>
              </button>

            </div>
          </div>
        </div>

      ) : (
        <div className="flex-1 flex flex-col lg:flex-row items-stretch select-none">
          {/* Streamlined Agent Sidebar */}
          <aside className="w-full lg:w-[325px] bg-white border-r border-stone-200 p-6 flex flex-col justify-between space-y-8 select-none font-sans">
            
            <div className="space-y-6">
              
              {/* Back to task selector button */}
              <button
                type="button"
                onClick={() => setSelectedPart(null)}
                className="w-full py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-stone-850 hover:text-stone-900 text-xs font-bold rounded-2xl border border-stone-250 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs font-sans mb-1"
              >
                <ChevronLeft className="w-4 h-4 text-stone-600 shrink-0" />
                Retour au Tableau de Choix
              </button>

              {/* Agent info and daily limit progress */}
              <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl relative overflow-hidden">
                <span className="text-[9px] bg-rose-200 text-rose-800 font-bold uppercase px-2 py-0.5 rounded-md block max-w-fit mb-2">
                  Session Agent Actif
                </span>
                <h4 className="font-display font-black text-stone-950 text-sm leading-tight">
                  {currentUser?.name}
                </h4>
                <p className="text-[10px] text-stone-500 font-mono mt-0.5">{currentUser?.email}</p>
 
                {/* Simulated session progress bar */}
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-[9px] font-bold text-rose-900">
                    <span>Performance d'Aujourd'hui :</span>
                    <span className="font-mono">35 / 50 Actes</span>
                  </div>
                  <div className="w-full bg-rose-200/50 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-rose-800 h-full rounded-full" style={{ width: "70%" }} />
                  </div>
                </div>
              </div>
 
              <div className="space-y-2">
                <h3 className="font-display font-black text-stone-900 text-[11px] uppercase tracking-wider pb-2 border-b border-stone-200 mb-1">
                  {selectedPart === 'scan' && "Menu Partie 1 : Capture & Scan"}
                  {selectedPart === 'rescan_correct' && "Menu Partie 2 : Rescan & Correction"}
                  {selectedPart === 'identification' && "Menu Partie 3 : Identification"}
                  {selectedPart === 'ia_injection' && "Menu Partie 4 : Moteur IA"}
                  {selectedPart === 'double_entry' && "Menu Partie 5 : Double Saisie"}
                  {selectedPart === 'controle_saisie' && "Menu Partie 6 : Contrôle Saisie"}
                  {selectedPart === 'validation_lot' && "Menu Partie 7 : Sceau & Clôture"}
                </h3>

                {/* Sub-tabs list corresponding strictly to active selectedPart */}
                {selectedPart === 'scan' && (
                  <div className="space-y-2">
                    {/* Sub-tab 1.1: Capture & Contrôle */}
                    <button
                      type="button"
                      onClick={() => setAgentTab('scan')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'scan' 
                          ? "bg-rose-50 border-rose-400 text-rose-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          agentTab === 'scan' ? "bg-rose-800 text-white" : "bg-stone-100 text-stone-500"
                        }`}>
                          1.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Capture & Numérisation</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Caméra Zénithale & Binarisation</span>
                        </div>
                      </div>
                      <Check className="w-4 h-4 text-rose-700 bg-rose-100/50 p-0.5 border border-rose-200 rounded-full shrink-0" />
                    </button>
                  </div>
                )}

                {selectedPart === 'rescan_correct' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => setAgentTab('rescan_correct')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'rescan_correct' 
                          ? "bg-emerald-50 border-emerald-400 text-emerald-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-emerald-800 text-white font-bold text-xs shrink-0">
                          2.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Atelier Correctif (Cam)</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Remplacer & lever les rejets</span>
                        </div>
                      </div>
                      <Check className="w-4 h-4 text-emerald-700 bg-emerald-100/50 p-0.5 border border-emerald-200 rounded-full shrink-0" />
                    </button>
                  </div>
                )}

                {selectedPart === 'identification' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => setAgentTab('identification')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'identification' 
                          ? "bg-rose-50 border-rose-400 text-rose-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-rose-800 text-white font-bold text-xs shrink-0">
                          3.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Identification RC & RP</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Indexation des Registres d'actes</span>
                        </div>
                      </div>
                      <Check className="w-4 h-4 text-rose-700 bg-rose-100/50 p-0.5 border border-rose-200 rounded-full shrink-0" />
                    </button>
                  </div>
                )}

                {selectedPart === 'ia_injection' && (
                  <div className="space-y-2 font-sans font-medium">
                    <div className="p-4 rounded-2xl border border-rose-400 bg-rose-50/60 text-stone-900 shadow-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-rose-800 text-white font-bold text-xs shrink-0">
                          4
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold text-stone-900">Injection SQL Directe</h4>
                          <span className="text-[9.5px] font-sans text-stone-600 font-medium block">Fichiers d'Échange JSON</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {selectedPart === 'double_entry' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => setAgentTab('double_entry')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'double_entry' 
                          ? "bg-rose-50 border-rose-400 text-rose-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          agentTab === 'double_entry' ? "bg-rose-800 text-white" : "bg-stone-100 text-stone-500"
                        }`}>
                          5.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Arbitrage Double Saisie</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Conflits Saisie A & B</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-0.5 px-1.5 py-0.5 bg-blue-50 border border-blue-150 rounded-full text-blue-800 text-[8px] font-bold shrink-0">
                        Certif
                      </div>
                    </button>
                  </div>
                )}

                {selectedPart === 'controle_saisie' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => setAgentTab('controle_saisie')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'controle_saisie' 
                          ? "bg-rose-50 border-rose-400 text-rose-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          agentTab === 'controle_saisie' ? "bg-emerald-800 text-white" : "bg-stone-100 text-stone-500"
                        }`}>
                          6.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Audit de Conformité</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Grille de contrôle finale</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 px-1.5 py-0.5 bg-emerald-50 border border-emerald-150 rounded-full text-emerald-800 text-[8px] font-bold shrink-0">
                        Audit
                      </div>
                    </button>
                  </div>
                )}

                {selectedPart === 'validation_lot' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => setAgentTab('validation_lot')}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        agentTab === 'validation_lot' 
                          ? "bg-rose-50 border-rose-400 text-rose-900 font-bold shadow-xs" 
                          : "bg-white border-stone-200 text-stone-700 hover:bg-stone-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          agentTab === 'validation_lot' ? "bg-rose-800 text-white" : "bg-stone-100 text-stone-500"
                        }`}>
                          7.1
                        </div>
                        <div>
                          <h4 className="text-xs tracking-tight block font-bold">Sceau & Clôture finale</h4>
                          <span className="text-[9.5px] font-sans opacity-70 block">Certifier et sceller le lot</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 px-1.5 py-0.5 bg-rose-50 border border-rose-150 rounded-full text-rose-800 text-[8px] font-bold shrink-0">
                        Sceau
                      </div>
                    </button>
                  </div>
                )}

              </div>
            </div>

            {/* Core Validation action & status footer */}
            <div className="pt-4 border-t border-stone-200 space-y-3">
              
              {/* Premium validation and completion button with safety validations */}
              {(() => {
                const hasImageQualityIssues = scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough || (p.wasRescanned && !p.isRescanApproved));
                const isScanBlocked = selectedPart === 'scan' && scannedPages.length === 0;
                
                const hasUnresolvedConflicts = scannedPages.some(p => !p.isConflictResolved);
                const hasIdentifierConflicts = scannedPages.some(p => 
                   !p.isConflictResolved && (p.operatorA.numActe !== p.operatorB.numActe || p.operatorA.typeActe !== p.operatorB.typeActe)
                );
                const isRejetsBlocked = selectedPart === 'rejets' && (hasUnresolvedConflicts || hasIdentifierConflicts);
                const isRescanBlocked = selectedPart === 'rescan_correct' && hasImageQualityIssues;
                
                const isButtonDisabled = isScanBlocked || isRejetsBlocked || isRescanBlocked;
                
                return (
                  <button
                    type="button"
                    disabled={isButtonDisabled}
                    onClick={() => {
                      if (selectedPart === 'scan') {
                        if (scannedPages.length === 0) {
                          alert("🚨 Impossible de valider : Vous n'avez scanné aucun acte.");
                          return;
                        }
                        setIsPart1Validated(true);
                        setIsPart2Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 1 - Capture & Scan", "LOT1-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 1,
                          title: "Partie 1 (Capture & Scan) Validée avec Succès 🎉",
                          details: `La séance de capture, redressage et binarisation de ${scannedPages.length} pages de listes d'État Civil a été approuvée. La Partie 1 is clôturée.`,
                          icon: "📸"
                        });
                        setSelectedPart('rescan_correct');
                        setAgentTab('rescan_correct');
                      } else if (selectedPart === 'rescan_correct') {
                        if (hasImageQualityIssues) {
                          alert("🚨 Impossible de valider : Il reste des actes défectueux à re-scanner ou en attente d'approbation au contrôle d'image.");
                          return;
                        }
                        setIsPart3Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 3 - Rescan & Correction", "LOT3-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 3,
                          title: "Partie 3 (Rescan & Correction) Validée avec Succès 📷",
                          details: "Tous les actes défectueux ont été ré-capturés, corrigés et approuvés conformes.",
                          icon: "📷"
                        });
                        setSelectedPart('identification');
                        setAgentTab('identification');
                      } else if (selectedPart === 'identification') {
                        setIsPart4Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 4 - Identification d'Actes", "LOT4-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 4,
                          title: "Partie 4 (Identification) Validée avec Succès 🏛️",
                          details: "L'identification du type de registre et indexation réglementaire est complète.",
                          icon: "🏛️"
                        });
                        setSelectedPart('ia_injection');
                        setAgentTab('ocr');
                      } else if (selectedPart === 'ia_injection') {
                        setIsPart5Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 5 - Moteur IA & Injection Postgres", "LOT5-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 5,
                          title: "Partie 5 (Moteur IA & SQL) Validée avec Succès 🧠",
                          details: "La transcription neuronale et l'injection bulk SQL dans les bases ont été finalisées et validées avec succès.",
                          icon: "🚀"
                        });
                        setSelectedPart('double_entry');
                        setAgentTab('double_entry');
                      } else if (selectedPart === 'double_entry') {
                        setIsPart6Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 6 - Arbitrage & Concordance", "LOT6-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 6,
                          title: "Partie 6 (Double Saisie) Validée avec Succès 🏛️",
                          details: "L'arbitrage ultime de concordance entre les saisies indépendantes des opérateurs A et B a été finalisé et scellé.",
                          icon: "✅"
                        });
                        setSelectedPart('controle_saisie');
                        setAgentTab('controle_saisie');
                      } else if (selectedPart === 'controle_saisie') {
                        setIsPart7Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 7 - Contrôle de Saisie qualitative", "LOT7-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 7,
                          title: "Partie 7 (Contrôle Saisie) Validée avec Succès 🛡️",
                          details: "L'audit qualitatif de tous les champs transcrits et des pièces d'appui a été vérifié conforme.",
                          icon: "🛡️"
                        });
                        setSelectedPart('validation_lot');
                        setAgentTab('validation_lot');
                      } else if (selectedPart === 'validation_lot') {
                        setIsPart8Validated(true);
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 8 - Sceau & Transmission de Lot", "LOT8-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 8,
                          title: "Partie 8 (Sceau & Clôture) Validée avec Succès 👑",
                          details: "Le lot d'actes d'État Civil a été officiellement signé d'un sceau d'État Civil exécutoire et archives transmises.",
                          icon: "👑"
                        });
                        setSelectedPart(null);
                      }
                    }}
                    className={`w-full py-3 px-4 text-white font-bold text-xs rounded-2xl flex items-center justify-center gap-2 shadow-xs transition-all ${
                      isButtonDisabled 
                        ? "bg-stone-300 hover:bg-stone-300 text-stone-500 cursor-not-allowed border border-stone-400" 
                        : "bg-green-700 hover:bg-green-800 cursor-pointer animate-pulse"
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    {isScanBlocked ? "Bloqué : Lot Vide" : isRejetsBlocked ? "Bloqué : Écarts Non Arbitrés" : isRescanBlocked ? "Bloqué : Actes à Corriger" : "Valider & Clôturer la Partie"}
                  </button>
                );
              })()}

              {/* Quality Issue block showing acts needing re-scan and direct return button */}
              {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough || (p.wasRescanned && !p.isRescanApproved)) && (
                <div className="bg-amber-50 border-2 border-amber-300 p-3 rounded-2xl text-[10.5px] text-amber-900 font-sans space-y-2 mt-2 animate-fade-in">
                  <div className="font-bold flex items-center gap-1.5 text-amber-950">
                    <span className="animate-pulse">📷⚠️</span> 
                    <span className="uppercase text-[10px] tracking-wide font-sans">Correction / Contrôle Re-Scan</span>
                  </div>
                  <p className="text-[10px] text-amber-800 leading-normal font-medium">
                    Des actes nécessitent un re-scan ou un contrôle d'image de conformité avant de pouvoir passer à l'étape d'identification.
                  </p>
                  
                  <div className="bg-white/90 p-2 rounded-xl border border-amber-250 font-mono text-[9.5px] text-amber-950 space-y-1">
                    <div className="font-bold uppercase text-[8px] text-amber-700 tracking-wider">État des actes signalés :</div>
                    {scannedPages.map((p, idx) => {
                      if (p.isBlurred || p.isFoldedText || p.isStrikethrough || (p.wasRescanned && !p.isRescanApproved)) {
                        return (
                          <div key={p.id} className="flex items-center gap-1 text-[9px]">
                            <span>⚠️</span>
                            <span className="font-bold">Page {idx + 1}</span>
                            <span className="opacity-80">• N° {p.numActe} ({p.wasRescanned ? "Re-scanné, à contrôler" : "À re-scanner"})</span>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </div>

                  {selectedPart !== 'rescan_correct' && (
                    <button
                      onClick={() => {
                        setSelectedPart('rescan_correct');
                        setAgentTab('rescan_correct');
                      }}
                      className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-center rounded-xl text-[10px] uppercase shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      📷 Aller au Rescan Correctif
                    </button>
                  )}
                </div>
              )}

              <div className="bg-stone-50 border border-stone-200 p-3 rounded-xl text-[9px] text-stone-600 leading-relaxed font-sans font-medium flex gap-1.5 animate-fade-in">
                <span>⚠️</span>
                <p>La clôture transmet vos statistiques de travail à l'administration de Mlle Chaymae.</p>
              </div>
            </div>

          </aside>

          {/* Streamlined Live Stage Agent main viewport */}
          <main className="flex-1 p-6 md:p-8 xl:p-10 max-w-7xl mx-auto w-full transition-all duration-300">
            
            {/* Header description */}
            <div className="mb-6 pb-4 border-b border-stone-200 flex justify-between items-end">
              <div>
                <span className="text-xs font-display font-bold text-rose-800 bg-rose-50 px-3 py-1 rounded-full border border-rose-100 uppercase select-none">
                  {selectedPart === 'scan' && "Partie 1 • Capture & Scan"}
                  {selectedPart === 'controle_image' && "Partie 2 • Contrôle d'Image"}
                  {selectedPart === 'rescan_correct' && "Partie 3 • Rescan & Validation"}
                  {selectedPart === 'identification' && "Partie 4 • Identification d'Actes"}
                  {selectedPart === 'ia_injection' && "Partie 5 • Injection Directe IA"}
                  {selectedPart === 'double_entry' && "Partie 6 • Double Saisie & Arbitrage"}
                  {selectedPart === 'controle_saisie' && "Partie 7 • Contrôle Saisie Qualitatif"}
                  {selectedPart === 'validation_lot' && "Partie 8 • Sceau & Clôture"}
                </span>
                <h2 className="font-display font-black text-xl text-stone-900 mt-2 select-none">
                  {selectedPart === 'scan' && "🎥 Numérisation, Recadrage & Gestion de la Caméra Zénithale"}
                  {selectedPart === 'controle_image' && "🔎 Contrôle de Netteté, Détection de Flou & Pliures"}
                  {selectedPart === 'rescan_correct' && "📷 Atelier de Ré-numérisation & Validation Conforme"}
                  {selectedPart === 'identification' && "🏛️ Identification de l'Acte Civile (RC / RP)"}
                  {selectedPart === 'ia_injection' && "🧠 Moteur IA & Générateur de Script PostgreSQL"}
                  {selectedPart === 'double_entry' && "🏛️ Résolution d'Écarts & Arbitrage de Double Saisie"}
                  {selectedPart === 'controle_saisie' && "🎯 Audit Final de Conformité de Saisie"}
                  {selectedPart === 'validation_lot' && "🌹 Apposition du Sceau Officiel de l'État Civil & Clôture"}
                </h2>
              </div>
            </div>

            {/* Core Viewport router based on current agentTab sub-tab selection */}
            <div className="transition-all duration-200">
              
              {/* Part 1: Camera scan & image control */}
              {selectedPart === 'scan' && (
                <div className="space-y-6 animate-fade-in">
                  {scannedPages.some(p => p.isBlurred || p.isFoldedText) && (
                    <div className="p-4 bg-red-50 border-2 border-red-300 text-red-900 rounded-3xl mb-6 relative overflow-hidden shadow-xs animate-bounce">
                      <div className="flex gap-3">
                        <span className="text-xl">🚨</span>
                        <div>
                          <h4 className="font-bold text-red-950 text-xs md:text-sm">LOT BLOQUÉ : Image Floue ou anomalie de pliure (Twya) détectée !</h4>
                          <p className="text-[10.5px] text-red-800 mt-1 leading-relaxed font-sans font-medium">
                            Détails réglementaires : Un message automatique a été envoyé pour répéter le scan de l'acte défectueux. La validation et la transition vers la Partie 2 (Traitement de Rejets) sont <b>bloquées</b> tant qu'un flou physique ou un pliage subsiste sur le lot.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <WorkflowPreparation 
                    scannedPages={scannedPages} 
                    setScannedPages={setScannedPages}
                    onValidatePreparation={() => {
                      setIsPart1Validated(true);
                      setIsPart2Validated(true);
                      setSelectedPart('rescan_correct');
                      setAgentTab('rescan_correct');
                    }}
                    isIAStageUnlocked={isPart2Validated}
                    forceMode="scan"
                    resetCounter={resetCounter}
                  />
                </div>
              )}

              {/* Part 4: Rescan & Validation */}
              {selectedPart === 'rescan_correct' && (
                <div className="space-y-6 animate-fade-in">
                  <RescanCorrectWorkspace 
                    scannedPages={scannedPages}
                    setScannedPages={setScannedPages}
                    onValidate={() => {
                      setIsPart3Validated(true);
                      setSelectedPart('identification');
                      setAgentTab('identification');
                    }}
                  />
                </div>
              )}

              {/* Part 5: Identification */}
              {selectedPart === 'identification' && (
                <div className="space-y-6 animate-fade-in">
                  <WorkflowPreparation 
                    scannedPages={scannedPages} 
                    setScannedPages={setScannedPages}
                    onValidatePreparation={() => {
                      setIsPart4Validated(true);
                      setSelectedPart('ia_injection');
                      setAgentTab('ocr');
                    }}
                    isIAStageUnlocked={isPart5Validated}
                    forceMode="identification"
                    resetCounter={resetCounter}
                  />
                </div>
              )}

              {/* Part 5: Direct JSON State Civil Bulk Injection into PostgreSQL */}
              {selectedPart === 'ia_injection' && (
                <div className="space-y-6 animate-fade-in">
                  <IaEngineMorocco 
                    scannedPages={scannedPages}
                    setScannedPages={setScannedPages}
                    onValidateIAStage={() => {
                      setIsPart5Validated(true);
                      setSelectedPart('double_entry');
                      setAgentTab('double_entry');
                      handleAgentLoggedAction(scannedPages.length, "Clôture Partie 5 - Injection de Fichier JSON", "LOT5-" + Date.now().toString().slice(-4));
                      setCompletedPartInfo({
                        partNum: 5,
                        title: "Partie 5 (Injection de Fichier JSON) Validée avec Succès 🎉",
                        details: "La transcription de fichier d'échange civil JSON et l'injection bulk PostgreSQL ont été validées.",
                        icon: "🚀"
                      });
                    }}
                  />
                </div>
              )}

              {/* Part 7: Double Entry Verification for Double Entry match */}
              {selectedPart === 'double_entry' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-white border border-stone-200 p-6 rounded-3xl space-y-4 shadow-2xs">
                    <h3 className="font-display font-black text-stone-900 text-base border-b border-stone-150 pb-2">
                       A. Contrôle de Double Saisie & Résolution d'Écarts (Opérateurs A & B)
                    </h3>
                    <RegistryDoubleEntry 
                      scannedPages={scannedPages}
                      setScannedPages={setScannedPages}
                      onValidateStep3={() => {
                        setIsPart6Validated(true);
                        setSelectedPart('controle_saisie');
                        setAgentTab('controle_saisie');
                        handleAgentLoggedAction(scannedPages.length, "Clôture Partie 6 - Double Saisie (Arbitrage)", "LOT6-" + Date.now().toString().slice(-4));
                        setCompletedPartInfo({
                          partNum: 6,
                          title: "Partie 6 (Double Saisie) Validée avec Succès 🏛️",
                          details: "L'arbitrage ultime de concordance entre les saisies indépendantes des opérateurs A et B a été finalisé et scellé.",
                          icon: "✅"
                        });
                      }}
                      isStep4Unlocked={true}
                    />
                  </div>
                </div>
              )}

              {/* Part 7: Contrôle de Saisie */}
              {selectedPart === 'controle_saisie' && (
                <div className="space-y-6 animate-fade-in">
                  <ControleSaisie
                    scannedPages={scannedPages}
                    setScannedPages={setScannedPages}
                    onValidateStep6={() => {
                      setIsPart7Validated(true);
                      setSelectedPart('validation_lot');
                      setAgentTab('validation_lot');
                    }}
                  />
                </div>
              )}

              {/* Part 8: Validation de Lot */}
              {selectedPart === 'validation_lot' && (
                <div className="space-y-6 animate-fade-in">
                  <ValidationLot
                    scannedPages={scannedPages}
                    onFinalResetAll={triggerResetProgress}
                  />
                </div>
              )}

            </div>

          </main>

        </div>

      )}

    </div>
  );
}
