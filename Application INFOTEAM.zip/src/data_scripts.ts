/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const CODE_INJECT_JSON_POSTGRES = `from __future__ import annotations

import csv
import json
import logging
import re
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

import pyodbc
import psycopg2
from psycopg2.extras import RealDictCursor

from injection_config import CONFIG

logger = logging.getLogger("inject-json")

@dataclass(frozen=True)
class ColumnMeta:
    table_name: str
    column_name: str
    data_type: str
    character_maximum_length: Optional[int]
    is_nullable: bool
    column_default: Optional[str]
    is_identity: bool

def get_injection_date() -> date:
    raw = normalize_text(CONFIG.processing.dateinjection)
    if not raw:
        return datetime.utcnow().date()
    # Formats gérés : YYYY-MM-DD, DD/MM/YYYY, etc.
    formats = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d")
    for fmt in formats:
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    raise ValueError("dateinjection invalide.")

class SqlServerLotSource:
    def __init__(self) -> None:
        # Configuration ODBC pour SQL Server
        cs = (
            f"DRIVER={{{CONFIG.sqlserver.driver}}};"
            f"SERVER={CONFIG.sqlserver.server};"
            f"DATABASE={CONFIG.sqlserver.database};"
            f"UID={CONFIG.sqlserver.user};"
            f"PWD={CONFIG.sqlserver.password};"
        )
        self.conn = pyodbc.connect(cs)
        self.conn.autocommit = False

    def fetch_lots(self) -> List[Dict[str, Any]]:
        return self.query_all(CONFIG.sql.select_lots_sql, [3])

    def update_lot_status(self, lot: str) -> None:
        self.execute(CONFIG.sql.update_lot_after_pick_sql, [lot])

class Db:
    def __init__(self) -> None:
        self.conn = psycopg2.connect(
            host=CONFIG.db.host,
            port=CONFIG.db.port,
            dbname=CONFIG.db.dbname,
            user=CONFIG.db.user,
            password=CONFIG.db.password
        )
        self.conn.autocommit = False
        self.columns = self._load_columns()
        self.primary_keys = self._load_primary_keys()

    def table_exists(self, table: str) -> bool:
        return table in self.columns

    def insert_row(self, table: str, row: Dict[str, Any]) -> Optional[int]:
        if not self.table_exists(table):
            return None
        clean = self.sanitize_row(table, row)
        col_names = list(clean.keys())
        values = [clean[c] for c in col_names]
        placeholders = ", ".join(["%s"] * len(values))
        cols_sql = ", ".join(col_names)
        sql = f"INSERT INTO {table} ({cols_sql}) VALUES ({placeholders})"
        # Exécution et retour de la Primary Key
        ...
`;

export const CODE_INJECTION_CONFIG = `from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set

@dataclass(frozen=True)
class DbConfig:
    host: str = "192.168.40.13"
    port: int = 5432
    dbname: str = "ECIA2"
    user: str = "postgres"
    password: str = "arh$2017"

@dataclass(frozen=True)
class SqlServerConfig:
    server: str = r"DESKTOP-JDMI37I"
    database: str = "Acte_IA"
    user: str = "sa"
    password: str = "pass123"

@dataclass(frozen=True)
class PathsConfig:
    json_root: Path = Path(r"C:\\arhp_injection\\TR6")
    recursive: bool = True
    glob_pattern: str = "*.json"

@dataclass(frozen=True)
class AppConfig:
    db: DbConfig = DbConfig()
    sqlserver: SqlServerConfig = SqlServerConfig()
    paths: PathsConfig = PathsConfig()

CONFIG = AppConfig()
`;

export const CODE_MAJ_TOMEREGISTRE = `import argparse
import logging
from inject_json_postgres import CONFIG, Db

def run(target_lot, status_value="PL"):
    db = Db()
    # Récupération et MAJ du tome de registre
    lot_id_aff = int(target_lot) if target_lot.isdigit() else target_lot
    aff = db.query_one("SELECT id_tome_registre FROM affectationregistre WHERE id_lot = %s LIMIT 1", [lot_id_aff])
    
    if aff:
        tome_id = aff["id_tome_registre"]
        db.execute("UPDATE tomeregistre SET status = %s WHERE id_tome_registre = %s", [status_value, tome_id])
        print(f"Modifié avec succès le statut du tome {tome_id} à {status_value}")
    db.close()
`;

export interface DbColumnMeta {
  column_name: string;
  data_type: string;
  character_maximum_length: number | null;
  is_nullable: boolean;
  column_default: string | null;
  is_identity: boolean;
}

export interface DbTableInfo {
  tableName: string;
  description: string;
  columns: DbColumnMeta[];
}

export const POSTGRES_TABLES_SCHEMA: DbTableInfo[] = [
  {
    tableName: "acte",
    description: "Table pivot contenant la fiche d'acte d'état civil de base.",
    columns: [
      { column_name: "id_acte", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: "nextval()", is_identity: true },
      { column_name: "num_acte", data_type: "varchar", character_maximum_length: 50, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "id_tome_registre", data_type: "integer", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "status_acte", data_type: "varchar", character_maximum_length: 5, is_nullable: false, column_default: "'I'", is_identity: false },
      { column_name: "imagepath", data_type: "text", character_maximum_length: null, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "id_type_acte", data_type: "integer", character_maximum_length: null, is_nullable: false, column_default: "1", is_identity: false },
      { column_name: "id_bureau", data_type: "varchar", character_maximum_length: 50, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "id_commune", data_type: "varchar", character_maximum_length: 50, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "date_creation", data_type: "date", character_maximum_length: null, is_nullable: false, column_default: "now()", is_identity: false },
      { column_name: "id_nationalite", data_type: "integer", character_maximum_length: null, is_nullable: true, column_default: "40", is_identity: false }
    ]
  },
  {
    tableName: "deces",
    description: "Informations complémentaires spécifiques pour les actes de décès (type DE).",
    columns: [
      { column_name: "id_acte", data_type: "integer", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "date_deces", data_type: "date", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "lieu_deces", data_type: "text", character_maximum_length: null, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "cause_deces", data_type: "text", character_maximum_length: null, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "id_profession", data_type: "integer", character_maximum_length: null, is_nullable: true, column_default: "54", is_identity: false }
    ]
  },
  {
    tableName: "declaration",
    description: "Détails du déclarant civil lié à l'acte, son lien de parenté et ses informations.",
    columns: [
      { column_name: "id_acte", data_type: "integer", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "nom_civil", data_type: "varchar", character_maximum_length: 150, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "prenom_civil", data_type: "varchar", character_maximum_length: 150, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "date_gregoirienne", data_type: "date", character_maximum_length: null, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "date_hegirienne", data_type: "varchar", character_maximum_length: 50, is_nullable: true, column_default: null, is_identity: false },
      { column_name: "id_lien_parente", data_type: "integer", character_maximum_length: null, is_nullable: true, column_default: "130", is_identity: false }
    ]
  },
  {
    tableName: "mention",
    description: "Mentions marginales transcrites en bordure de registre (Mariage, divorce, décès, etc.).",
    columns: [
      { column_name: "id_mention", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "id_acte", data_type: "integer", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "txtmention", data_type: "text", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "id_type_mention", data_type: "integer", character_maximum_length: null, is_nullable: true, column_default: "40", is_identity: false },
      { column_name: "sign_officier", data_type: "varchar", character_maximum_length: 5, is_nullable: true, column_default: "'O'", is_identity: false }
    ]
  },
  {
    tableName: "nationalite",
    description: "Table des codes et libellés de nationalité dédoublonnés.",
    columns: [
      { column_name: "id_nationalite", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "nationalite", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "nationalite_fr", data_type: "varchar", character_maximum_length: 150, is_nullable: true, column_default: null, is_identity: false }
    ]
  },
  {
    tableName: "profession",
    description: "Table de référence des métiers et professions résolues par l'injecteur.",
    columns: [
      { column_name: "id_profession", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "profession", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "profession_fr", data_type: "varchar", character_maximum_length: 150, is_nullable: true, column_default: null, is_identity: false }
    ]
  },
  {
    tableName: "lien_parente",
    description: "Relations de parenté légale du déclarant de l'acte civil.",
    columns: [
      { column_name: "id_lien_parente", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "lib_lien_parente", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "lib_lien_parente_fr", data_type: "varchar", character_maximum_length: 150, is_nullable: true, column_default: null, is_identity: false }
    ]
  },
  {
    tableName: "qualite",
    description: "Fonctions et qualités validées de l'officier de saisie (Adjoint, Pachalik, etc.).",
    columns: [
      { column_name: "id_qualite", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "liba_qualite", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "type_qualite", data_type: "varchar", character_maximum_length: 5, is_nullable: true, column_default: "'O'", is_identity: false }
    ]
  },
  {
    tableName: "oec",
    description: "Officiers d'État Civil habilités et rattachés aux bureaux d'indexation.",
    columns: [
      { column_name: "id_officier", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "nom_officier_ar", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "id_qualite", data_type: "integer", character_maximum_length: null, is_nullable: true, column_default: null, is_identity: false }
    ]
  },
  {
    tableName: "ville",
    description: "Villes et géolocalisations administratives de naissance des déclarants originaux.",
    columns: [
      { column_name: "id_ville", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "lib_ville", data_type: "varchar", character_maximum_length: 150, is_nullable: false, column_default: null, is_identity: false }
    ]
  },
  {
    tableName: "tomeregistre",
    description: "Détail physique des Tomes d'archives nationales enregistrés et validés.",
    columns: [
      { column_name: "id_tome_registre", data_type: "serial", character_maximum_length: null, is_nullable: false, column_default: null, is_identity: true },
      { column_name: "num_tome", data_type: "varchar", character_maximum_length: 20, is_nullable: false, column_default: null, is_identity: false },
      { column_name: "status", data_type: "varchar", character_maximum_length: 10, is_nullable: false, column_default: "'PL'", is_identity: false }
    ]
  }
];

