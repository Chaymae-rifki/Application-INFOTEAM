/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PageScan, PieceJointe, OperatorSaisieData } from './types';

// Let's declare some prebuilt records to demo the workflow
export const PRESET_PAGES: PageScan[] = [
  {
    id: "SCAN-2026-001",
    imageIndex: 0,
    filename: "REG_BEC341_TOME12_ACTE248.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:12",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "12",
    numActe: "248",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Déclaré par le père en personne dans les délais légaux.",
    declarationDetails: "Déclaration reçue en présence de deux témoins certifiés, Monsieur Ahmed El Fassi et Monsieur Said Bennani, tous deux de nationalité marocaine.",
    piecesJointes: [
      {
        id: "PJ-001",
        typePiece: "Attestation d'accouchement",
        reference: "HOP-MIL-2026-441-A",
        dateDelivrance: "1994-04-10",
        autoriteEmettrice: "Maternité de l'Hôpital Militaire de Fès"
      }
    ],
    operatorA: {
      prenom: "Fatima",
      nom: "Khaloui",
      prenomAr: "فاطمة",
      nomAr: "خلوى",
      dateGregoirienne: "10/04/1994",
      dateHegirienne: "29/10/1414",
      perePrenom: "Ahmed",
      merePrenom: "Aicha",
      numActe: "248",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Fatima",
      nom: "Khalouy", // Discrepant spelling A vs B (Khaloui vs Khalouy)
      prenomAr: "فاطمة",
      nomAr: "خلوى",
      dateGregoirienne: "10/04/1994",
      dateHegirienne: "20/10/1414", // Discrepant Date Hégirienne (29 vs 20)
      perePrenom: "Ahmed",
      merePrenom: "Aisha", // Discrepant Spelling (Aicha vs Aisha)
      numActe: "248",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-002",
    imageIndex: 1,
    filename: "REG_BEC220_TOME04_ACTE015.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:14",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "04",
    numActe: "015",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le fils de la défunte, Majeur de son état civil actuel.",
    declarationDetails: "Liaison directe avec l'acte de naissance d'origine. Certificat de décès délivré après constat par l'autorité sanitaire compétente.",
    piecesJointes: [
      {
        id: "PJ-002",
        typePiece: "Constat de Décès Médical",
        reference: "CERT-MED-9921",
        dateDelivrance: "2026-05-15",
        autoriteEmettrice: "Clinique Ibn Sina, Service Urgences"
      }
    ],
    operatorA: {
      prenom: "Mohammed",
      nom: "Benzakri",
      prenomAr: "محمد",
      nomAr: "بنزكري",
      dateGregoirienne: "14/05/2026",
      dateHegirienne: "26/10/1447",
      perePrenom: "Ali",
      merePrenom: "Fatima",
      numActe: "015",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Mohamed", // Discrepant Spelling
      nom: "Benzakri",
      prenomAr: "محمد",
      nomAr: "بنزكري",
      dateGregoirienne: "14/05/2026",
      dateHegirienne: "26/10/1447",
      perePrenom: "Aly", // Discrepant Spelling Aly vs Ali
      merePrenom: "Fatima",
      numActe: "015",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-003",
    imageIndex: 2,
    filename: "REG_BEC105_TOME08_ACTE112.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:18",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "08",
    numActe: "112",
    isOpeningPage: true,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 2,
    isActeBis: false,
    marginalMentionsCount: 2,
    statutDeclarative: "Mariage certifié par Adoul agréé près l'état civil de la circonscription.",
    declarationDetails: "Enregistrement du contrat d'union matrimoniale en présence des tuteurs légitimes des conjoints et des témoins d'usage.",
    piecesJointes: [
      {
        id: "PJ-003",
        typePiece: "Contrat de Dot et Certificat Prénuptial",
        reference: "ADL-4491-2026",
        dateDelivrance: "2026-06-01",
        autoriteEmettrice: "Tribunal de la Famille de Fès"
      }
    ],
    operatorA: {
      prenom: "Yassine",
      nom: "El Amrani",
      prenomAr: "ياسين",
      nomAr: "العمراني",
      dateGregoirienne: "01/06/2026",
      dateHegirienne: "15/11/1447",
      perePrenom: "Karim",
      merePrenom: "Malika",
      numActe: "112",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Yassine",
      nom: "El Amrani",
      prenomAr: "ياسين",
      nomAr: "العمراني",
      dateGregoirienne: "01/06/2026",
      dateHegirienne: "15/11/1447",
      perePrenom: "Karim",
      merePrenom: "Malika",
      numActe: "112",
      typeActe: "Mariage"
    },
    isConflictResolved: true // 100% Identical!
  },
  {
    id: "SCAN-2026-004",
    imageIndex: 0,
    filename: "REG_BEC341_TOME12_ACTE249.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:20",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "12",
    numActe: "249",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Établi d'après avis officiel du médecin ayant assisté à l'accouchement.",
    declarationDetails: "Nouveau-né de sexe masculin. Nom de famille validé d'après livret de famille officiel.",
    piecesJointes: [
      {
        id: "PJ-004",
        typePiece: "Déclaration d'accouchement clinique",
        reference: "CLIN-FES-883",
        dateDelivrance: "1990-06-15",
        autoriteEmettrice: "Direction de la Maternité Privée"
      }
    ],
    operatorA: {
      prenom: "Omar",
      nom: "Sijilmassi",
      prenomAr: "عمر",
      nomAr: "سجلماسي",
      dateGregoirienne: "15/06/1990",
      dateHegirienne: "21/11/1410",
      perePrenom: "Karim",
      merePrenom: "Zineb",
      numActe: "249",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Omar",
      nom: "Sijilmasi", // Discrepant Spelling (Sijilmassi vs Sijilmasi)
      prenomAr: "عمر",
      nomAr: "سجلماسي",
      dateGregoirienne: "16/06/1990", // Discrepant Date (15 vs 16)
      dateHegirienne: "21/11/1410",
      perePrenom: "Karime", // Discrepant Spelling
      merePrenom: "Zineb",
      numActe: "250", // DIFF ID: Triggering discrepancy check for double identifiers
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-005",
    imageIndex: 1,
    filename: "REG_BEC220_TOME04_ACTE016.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:22",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "04",
    numActe: "016",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le conjoint survivant à la diligence de l'Hôpital Hassan II.",
    declarationDetails: "Ancien fonctionnaire retraité d'État. Acte consigné sur procès-verbal dressé par la police judiciaire.",
    piecesJointes: [
      {
        id: "PJ-005",
        typePiece: "Certificat Administratif de Constat",
        reference: "ADM-DECES-774",
        dateDelivrance: "2026-05-20",
        autoriteEmettrice: "Bureau Municipal d'Hygiène (BMH)"
      }
    ],
    operatorA: {
      prenom: "Latifa",
      nom: "Bennani",
      prenomAr: "لطيفة",
      nomAr: "بنانى",
      dateGregoirienne: "20/05/2026",
      dateHegirienne: "03/11/1447",
      perePrenom: "Rachid",
      merePrenom: "Kenza",
      numActe: "016",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Letifa", // Discrepant Spelling
      nom: "Bennani",
      prenomAr: "لطيفة",
      nomAr: "بنانى",
      dateGregoirienne: "20/05/2026",
      dateHegirienne: "03/11/1447",
      perePrenom: "Rachid",
      merePrenom: "Kanza", // Discrepant Spelling (Kenza vs Kanza)
      numActe: "016",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-006",
    imageIndex: 0,
    filename: "REG_BEC341_TOME12_ACTE250.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:25",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "12",
    numActe: "250",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Présenté par le grand-père paternel résidant à Fès.",
    declarationDetails: "Mère absente lors de l'enregistrement pour des motifs de santé publique légitimes.",
    piecesJointes: [],
    operatorA: {
      prenom: "Anass",
      nom: "Bouazza",
      prenomAr: "أنس",
      nomAr: "بوعزة",
      dateGregoirienne: "12/03/2001",
      dateHegirienne: "17/12/1421",
      perePrenom: "Mehdi",
      merePrenom: "Halima",
      numActe: "250",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Anass",
      nom: "Bouaza", // Discrepant Spelling (Bouzza vs Bouaza)
      prenomAr: "أنس",
      nomAr: "بوعزة",
      dateGregoirienne: "12/03/2001",
      dateHegirienne: "17/12/1421",
      perePrenom: "Mahdi", // Discrepant Spelling (Mehdi vs Mahdi)
      merePrenom: "Halima",
      numActe: "250",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-007",
    imageIndex: 2,
    filename: "REG_BEC105_TOME08_ACTE113.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:28",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "08",
    numActe: "113",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Union notariale entre résidents marocains et binationaux.",
    declarationDetails: "Contrat de mariage répertorié au registre central des alliances matrimoniales.",
    piecesJointes: [
      {
        id: "PJ-007",
        typePiece: "Autorisation Spéciale de Mariage",
        reference: "AUT-TRIB-110",
        dateDelivrance: "2026-04-10",
        autoriteEmettrice: "Tribunal Judiciaire de Fès"
      }
    ],
    operatorA: {
      prenom: "Tarik",
      nom: "Kadiri",
      prenomAr: "طارق",
      nomAr: "قادري",
      dateGregoirienne: "15/04/2026",
      dateHegirienne: "27/09/1447",
      perePrenom: "Hassan",
      merePrenom: "Sofia",
      numActe: "113",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Tariq", // Discrepant Spelling Tarik vs Tariq
      nom: "Kadiri",
      prenomAr: "طارق",
      nomAr: "قادري",
      dateGregoirienne: "15/04/2026",
      dateHegirienne: "27/09/1447",
      perePrenom: "Hassan",
      merePrenom: "Sofya", // Discrepant Spelling Sofia vs Sofya
      numActe: "113",
      typeActe: "Mariage"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-008",
    imageIndex: 0,
    filename: "REG_BEC341_TOME12_ACTE251.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:30",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "12",
    numActe: "251",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par la mère célibataire d'après l'acte d'autorisation légale de tutelle exclusive.",
    declarationDetails: "Enregistrement supervisé pour conformité constitutionnelle relative aux droits des mères.",
    piecesJointes: [
      {
        id: "PJ-008",
        typePiece: "Autorisation tutelle judiciaire",
        reference: "JUG-TUT-4321",
        dateDelivrance: "2015-11-01",
        autoriteEmettrice: "Tribunal de Première Instance de Fès"
      }
    ],
    operatorA: {
      prenom: "Kenza",
      nom: "El Fassi",
      prenomAr: "كنزة",
      nomAr: "الفاسي",
      dateGregoirienne: "11/11/2015",
      dateHegirienne: "28/12/1436",
      perePrenom: "Inconnu",
      merePrenom: "Fatima",
      numActe: "251",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Kenza",
      nom: "Elfassi", // Discrepant spelling El Fassi vs Elfassi
      prenomAr: "كنزة",
      nomAr: "الفاسي",
      dateGregoirienne: "11/11/2015",
      dateHegirienne: "28/12/1436",
      perePrenom: "Inconnu",
      merePrenom: "Fatema", // Discrepant spelling Fatima vs Fatema
      numActe: "251",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-009",
    imageIndex: 2,
    filename: "REG_BEC105_TOME08_ACTE114.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:33",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Divorce",
    numBEC: "BEC-105",
    numTome: "08",
    numActe: "114",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Prononcé judiciaire contradictoire définitif enregistré par Adoul habilité.",
    declarationDetails: "Enregistrement de la rupture d'union ordonnée par jugement civil exécutoire.",
    piecesJointes: [
      {
        id: "PJ-009",
        typePiece: "Jugement de Dissolution de Mariage",
        reference: "DIV-SEC-998",
        dateDelivrance: "2026-05-10",
        autoriteEmettrice: "Chambre Civile de la Famille de Fès"
      }
    ],
    operatorA: {
      prenom: "Amina",
      nom: "Mansouri",
      prenomAr: "أمينة",
      nomAr: "منصوري",
      dateGregoirienne: "25/05/2026",
      dateHegirienne: "08/11/1447",
      perePrenom: "Said",
      merePrenom: "Salma",
      numActe: "114",
      typeActe: "Divorce"
    },
    operatorB: {
      prenom: "Amina",
      nom: "Mansouri",
      prenomAr: "أمينة",
      nomAr: "منصوري",
      dateGregoirienne: "25/05/2026",
      dateHegirienne: "08/11/1447",
      perePrenom: "Said",
      merePrenom: "Salame", // Discrepant Spelling (Salma vs Salame)
      numActe: "114",
      typeActe: "Divorce"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-010",
    imageIndex: 0,
    filename: "REG_BEC341_TOME12_ACTE252.jpg",
    status: "Brut",
    captureTime: "19/06/2026 09:36",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "12",
    numActe: "252",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Déclaré par le père adoptif ou légataire avec justificatifs légaux d'usage.",
    declarationDetails: "Mention marginale de tutelle (Kafala) enregistrée synchrone avec l'acte d'État Civil principal.",
    piecesJointes: [
      {
        id: "PJ-010",
        typePiece: "Ordonnance Homologation Kafala",
        reference: "KAF-TRIB-8821",
        dateDelivrance: "2018-09-02",
        autoriteEmettrice: "Tribunal Judiciaire des Affaires Sociales"
      }
    ],
    operatorA: {
      prenom: "Mehdi",
      nom: "Benjelloun",
      prenomAr: "المهدي",
      nomAr: "بن جلون",
      dateGregoirienne: "02/09/2018",
      dateHegirienne: "22/12/1439",
      perePrenom: "Rachid",
      merePrenom: "Yasmina",
      numActe: "252",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Mahdy", // Discrepant spelling Mehdi vs Mahdy
      nom: "Benjelloun",
      prenomAr: "المهدي",
      nomAr: "بن جلون",
      dateGregoirienne: "02/09/2018",
      dateHegirienne: "22/12/1439",
      perePrenom: "Rachide", // Discrepant spelling Rachid vs Rachide
      merePrenom: "Yasmina",
      numActe: "252",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  }
];

// Raw input strings which demonstrates the stripper logic!
export const MOCK_NOTEPAD_BAK_FILE = 
`// ==============================================================================
// NOTEPAD++ AUTOSAVE RECOVERY BUFFER & COPIED CLIPBOARD VERSION
// FILE: Acte_IA_backup_2026_06_16_110001_8861116.bak
// SYSTEM PROCESS STATUS: INACTIVE
// RECOVERY PORT: LOCALHOST:5433 / ADM_CIVIL
// EXPORT_DATE: Friday, June 16, 2026 @ 11:00:01 AM
// 
// [WARNING] DO NOT SEND THIS LOG TO PRODUCTION.
// USE ONLY THE SECURED PARSER AT THE FIRST BRACKET '{' TO PREVENT INGEST CRASH.
// ==============================================================================

{
  "backup_id": "8861116",
  "moteur_version": "Gemini-3.5-CivilStatus-v2b",
  "timestamp": "2026-06-16T11:00:01Z",
  "acte": {
    "num_acte": "248",
    "bec_code": "BEC-341",
    "tome": "12",
    "type": "Naissance",
    "date_enregistrement": "1994-04-12"
  },
  "declaration": {
    "declarant_relation": "Père",
    "declarant_nom": "خلوى",
    "declarant_prenom": "أحمد",
    "nom_civil_fr": "Khaloui",
    "prenom_civil_fr": "Fatima",
    "nom_civil": "خلوى",
    "prenom_civil": "فاطمة",
    "date_gregoirienne": "10/04/1994",
    "date_hegirienne": "29/10/1414",
    "pere_nom": "خلوى",
    "pere_prenom": "أحمد",
    "mere_nom": "شقرون",
    "mere_prenom": "عائشة"
  },
  "deces": null,
  "jugement": {
    "has_jugement": false,
    "reference": null,
    "tribunal": null,
    "details": null
  },
  "mentions": [
    {
      "date": "2018-07-20",
      "type": "Mariage",
      "annotation": "Mariée le 20/07/2018 avec Benzakri Mohamed"
    }
  ]
}`;

export const MOCK_NOTEPAD_BAK_FILE_DECES = 
`# ==============================================================================
# ATTACHED DISK RECOVERY LOG - EMERGENCY BAK DECES
# SOURCE IP: 10.12.99.14
# GENERATED BY: AGENT INTEGRATOR v2.4
# STATUS: UNCLEAN HEADERS DETECTED & IGNORED
# ==============================================================================
{
  "backup_id": "9921223",
  "moteur_version": "Gemini-3.5-CivilStatus-DeathEngine",
  "timestamp": "2026-05-15T14:30:10Z",
  "acte": {
    "num_acte": "015",
    "bec_code": "BEC-220",
    "tome": "04",
    "type": "Décès",
    "date_enregistrement": "2026-05-15"
  },
  "declaration": {
    "declarant_relation": "Fils",
    "declarant_nom": "بنزكري",
    "declarant_prenom": "سعيد",
    "nom_civil_fr": "Benzakri",
    "prenom_civil_fr": "Mohamed",
    "nom_civil": "بنزكري",
    "prenom_civil": "محمد",
    "date_gregoirienne": "14/05/2026",
    "date_hegirienne": "26/10/1447",
    "pere_nom": "بنزكري",
    "pere_prenom": "علي",
    "mere_nom": "خلوى",
    "mere_prenom": "فاطمة"
  },
  "deces": {
    "date_deces": "2026-05-14",
    "lieu_deces": "Clinique Ibn Sina, Fès",
    "cause_deces": "Arrêt cardio-respiratoire"
  },
  "jugement": {
    "has_jugement": false,
    "reference": null,
    "tribunal": null,
    "details": null
  },
  "mentions": []
}`;

// The extracted PostgreSQL SQL command representations for visuals
export const SQL_STATEMENTS = `
-- ==========================================================================
-- E-REGISTRE ETAT CIVIL NATIONAL DATABASE - POSTGRESQL 16 SCHEMA
-- HOST: LOCALHOST:5433 | DATABASE: acte_civil
-- GENERATED AUTOMATICALLY BY IA ENGINE STRIPPER
-- ==========================================================================

-- 🏛️ CREATE TABLE STRUCTURES
CREATE TABLE IF NOT EXISTS bec_offices (
    bec_code VARCHAR(50) PRIMARY KEY,
    name_fr VARCHAR(150),
    governorate_fr VARCHAR(150)
);

CREATE TABLE IF NOT EXISTS records (
    id SERIAL PRIMARY KEY,
    num_acte VARCHAR(50) NOT NULL,
    bec_code VARCHAR(50) REFERENCES bec_offices(bec_code),
    tome VARCHAR(50),
    type_acte VARCHAR(100) NOT NULL,
    date_enregistrement DATE NOT NULL,
    nom_civil VARCHAR(150) NOT NULL,
    prenom_civil VARCHAR(150) NOT NULL,
    nom_civil_ar VARCHAR(150),
    prenom_civil_ar VARCHAR(150),
    date_gregoirienne DATE,
    date_hegirienne VARCHAR(50),
    pere_prenom VARCHAR(150),
    mere_prenom VARCHAR(150),
    is_opening_page BOOLEAN DEFAULT FALSE,
    is_closing_page BOOLEAN DEFAULT FALSE,
    twya_folded BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS marginal_mentions (
    id SERIAL PRIMARY KEY,
    record_id INT REFERENCES records(id) ON DELETE CASCADE,
    mention_date DATE,
    type_mention VARCHAR(100),
    annotation TEXT
);

-- 🚀 POPULATE / INSERT NEW PARSED INTEGRATION RECORD
INSERT INTO bec_offices (bec_code, name_fr, governorate_fr)
VALUES ('BEC-341', 'Bureau d\\'État Civil principal - Fès Médina', 'Fès-Meknès')
ON CONFLICT (bec_code) DO NOTHING;

INSERT INTO records (
    num_acte, bec_code, tome, type_acte, date_enregistrement, 
    nom_civil, prenom_civil, nom_civil_ar, prenom_civil_ar,
    date_gregoirienne, date_hegirienne, pere_prenom, mere_prenom,
    twya_folded, is_opening_page, is_closing_page
) VALUES (
    '248', 'BEC-341', '12', 'Naissance', '1994-04-12',
    'Khaloui', 'Fatima', 'خلوى', 'فاطمة',
    '1994-04-10', '1414-10-29', 'Ahmed', 'Aicha',
    FALSE, FALSE, FALSE
);

INSERT INTO marginal_mentions (record_id, mention_date, type_mention, annotation)
VALUES (
    (SELECT id FROM records WHERE num_acte = '248' AND bec_code = 'BEC-341' LIMIT 1),
    '2018-07-20', 'Mariage', 'Mariée le 20/07/2018 avec Benzakri Mohamed'
);

COMMIT;
`;

export const PRESET_PAGES_POOL_B: PageScan[] = [
  {
    id: "SCAN-2026-B01",
    imageIndex: 0,
    filename: "REG_BEC341_TOME15_ACTE310.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:15",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "15",
    numActe: "310",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Déclaré par le père en personne dans les délais légaux.",
    declarationDetails: "Déclaration reçue en présence de deux témoins certifiés de nationalité marocaine.",
    piecesJointes: [
      {
        id: "PJ-B01",
        typePiece: "Attestation d'accouchement",
        reference: "HOP-MIL-2026-992-B",
        dateDelivrance: "1998-05-12",
        autoriteEmettrice: "Maternité Clinique Fès"
      }
    ],
    operatorA: {
      prenom: "Youssef",
      nom: "Chraibi",
      prenomAr: "يوسف",
      nomAr: "الشرايبي",
      dateGregoirienne: "12/05/1998",
      dateHegirienne: "15/01/1419",
      perePrenom: "Rachid",
      merePrenom: "Khadija",
      numActe: "310",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Youssef",
      nom: "Chraybi",
      prenomAr: "يوسف",
      nomAr: "الشرايبي",
      dateGregoirienne: "12/05/1998",
      dateHegirienne: "05/01/1419",
      perePrenom: "Rachid",
      merePrenom: "Khadija",
      numActe: "310",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B02",
    imageIndex: 1,
    filename: "REG_BEC220_TOME06_ACTE044.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:17",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "06",
    numActe: "044",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le fils de la défunte.",
    declarationDetails: "Liaison directe avec l'acte de naissance d'origine. Certificat de décès délivré après constat.",
    piecesJointes: [
      {
        id: "PJ-B02",
        typePiece: "Constat de Décès Médical",
        reference: "CERT-MED-9988",
        dateDelivrance: "2026-06-18",
        autoriteEmettrice: "Clinique Ibn Sina, Fès"
      }
    ],
    operatorA: {
      prenom: "Aicha",
      nom: "Alaoui",
      prenomAr: "عائشة",
      nomAr: "العلوي",
      dateGregoirienne: "18/06/2026",
      dateHegirienne: "03/12/1447",
      perePrenom: "Hassan",
      merePrenom: "Malika",
      numActe: "044",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Aisha",
      nom: "Alaoui",
      prenomAr: "عائشة",
      nomAr: "العلوي",
      dateGregoirienne: "18/06/2026",
      dateHegirienne: "03/12/1447",
      perePrenom: "Hassen",
      merePrenom: "Malika",
      numActe: "044",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B03",
    imageIndex: 2,
    filename: "REG_BEC105_TOME09_ACTE180.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:20",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "09",
    numActe: "180",
    isOpeningPage: true,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 2,
    isActeBis: false,
    marginalMentionsCount: 2,
    statutDeclarative: "Mariage certifié par Adoul agréé près l'état civil de la circonscription.",
    declarationDetails: "Enregistrement du contrat d'union matrimoniale en présence des tuteurs légitimes.",
    piecesJointes: [
      {
        id: "PJ-B03",
        typePiece: "Contrat de Dot et Certificat Prénuptial",
        reference: "ADL-8821-2026",
        dateDelivrance: "2026-06-05",
        autoriteEmettrice: "Tribunal de la Famille de Fès"
      }
    ],
    operatorA: {
      prenom: "Amine",
      nom: "Filali",
      prenomAr: "أمين",
      nomAr: "الفيلالي",
      dateGregoirienne: "05/06/2026",
      dateHegirienne: "19/11/1447",
      perePrenom: "Khalid",
      merePrenom: "Ghita",
      numActe: "180",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Amine",
      nom: "Filali",
      prenomAr: "أمين",
      nomAr: "الفيلالي",
      dateGregoirienne: "05/06/2026",
      dateHegirienne: "19/11/1447",
      perePrenom: "Khalid",
      merePrenom: "Ghita",
      numActe: "180",
      typeActe: "Mariage"
    },
    isConflictResolved: true
  },
  {
    id: "SCAN-2026-B04",
    imageIndex: 0,
    filename: "REG_BEC341_TOME15_ACTE311.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:22",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "15",
    numActe: "311",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Établi d'après avis officiel du médecin ayant assisté à l'accouchement.",
    declarationDetails: "Nouveau-né de sexe féminin. Nom de famille validé d'après livret de famille.",
    piecesJointes: [
      {
        id: "PJ-B04",
        typePiece: "Déclaration d'accouchement clinique",
        reference: "CLIN-FES-992",
        dateDelivrance: "1998-07-20",
        autoriteEmettrice: "Direction de la Maternité Privée"
      }
    ],
    operatorA: {
      prenom: "Meriem",
      nom: "Tazi",
      prenomAr: "مريم",
      nomAr: "التازي",
      dateGregoirienne: "20/07/1998",
      dateHegirienne: "26/03/1419",
      perePrenom: "Abdelkader",
      merePrenom: "Mina",
      numActe: "311",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Meryem",
      nom: "Tazi",
      prenomAr: "مريم",
      nomAr: "التازي",
      dateGregoirienne: "21/07/1998",
      dateHegirienne: "26/03/1419",
      perePrenom: "Abdelkader",
      merePrenom: "Mina",
      numActe: "311",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B05",
    imageIndex: 1,
    filename: "REG_BEC220_TOME06_ACTE045.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:25",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "06",
    numActe: "045",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le conjoint survivant.",
    declarationDetails: "Ancien fonctionnaire retraité d'État. Acte consigné sur procès-verbal.",
    piecesJointes: [
      {
        id: "PJ-B05",
        typePiece: "Certificat Administratif de Constat",
        reference: "ADM-DECES-992",
        dateDelivrance: "2026-06-22",
        autoriteEmettrice: "Bureau Municipal d'Hygiène (BMH)"
      }
    ],
    operatorA: {
      prenom: "Abdellah",
      nom: "Daoudi",
      prenomAr: "عبد الله",
      nomAr: "الداودي",
      dateGregoirienne: "22/06/2026",
      dateHegirienne: "07/12/1447",
      perePrenom: "Ahmed",
      merePrenom: "Kenza",
      numActe: "045",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Abdallah",
      nom: "Daoudi",
      prenomAr: "عبد الله",
      nomAr: "الداودي",
      dateGregoirienne: "22/06/2026",
      dateHegirienne: "07/12/1447",
      perePrenom: "Ahmed",
      merePrenom: "Kanza",
      numActe: "045",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B06",
    imageIndex: 0,
    filename: "REG_BEC341_TOME15_ACTE312.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:28",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "15",
    numActe: "312",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Présenté par le grand-père paternel.",
    declarationDetails: "Mère absente lors de l'enregistrement pour des motifs valables.",
    piecesJointes: [],
    operatorA: {
      prenom: "Ghita",
      nom: "Belkhayat",
      prenomAr: "غيثة",
      nomAr: "بلخياط",
      dateGregoirienne: "14/10/2002",
      dateHegirienne: "07/08/1423",
      perePrenom: "Said",
      merePrenom: "Laila",
      numActe: "312",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Ghita",
      nom: "Belkhaiat",
      prenomAr: "غيثة",
      nomAr: "بلخياط",
      dateGregoirienne: "14/10/2002",
      dateHegirienne: "07/08/1423",
      perePrenom: "Saïd",
      merePrenom: "Laila",
      numActe: "312",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B07",
    imageIndex: 2,
    filename: "REG_BEC105_TOME09_ACTE181.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:31",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "09",
    numActe: "181",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Union matrimoniale de droit commun.",
    declarationDetails: "Contrat de mariage répertorié au registre central.",
    piecesJointes: [
      {
        id: "PJ-B07",
        typePiece: "Autorisation Spéciale de Mariage",
        reference: "AUT-TRIB-200",
        dateDelivrance: "2026-06-10",
        autoriteEmettrice: "Tribunal Judiciaire de Fès"
      }
    ],
    operatorA: {
      prenom: "Mustapha",
      nom: "Sabri",
      prenomAr: "مصطفى",
      nomAr: "صبري",
      dateGregoirienne: "10/06/2026",
      dateHegirienne: "24/11/1447",
      perePrenom: "Hamza",
      merePrenom: "Nouzha",
      numActe: "181",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Moustapha",
      nom: "Sabri",
      prenomAr: "مصطفى",
      nomAr: "صبري",
      dateGregoirienne: "10/06/2026",
      dateHegirienne: "24/11/1447",
      perePrenom: "Hamza",
      merePrenom: "Nozha",
      numActe: "181",
      typeActe: "Mariage"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-B08",
    imageIndex: 0,
    filename: "REG_BEC341_TOME15_ACTE313.jpg",
    status: "Brut",
    captureTime: "19/06/2026 10:33",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "15",
    numActe: "313",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le père.",
    declarationDetails: "Régularisation administrative approuvée par l'officier de garde.",
    piecesJointes: [
      {
        id: "PJ-B08",
        typePiece: "Déclaration d'accouchement clinique",
        reference: "CLIN-FES-451",
        dateDelivrance: "2016-11-05",
        autoriteEmettrice: "Maternité Principale"
      }
    ],
    operatorA: {
      prenom: "Salma",
      nom: "Tahiri",
      prenomAr: "سلمى",
      nomAr: "الطاهري",
      dateGregoirienne: "05/11/2016",
      dateHegirienne: "05/02/1438",
      perePrenom: "Brahim",
      merePrenom: "Samira",
      numActe: "313",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Salma",
      nom: "Tayri",
      prenomAr: "سلمى",
      nomAr: "الطاهري",
      dateGregoirienne: "05/11/2016",
      dateHegirienne: "05/02/1438",
      perePrenom: "Brahim",
      merePrenom: "Samyra",
      numActe: "313",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  }
];

export const PRESET_PAGES_POOL_C: PageScan[] = [
  {
    id: "SCAN-2026-C01",
    imageIndex: 0,
    filename: "REG_BEC341_TOME22_ACTE501.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:10",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "22",
    numActe: "501",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le père en personne.",
    declarationDetails: "Conforme aux pièces produites.",
    piecesJointes: [
      {
        id: "PJ-C01",
        typePiece: "Attestation d'accouchement",
        reference: "HOP-C-501",
        dateDelivrance: "2005-02-08",
        autoriteEmettrice: "Maternité de Fès"
      }
    ],
    operatorA: {
      prenom: "Anass",
      nom: "El Fassi",
      prenomAr: "أنس",
      nomAr: "الفاسي",
      dateGregoirienne: "08/02/2005",
      dateHegirienne: "29/12/1425",
      perePrenom: "Hicham",
      merePrenom: "Sanaa",
      numActe: "501",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Anass",
      nom: "Elfassi",
      prenomAr: "أنس",
      nomAr: "الفاسي",
      dateGregoirienne: "08/02/2005",
      dateHegirienne: "20/12/1425",
      perePrenom: "Hicham",
      merePrenom: "Sanaa",
      numActe: "501",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C02",
    imageIndex: 1,
    filename: "REG_BEC220_TOME07_ACTE102.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:12",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "07",
    numActe: "102",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le conjoint.",
    declarationDetails: "Liaison d'acte établie.",
    piecesJointes: [
      {
        id: "PJ-C02",
        typePiece: "Constat de Décès Médical",
        reference: "CERT-MED-C02",
        dateDelivrance: "2026-06-29",
        autoriteEmettrice: "Hôpital Hassan II"
      }
    ],
    operatorA: {
      prenom: "Khadija",
      nom: "Bennani",
      prenomAr: "خديجة",
      nomAr: "بناني",
      dateGregoirienne: "29/06/2026",
      dateHegirienne: "14/12/1447",
      perePrenom: "Ali",
      merePrenom: "Fatima",
      numActe: "102",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Khadidja",
      nom: "Bennani",
      prenomAr: "خديجة",
      nomAr: "بناني",
      dateGregoirienne: "29/06/2026",
      dateHegirienne: "14/12/1447",
      perePrenom: "Ali",
      merePrenom: "Fatima",
      numActe: "102",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C03",
    imageIndex: 2,
    filename: "REG_BEC105_TOME10_ACTE099.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:15",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "10",
    numActe: "099",
    isOpeningPage: true,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 2,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Mariage certifié par Adoul agréé.",
    declarationDetails: "Enregistrement standard en présence de deux témoins.",
    piecesJointes: [
      {
        id: "PJ-C03",
        typePiece: "Contrat de Dot et Certificat Prénuptial",
        reference: "ADL-C03",
        dateDelivrance: "2026-06-12",
        autoriteEmettrice: "Tribunal Judiciaire"
      }
    ],
    operatorA: {
      prenom: "Karim",
      nom: "Mansouri",
      prenomAr: "كريم",
      nomAr: "كريم منصوري",
      dateGregoirienne: "12/06/2026",
      dateHegirienne: "26/11/1447",
      perePrenom: "Driss",
      merePrenom: "Amina",
      numActe: "099",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Karim",
      nom: "Mansouri",
      prenomAr: "كريم",
      nomAr: "كريم منصوري",
      dateGregoirienne: "12/06/2026",
      dateHegirienne: "26/11/1447",
      perePrenom: "Driss",
      merePrenom: "Amina",
      numActe: "099",
      typeActe: "Mariage"
    },
    isConflictResolved: true
  },
  {
    id: "SCAN-2026-C04",
    imageIndex: 0,
    filename: "REG_BEC341_TOME22_ACTE502.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:18",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "22",
    numActe: "502",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le père légal.",
    declarationDetails: "Spécifications de nom approuvées.",
    piecesJointes: [
      {
        id: "PJ-C04",
        typePiece: "Déclaration d'accouchement clinique",
        reference: "CLIN-FES-C04",
        dateDelivrance: "2005-03-18",
        autoriteEmettrice: "Direction Clinique"
      }
    ],
    operatorA: {
      prenom: "Yasmina",
      nom: "Benjelloun",
      prenomAr: "ياسمينة",
      nomAr: "بنجلون",
      dateGregoirienne: "18/03/2005",
      dateHegirienne: "07/02/1426",
      perePrenom: "Adil",
      merePrenom: "Nezha",
      numActe: "502",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Yasmine",
      nom: "Benjelloun",
      prenomAr: "ياسمينة",
      nomAr: "بنجلون",
      dateGregoirienne: "19/03/2005",
      dateHegirienne: "07/02/1426",
      perePrenom: "Adil",
      merePrenom: "Nezha",
      numActe: "502",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C05",
    imageIndex: 1,
    filename: "REG_BEC220_TOME07_ACTE103.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:21",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Décès",
    numBEC: "BEC-220",
    numTome: "07",
    numActe: "103",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le fils.",
    declarationDetails: "Liaison d'acte vérifiée.",
    piecesJointes: [
      {
        id: "PJ-C05",
        typePiece: "Certificat Administratif de Constat",
        reference: "ADM-C05",
        dateDelivrance: "2026-06-30",
        autoriteEmettrice: "Bureau d'Hygiène"
      }
    ],
    operatorA: {
      prenom: "Hamza",
      nom: "Alaoui",
      prenomAr: "حمزة",
      nomAr: "العلوي",
      dateGregoirienne: "30/06/2026",
      dateHegirienne: "15/12/1447",
      perePrenom: "Kamal",
      merePrenom: "Latifa",
      numActe: "103",
      typeActe: "Décès"
    },
    operatorB: {
      prenom: "Hamzah",
      nom: "Alaoui",
      prenomAr: "حمزة",
      nomAr: "العلوي",
      dateGregoirienne: "30/06/2026",
      dateHegirienne: "15/12/1447",
      perePrenom: "Kamal",
      merePrenom: "Letifa",
      numActe: "103",
      typeActe: "Décès"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C06",
    imageIndex: 0,
    filename: "REG_BEC341_TOME22_ACTE503.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:24",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "22",
    numActe: "503",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Présenté par le grand-père paternel.",
    declarationDetails: "Pièces à l'appui enregistrées.",
    piecesJointes: [],
    operatorA: {
      prenom: "Adnane",
      nom: "Bouazza",
      prenomAr: "عدنان",
      nomAr: "بوعزة",
      dateGregoirienne: "05/09/2005",
      dateHegirienne: "01/08/1426",
      perePrenom: "Omar",
      merePrenom: "Meriem",
      numActe: "503",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Adnane",
      nom: "Bouaza",
      prenomAr: "عدنان",
      nomAr: "بوعزة",
      dateGregoirienne: "05/09/2005",
      dateHegirienne: "01/08/1426",
      perePrenom: "Oumar",
      merePrenom: "Meriem",
      numActe: "503",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C07",
    imageIndex: 2,
    filename: "REG_BEC105_TOME10_ACTE100.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:27",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Mariage",
    numBEC: "BEC-105",
    numTome: "10",
    numActe: "100",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 1,
    statutDeclarative: "Union notariale standard.",
    declarationDetails: "Enregistré conformément aux règlements de l'État Civil.",
    piecesJointes: [
      {
        id: "PJ-C07",
        typePiece: "Autorisation Spéciale de Mariage",
        reference: "AUT-TRIB-C07",
        dateDelivrance: "2026-06-15",
        autoriteEmettrice: "Tribunal Judiciaire"
      }
    ],
    operatorA: {
      prenom: "Rachid",
      nom: "Kadiri",
      prenomAr: "رشيد",
      nomAr: "قادري",
      dateGregoirienne: "15/06/2026",
      dateHegirienne: "29/11/1447",
      perePrenom: "Ahmed",
      merePrenom: "Sofia",
      numActe: "100",
      typeActe: "Mariage"
    },
    operatorB: {
      prenom: "Rachid",
      nom: "Rachid",
      prenomAr: "رشيد",
      nomAr: "قادري",
      dateGregoirienne: "15/06/2026",
      dateHegirienne: "29/11/1447",
      perePrenom: "Ahmed",
      merePrenom: "Sofya",
      numActe: "100",
      typeActe: "Mariage"
    },
    isConflictResolved: false
  },
  {
    id: "SCAN-2026-C08",
    imageIndex: 0,
    filename: "REG_BEC341_TOME22_ACTE504.jpg",
    status: "Brut",
    captureTime: "19/06/2026 11:30",
    rotation: 0,
    zoom: 1,
    deskew: false,
    binarized: false,
    typeActe: "Naissance",
    numBEC: "BEC-341",
    numTome: "22",
    numActe: "504",
    isOpeningPage: false,
    isClosingPage: false,
    isBlurred: false,
    isFoldedText: false,
    isStrikethrough: false,
    partsCount: 1,
    isActeBis: false,
    marginalMentionsCount: 0,
    statutDeclarative: "Déclaré par le père.",
    declarationDetails: "Conforme.",
    piecesJointes: [],
    operatorA: {
      prenom: "Malika",
      nom: "El Amrani",
      prenomAr: "مليكة",
      nomAr: "العمراني",
      dateGregoirienne: "20/12/2018",
      dateHegirienne: "12/04/1440",
      perePrenom: "Yassine",
      merePrenom: "Hind",
      numActe: "504",
      typeActe: "Naissance"
    },
    operatorB: {
      prenom: "Malika",
      nom: "Elamrani",
      prenomAr: "مليكة",
      nomAr: "العمراني",
      dateGregoirienne: "20/12/2018",
      dateHegirienne: "12/04/1440",
      perePrenom: "Yassine",
      merePrenom: "Hinde",
      numActe: "504",
      typeActe: "Naissance"
    },
    isConflictResolved: false
  }
];

export const getPresetPool = (index: number): PageScan[] => {
  const pools = [PRESET_PAGES, PRESET_PAGES_POOL_B, PRESET_PAGES_POOL_C];
  return pools[index % pools.length];
};

