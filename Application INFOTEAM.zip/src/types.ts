/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ActeType = 'Naissance' | 'Décès' | 'Mariage' | 'Divorce';

export interface PageScan {
  id: string;
  imageIndex: number; // reference mock register page image
  filename: string;
  status: 'Brut' | 'Préparé' | 'Identifié' | 'DoubleSaisie' | 'Indexé';
  captureTime: string;
  
  // Step 2 Actions / Status
  rotation: number; // 0, 90, 180, 270
  zoom: number; // scale
  deskew: boolean;
  binarized: boolean; // B&W net
  
  // Step 2 Metadata
  typeActe: ActeType;
  numBEC: string;
  numTome: string;
  numActe: string;
  isOpeningPage: boolean;
  isClosingPage: boolean;
  anneeEnregistrement?: string;
  
  // Step 2 Quality Checklist
  isBlurred: boolean; // Image floue
  isFoldedText: boolean; // Texte masqué/pliure (Twya)
  isStrikethrough: boolean; // Acte barré
  partsCount: number; // 1, 2, or more
  
  // Step 3 Identification Central (RC) & Documents (RP)
  isActeBis: boolean;
  marginalMentionsCount: number;
  statutDeclarative: string;
  declarationDetails: string;
  piecesJointes: PieceJointe[];

  // Step 4 Verification (Double Saisie status)
  operatorA: OperatorSaisieData;
  operatorB: OperatorSaisieData;
  supervisorCorrection?: OperatorSaisieData; // Resolved conflicting data
  isConflictResolved: boolean;
  customPreview?: string; // real-time camera captured frame
  _source_file?: string;
  _uid?: string;
  
  // Custom tracking for specific corrected acts
  wasRescanned?: boolean;
  isRescanApproved?: boolean;
}

export interface PieceJointe {
  id: string;
  typePiece: string; // "Jugement de Tribunal", "Jugement Rectificatif", "Attestation de Naissance"
  reference: string;
  dateDelivrance: string;
  autoriteEmettrice: string;
}

export interface OperatorSaisieData {
  prenom: string;
  nom: string;
  prenomAr?: string;
  nomAr?: string;
  dateGregoirienne: string;
  dateHegirienne: string;
  perePrenom: string;
  merePrenom: string;
  numActe?: string;
  typeActe?: ActeType;
}

export interface StatInfo {
  iaErrorRate: number; // percentage
  totalIndexed: number;
  byBEC: Record<string, number>;
  foldedDetected: number; // Twya cases
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  username: string;
  role: 'Administrateur' | 'AgentSaisie';
  status: 'Actif' | 'Suspendu';
  dailyQuota: number;
}

export interface WorkLog {
  id: string;
  agentId: string;
  agentName: string;
  timestamp: string;
  action: string;
  lotId?: string;
  count: number;
  status: 'Approuvé' | 'En attente';
}

