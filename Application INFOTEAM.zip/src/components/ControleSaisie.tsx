/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, FileText, ChevronLeft, ChevronRight, CheckSquare, 
  Square, ShieldAlert, Sparkles, Filter, Database, Calendar, UserCheck,
  ZoomIn, ZoomOut, RotateCw, Upload
} from 'lucide-react';
import { PageScan } from '../types';

interface ControleSaisieProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidateStep6: () => void;
}

export default function ControleSaisie({
  scannedPages,
  setScannedPages,
  onValidateStep6,
}: ControleSaisieProps) {
  const [selectedPageIndex, setSelectedPageIndex] = useState(0);
  const [successMsg, setSuccessMsg] = useState(false);
  
  // Direct live editing states
  const [isEditing, setIsEditing] = useState(false);
  const [editNom, setEditNom] = useState('');
  const [editNomAr, setEditNomAr] = useState('');
  const [editPrenom, setEditPrenom] = useState('');
  const [editPrenomAr, setEditPrenomAr] = useState('');
  const [editDateGreg, setEditDateGreg] = useState('');
  const [editDateHeg, setEditDateHeg] = useState('');
  const [editPere, setEditPere] = useState('');
  const [editMere, setEditMere] = useState('');

  // Compliance checklists state per page id
  const [checklist, setChecklist] = useState<Record<string, {
    spelling: boolean;
    calendar: boolean;
    regional: boolean;
    annexes: boolean;
  }>>({});

  const page = scannedPages[selectedPageIndex] || null;

  // Sync editing fields with active data on page change
  useEffect(() => {
    if (page) {
      const active = page.supervisorCorrection || page.operatorA;
      setEditNom(active.nom || '');
      setEditNomAr(active.nomAr || '');
      setEditPrenom(active.prenom || '');
      setEditPrenomAr(active.prenomAr || '');
      setEditDateGreg(active.dateGregoirienne || '');
      setEditDateHeg(active.dateHegirienne || '');
      setEditPere(active.perePrenom || '');
      setEditMere(active.merePrenom || '');
    }
    setIsEditing(false);
  }, [selectedPageIndex, page]);

  const handleSaveEdit = () => {
    if (!page) return;
    setScannedPages(prev => prev.map(p => {
      if (p.id === page.id) {
        const currentCorrection = p.supervisorCorrection || p.operatorA || {};
        return {
          ...p,
          supervisorCorrection: {
            ...currentCorrection,
            nom: editNom,
            nomAr: editNomAr,
            prenom: editPrenom,
            prenomAr: editPrenomAr,
            dateGregoirienne: editDateGreg,
            dateHegirienne: editDateHeg,
            perePrenom: editPere,
            merePrenom: editMere,
          }
        };
      }
      return p;
    }));
    setIsEditing(false);
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 2000);
  };

  const handleZoom = (amount: number) => {
    if (!page) return;
    setScannedPages(prev => prev.map(p => {
      if (p.id === page.id) {
        const currentZoom = p.zoom ?? 1;
        const nextZoom = Math.min(Math.max(currentZoom + amount, 0.8), 2.5);
        return { ...p, zoom: parseFloat(nextZoom.toFixed(1)) };
      }
      return p;
    }));
  };

  const handleRotation = () => {
    if (!page) return;
    setScannedPages(prev => prev.map(p => {
      if (p.id === page.id) {
        const currentRotation = p.rotation ?? 0;
        const nextRot = (currentRotation + 90) % 360;
        return { ...p, rotation: nextRot };
      }
      return p;
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0] && page) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        setScannedPages(prev => prev.map(p => {
          if (p.id === page.id) {
            return {
              ...p,
              customPreview: result,
              filename: files[0].name
            };
          }
          return p;
        }));
        setSuccessMsg(true);
        setTimeout(() => setSuccessMsg(false), 2000);
      };
      reader.readAsDataURL(files[0]);
    }
  };

  // Initialize checklists
  useEffect(() => {
    const initial: typeof checklist = {};
    scannedPages.forEach(p => {
      initial[p.id] = {
        spelling: false, // Start un-checked to require user processing
        calendar: false,
        regional: false,
        annexes: false,
      };
    });
    setChecklist(prev => ({ ...initial, ...prev }));
  }, [scannedPages]);

  if (!page) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center border border-stone-200">
        <p className="font-sans text-sm text-stone-500">Aucun acte chargé pour le contrôle de saisie.</p>
      </div>
    );
  }

  const currentPageChecklist = checklist[page.id] || {
    spelling: false,
    calendar: false,
    regional: false,
    annexes: false,
  };

  const toggleCheck = (field: 'spelling' | 'calendar' | 'regional' | 'annexes') => {
    setChecklist(prev => {
      const current = prev[page.id] || {
        spelling: true,
        calendar: true,
        regional: true,
        annexes: true,
      };
      return {
        ...prev,
        [page.id]: {
          ...current,
          [field]: !current[field],
        }
      };
    });
  };

  const checkAllCurrentPage = () => {
    setChecklist(prev => ({
      ...prev,
      [page.id]: {
        spelling: true,
        calendar: true,
        regional: true,
        annexes: true,
      }
    }));
  };

  const checkAllLot = () => {
    setChecklist(prev => {
      const updated = { ...prev };
      scannedPages.forEach(p => {
        updated[p.id] = {
          spelling: true,
          calendar: true,
          regional: true,
          annexes: true,
        };
      });
      return updated;
    });
  };

  const activeData = page.supervisorCorrection || page.operatorA;

  // Check if ALL pages are fully audited
  const isEveryPageCompliant = scannedPages.every(p => {
    const c = checklist[p.id];
    return c && c.spelling && c.calendar && c.regional && c.annexes;
  });

  return (
    <div className="space-y-6" id="controle-saisie-stage">
      
      {/* Informational Guidance Banner */}
      <div className="bg-stone-900 text-stone-100 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h4 className="font-display font-medium text-xs md:text-sm text-amber-400 flex items-center gap-1.5 uppercase">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            Contrôle Qualité de Saisie Nationale d'État Civil 🛡️
          </h4>
          <p className="text-[10px] md:text-xs text-stone-300 mt-1 max-w-2xl">
            Cette étape de contrôle ultime valide la cohérence des transcriptions nominatives (français et arabe) et l'exactitude des pièces jointes réglementaires avant de déclencher la signature du lot.
          </p>
        </div>
        <div className="shrink-0 text-right bg-stone-800 p-2.5 rounded-lg border border-stone-700">
          <span className="text-[9px] font-mono font-bold text-stone-400 block">STATUT DE L'AUDIT</span>
          <span className="text-xs font-sans font-black text-amber-400">
            {isEveryPageCompliant ? "LOT 100% AUDITÉ ✔" : "AUDIT DU LOT EN COURS"}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Document Preview card & details */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex justify-between items-center border-b border-stone-100 pb-3">
            <h4 className="font-display font-bold text-stone-900 text-sm flex items-center gap-2">
              <FileText className="w-4 h-4 text-rose-800" />
              Champs de Saisie Consolidés — Évaluation
            </h4>
            <div className="flex items-center gap-2">
              {isEditing ? (
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="py-1 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10.5px] rounded-lg shadow-xs transition-all cursor-pointer"
                  >
                    💾 Enregistrer
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="py-1 px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-[10.5px] rounded-lg border border-stone-300 transition-all cursor-pointer"
                  >
                    Annuler
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="py-1 px-3 bg-rose-50 hover:bg-rose-100 text-rose-850 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 transition-all cursor-pointer"
                  id="btn-edit-acte-controle"
                >
                  ✏️ Modifier l'Acte
                </button>
              )}
              <span className="text-[10px] bg-amber-50 font-mono text-amber-800 border border-amber-200 px-2 py-1 rounded font-bold">
                ID Acte: {page.numActe}
              </span>
            </div>
          </div>

          {isEditing ? (
            <div className="grid grid-cols-2 gap-4 text-xs font-sans p-2 bg-stone-50 rounded-2xl border border-stone-200">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">NOM DE FAMILLE (FR)</label>
                <input
                  type="text"
                  value={editNom}
                  onChange={(e) => setEditNom(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">NOM DE FAMILLE (AR / النسب)</label>
                <input
                  type="text"
                  value={editNomAr}
                  onChange={(e) => setEditNomAr(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold text-right focus:outline-hidden focus:border-rose-500"
                  dir="rtl"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">PRÉNOMS (FR)</label>
                <input
                  type="text"
                  value={editPrenom}
                  onChange={(e) => setEditPrenom(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">PRÉNOMS (AR / الاسم الأول)</label>
                <input
                  type="text"
                  value={editPrenomAr}
                  onChange={(e) => setEditPrenomAr(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold text-right focus:outline-hidden focus:border-rose-500"
                  dir="rtl"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">DATE GRÉGORIENNE</label>
                <input
                  type="text"
                  value={editDateGreg}
                  onChange={(e) => setEditDateGreg(e.target.value)}
                  placeholder="JJ/MM/AAAA"
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">DATE HÉGIRIENNE</label>
                <input
                  type="text"
                  value={editDateHeg}
                  onChange={(e) => setEditDateHeg(e.target.value)}
                  placeholder="JJ/MM/AAAA"
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">PRÉNOM DU PÈRE</label>
                <input
                  type="text"
                  value={editPere}
                  onChange={(e) => setEditPere(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-600 block uppercase">PRÉNOM DE LA MÈRE</label>
                <input
                  type="text"
                  value={editMere}
                  onChange={(e) => setEditMere(e.target.value)}
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-950 font-bold focus:outline-hidden focus:border-rose-500"
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 text-xs font-sans">
              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">NOM DE FAMILLE / النسب</span>
                <span className="text-stone-900 font-bold text-sm block">{activeData.nom || '—'}</span>
                <span className="text-stone-500 font-mono text-[10px] block">{activeData.nomAr || '—'}</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">PRÉNOMS / الاسم الأول</span>
                <span className="text-stone-900 font-bold text-sm block">{activeData.prenom || '—'}</span>
                <span className="text-stone-500 font-mono text-[10px] block">{activeData.prenomAr || '—'}</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">DATE GRÉGORIENNE</span>
                <span className="text-stone-900 font-bold text-xs flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                  {activeData.dateGregoirienne || '—'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">DATE HÉGIRIENNE</span>
                <span className="text-stone-900 font-bold text-xs flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                  {activeData.dateHegirienne || '—'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">NOM DU PÈRE / اسم الأب</span>
                <span className="text-stone-900 font-bold text-sm block">{activeData.perePrenom || '—'}</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                <span className="text-[10px] font-mono text-stone-400 block font-bold">NOM DE LA MÈRE / اسم الأم</span>
                <span className="text-stone-900 font-bold text-sm block">{activeData.merePrenom || '—'}</span>
              </div>
            </div>
          )}

          <div className="border border-stone-150 p-4 rounded-2xl bg-stone-50 hover:bg-stone-100/50 transition-all">
            <h5 className="font-display font-bold text-xs text-stone-800 mb-2 flex items-center gap-1.5">
              <Database className="w-4 h-4 text-stone-600 shrink-0" />
              Répertoire National & Pièces Administratives (RP)
            </h5>
            <div className="space-y-2 text-[10.5px] font-sans">
              <div className="flex justify-between border-b border-stone-200/60 pb-1.5">
                <span className="text-stone-500">Bureau État Civil (BEC)</span>
                <span className="text-stone-900 font-semibold">{page.numBEC}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200/60 pb-1.5">
                <span className="text-stone-500">TOME du Registre (RP)</span>
                <span className="text-stone-900 font-semibold">Tome n° {page.numTome}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Pièces d'Archives jointes</span>
                <span className="text-stone-900 font-bold">
                  {page.piecesJointes.length > 0 
                    ? `${page.piecesJointes[0].typePiece} (${page.piecesJointes[0].reference})` 
                    : 'Aucun document de référence'
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Visualisation de l'Acte Original */}
          <div className="border border-stone-150 p-4 rounded-2xl bg-stone-50 hover:bg-stone-100/50 transition-all space-y-2">
            <h5 className="font-display font-bold text-xs text-stone-800 flex justify-between items-center">
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-rose-800 shrink-0" />
                📂 Image du Registre Original
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-stone-400 mr-2 max-w-[150px] truncate" title={page.filename}>
                  FILE: {page.filename}
                </span>
                <div className="flex items-center gap-1 bg-white p-1 rounded-md border border-stone-200">
                  <label className="p-1 px-2 hover:bg-stone-100 rounded text-stone-700 cursor-pointer flex items-center gap-1 text-[10px] font-sans font-bold text-rose-800" title="Importer la vraie photo de l'acte">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <Upload className="w-3.5 h-3.5 text-rose-800" />
                    <span>Remplacer la photo</span>
                  </label>
                  <div className="w-[1px] h-4 bg-stone-200" />
                  <button
                    type="button"
                    onClick={() => handleZoom(0.1)}
                    className="p-1 hover:bg-stone-100 rounded text-stone-700 cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleZoom(-0.1)}
                    className="p-1 hover:bg-stone-100 rounded text-stone-700 cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={handleRotation}
                    className="p-1 hover:bg-stone-100 rounded text-stone-700 cursor-pointer"
                    title="Faire pivoter"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </h5>
            
            <div className="h-[280px] border border-stone-300 rounded-lg overflow-hidden relative shadow-inner bg-[#faf4ea] p-4 text-xs select-none flex items-center justify-center">
              {page.customPreview ? (
                <div 
                  style={{
                    transform: `scale(${page.zoom || 1})`,
                    transition: 'all 0.2s ease-in-out',
                  }}
                  className={`w-full h-full flex items-center justify-center ${
                    page.rotation === 90 ? 'rotate-90' :
                    page.rotation === 180 ? 'rotate-180' :
                    page.rotation === 270 ? 'rotate-270' : 'rotate-0'
                  }`}
                >
                  <img 
                    src={page.customPreview} 
                    className="max-h-full max-w-full object-contain mx-auto" 
                    alt="Scan Registre" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : (
                <div 
                  style={{
                    transform: `scale(${page.zoom || 1})`,
                    transition: 'all 0.2s ease-in-out',
                  }}
                  className={`w-full h-full flex flex-col justify-between font-serif ${
                    page.rotation === 90 ? 'rotate-90' :
                    page.rotation === 180 ? 'rotate-180' :
                    page.rotation === 270 ? 'rotate-270' : 'rotate-0'
                  }`}
                >
                  <div className="flex justify-between items-start border-b border-[#c8b495] pb-1 bg-white/20 p-1 rounded text-[9px] text-stone-600">
                    <div>
                      <strong>ROYAUME DU MAROC</strong><br />
                      MUNICIPALITÉ DE FÈS
                    </div>
                    <div className="text-right">
                      <strong>BEC</strong><br />
                      {page.numBEC}
                    </div>
                  </div>
                  
                  <div className="text-center font-bold text-amber-900 my-2">
                    رسم الولادة رقم {page.numActe}
                  </div>
                  
                  <div className="text-right font-sans text-stone-700 text-[10px]">
                    الاسم الكامل: {page.operatorA.prenomAr} {page.operatorA.nomAr}
                  </div>
                  
                  <div className="flex justify-between items-center text-[8px] text-stone-400 border-t border-[#decbb0] pt-1">
                    <span>ANNEXE: OK</span>
                    <span>المفوض ببلدية فاس</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Compliance Checklist */}
        <div className="lg:col-span-5 bg-stone-50 p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <div className="border-b border-stone-200 pb-2">
              <h4 className="font-display font-bold text-stone-900 text-sm flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                Liste de Contrôle Conformité (Page {selectedPageIndex + 1})
              </h4>
              <p className="text-[10px] text-stone-500 mt-0.5 pb-2">
                Cochez ou décochez les points de contrôle après confrontation avec l'acte.
              </p>
              
              <div className="flex gap-2 pt-1 border-t border-stone-200/50">
                <button
                  type="button"
                  onClick={checkAllCurrentPage}
                  className="flex-1 py-1 px-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-[9.5px] font-bold text-emerald-800 transition-all cursor-pointer flex items-center justify-center gap-1"
                  id="btn-confirm-all-page"
                >
                  Tout cocher (Cette Page)
                </button>
                <button
                  type="button"
                  onClick={checkAllLot}
                  className="flex-1 py-1 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[9.5px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                  id="btn-confirm-all-lot"
                >
                  ⚡ Tout cocher (Tout le Lot)
                </button>
              </div>
            </div>

            <div className="space-y-3 font-sans">
              
              {/* Check 1 */}
              <button
                type="button"
                onClick={() => toggleCheck('spelling')}
                className="w-full text-left bg-white p-3.5 rounded-xl border border-stone-200 hover:border-emerald-500 hover:bg-emerald-50/10 transition-all flex items-start gap-3"
              >
                <div className="mt-0.5 text-emerald-700 shrink-0">
                  {currentPageChecklist.spelling ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-50" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-300" />
                  )}
                </div>
                <div>
                  <h5 className="font-bold text-xs text-stone-900">Orthographie & Translittération</h5>
                  <p className="text-[10px] text-stone-500 leading-normal mt-0.5">
                    Les noms et prénoms traduits de l'arabe sont exempts de toute typo d'orthographe (par exemple, "Khaloui" vs "Khalouy" harmonisé).
                  </p>
                </div>
              </button>

              {/* Check 2 */}
              <button
                type="button"
                onClick={() => toggleCheck('calendar')}
                className="w-full text-left bg-white p-3.5 rounded-xl border border-stone-200 hover:border-emerald-500 hover:bg-emerald-50/10 transition-all flex items-start gap-3"
              >
                <div className="mt-0.5 text-emerald-700 shrink-0">
                  {currentPageChecklist.calendar ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-50" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-300" />
                  )}
                </div>
                <div>
                  <h5 className="font-bold text-xs text-stone-900">Calendrier & Hégirienne</h5>
                  <p className="text-[10px] text-stone-500 leading-normal mt-0.5">
                    Vérification que la date grégorienne correspond bien historiquement à la date hégirienne déclarée sur l'album original.
                  </p>
                </div>
              </button>

              {/* Check 3 */}
              <button
                type="button"
                onClick={() => toggleCheck('regional')}
                className="w-full text-left bg-white p-3.5 rounded-xl border border-stone-200 hover:border-emerald-500 hover:bg-emerald-50/10 transition-all flex items-start gap-3"
              >
                <div className="mt-0.5 text-emerald-700 shrink-0">
                  {currentPageChecklist.regional ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-50" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-300" />
                  )}
                </div>
                <div>
                  <h5 className="font-bold text-xs text-stone-900">Identification Régionale</h5>
                  <p className="text-[10px] text-stone-500 leading-normal mt-0.5">
                    Exactitude du rattachement cantonal, bureau (BEC Fès) et numéro d'acte indexé.
                  </p>
                </div>
              </button>

              {/* Check 4 */}
              <button
                type="button"
                onClick={() => toggleCheck('annexes')}
                className="w-full text-left bg-white p-3.5 rounded-xl border border-stone-200 hover:border-emerald-500 hover:bg-emerald-50/10 transition-all flex items-start gap-3"
              >
                <div className="mt-0.5 text-emerald-700 shrink-0">
                  {currentPageChecklist.annexes ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-50" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-300" />
                  )}
                </div>
                <div>
                  <h5 className="font-bold text-xs text-stone-900">Pièces Administratives d'Appui</h5>
                  <p className="text-[10px] text-stone-500 leading-normal mt-0.5">
                    Les références officielles de l'attestation d'accouchement ou déclarations juridiques de maternité concordent.
                  </p>
                </div>
              </button>

            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-stone-200 bg-stone-100 p-3 rounded-2xl">
            <span className="text-[10px] text-stone-500 text-center block font-sans font-medium">
              Chaque acte doit être 100% conforme pour certifier le lot.
            </span>
          </div>

        </div>

      </div>

      {/* 🔟 Navigation des Pages Traitées */}
      <div className="bg-white p-4 rounded-2xl border-2 border-stone-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4 my-2 select-none">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-yellow-600 rounded-full animate-pulse" />
          <span className="text-xs font-bold text-stone-700 uppercase">
            Contrôle Saisie : Document {selectedPageIndex + 1} SÙR {scannedPages.length}
          </span>
        </div>

        {/* List of numbered buttons 1 to 10 */}
        <div className="flex flex-wrap gap-1.5 items-center justify-center">
          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.max(0, prev - 1))}
            disabled={selectedPageIndex === 0}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Préc.
          </button>

          {scannedPages.map((p, idx) => {
            const audit = checklist[p.id];
            const isAuditedPage = audit && audit.spelling && audit.calendar && audit.regional && audit.annexes;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPageIndex(idx)}
                className={`py-1.5 px-3 rounded-lg font-mono text-xs font-bold transition-all border flex items-center gap-1.5 relative ${
                  selectedPageIndex === idx 
                    ? "bg-stone-900 text-white border-stone-900 shadow-sm font-black scale-105" 
                    : "bg-white text-stone-600 border-stone-200 hover:bg-stone-50"
                }`}
              >
                <span>{idx + 1}</span>
                {isAuditedPage ? (
                  <span className="text-emerald-600 font-extrabold text-xs" title="Vérifié">✓</span>
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                )}
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.min(scannedPages.length - 1, prev + 1))}
            disabled={selectedPageIndex === scannedPages.length - 1}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
          >
            Suiv. <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* STEP COMPLIANCE SUBMISSION */}
      <div className="flex justify-between items-center pt-4 border-t border-stone-200 flex-wrap gap-4">
        
        <div className="text-xs text-stone-500 font-sans font-medium">
          {!isEveryPageCompliant && (
            <span className="text-amber-800 font-bold bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-full block">
              ⚠️ Attention : Veuillez cocher tous les points de contrôle pour chaque acte avant de pouvoir valider.
            </span>
          )}
          {isEveryPageCompliant && (
            <span className="text-emerald-850 font-bold bg-emerald-50 border border-emerald-100 px-3 py-1.5 rounded-full block">
              ✔ Tous les actes de ce lot de l'État Civil ont été audités avec succès !
            </span>
          )}
        </div>

        <button
          onClick={() => {
            if (!isEveryPageCompliant) {
              alert("🚨 Validation Impossible : Vous devez vérifier et certifier tous les points de contrôle de saisie pour l'ensemble des actes du lot.");
              return;
            }
            onValidateStep6();
          }}
          className={`px-8 py-4 font-display font-bold text-sm rounded-2xl shadow-sm transition-all flex items-center gap-2 shrink-0 ${
            !isEveryPageCompliant
              ? "bg-stone-200 text-stone-400 border border-stone-300 cursor-not-allowed opacity-50"
              : "bg-emerald-700 hover:bg-emerald-800 text-white cursor-pointer"
          }`}
          id="btn-validate-step-6"
        >
          <span>Certifier Saisie & Aller à la Validation Globale du Lot ➡️</span>
        </button>

      </div>

    </div>
  );
}
