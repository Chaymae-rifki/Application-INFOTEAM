/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Landmark, FileText, Heart, AlertTriangle, BookOpen, MessageSquare, 
  Keyboard, RefreshCw, Layers, Users, Settings, UserCheck, List, 
  ChevronLeft, ChevronRight, RotateCw, ZoomIn, ZoomOut, Check, ArrowRight
} from 'lucide-react';
import { PageScan, PieceJointe } from '../types';

// Import our highly detailed modular sub-components
import Messagerie from './registry/Messagerie';
import GestionAffectations from './registry/GestionAffectations';
import GestionUtilisateurs from './registry/GestionUtilisateurs';
import GestionListes from './registry/GestionListes';
import ActFormNaissance from './registry/ActFormNaissance';
import ActFormDeces from './registry/ActFormDeces';
import FormPopf from './registry/FormPopf';

interface RegistryDoubleEntryProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidateStep3: () => void;
  isStep4Unlocked: boolean;
}

type MainView = 
  | 'naissances' | 'deces' | 'mariages' | 'divorces' | 'po-pf' | 'rejets'
  | 'messagerie' | 'clavier' | 'changer-lot'
  | 'affectations' | 'utilisateurs' | 'parametrage' | 'officier' | 'listes';

export default function RegistryDoubleEntry({
  scannedPages,
  setScannedPages,
  onValidateStep3,
  isStep4Unlocked,
}: RegistryDoubleEntryProps) {
  
  // High fidelity Windows emulated state
  const [currentView, setCurrentView] = useState<MainView>('naissances');
  const [selectedPageIndex, setSelectedPageIndex] = useState(0);

  // Custom states for modal/notification triggers replacing browser alert/confirm
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [customNotification, setCustomNotification] = useState<string | null>(null);

  // Keyboard typing buffer for interactive virtual keyboard
  const [keyboardBuffer, setKeyboardBuffer] = useState('');

  // Saisie options state simulation
  const [clavierLanguage, setClavierLanguage] = useState<'AR' | 'FR'>('AR');

  // Reset page index when switching active tab types so we don't go out of bounds
  useEffect(() => {
    setSelectedPageIndex(0);
  }, [currentView]);

  // Auto-dismiss custom notification after 3.5 seconds
  useEffect(() => {
    if (customNotification) {
      const timer = setTimeout(() => {
        setCustomNotification(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [customNotification]);

  // Filter pages according to the active tab view type
  const getFilteredPages = () => {
    // Normalizing view types to match page.typeActe
    if (currentView === 'naissances') {
      return scannedPages.filter(p => {
        const t = (p.typeActe || '').toLowerCase();
        return t.startsWith('naissance') || t === 'nouveau';
      });
    }
    if (currentView === 'deces') {
      return scannedPages.filter(p => {
        const t = (p.typeActe || '').toLowerCase();
        return t.startsWith('décès') || t.startsWith('deces');
      });
    }
    if (currentView === 'mariages') {
      return scannedPages.filter(p => {
        const t = (p.typeActe || '').toLowerCase();
        return t.startsWith('mariage');
      });
    }
    if (currentView === 'divorces') {
      return scannedPages.filter(p => {
        const t = (p.typeActe || '').toLowerCase();
        return t.startsWith('divorce');
      });
    }
    
    // Default to all for lists or general screens
    return scannedPages;
  };

  const filteredPages = getFilteredPages();
  const page = filteredPages[selectedPageIndex] || filteredPages[0] || null;

  if (scannedPages.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-12 text-center border-2 border-slate-200 shadow-clay-sm select-none">
        <Landmark className="w-16 h-16 text-slate-300 mx-auto mb-4 animate-bounce" />
        <h4 className="font-display font-black text-slate-800 text-lg">Aucun registre numérisé disponible</h4>
        <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-2">
          Veuillez retourner à l'étape 1 ou 2 pour capturer et corriger les pages de registre d'abord.
        </p>
      </div>
    );
  }

  const updatePage = (fields: Partial<PageScan>) => {
    if (!page) return;
    setScannedPages(prev => prev.map((p) => {
      if (p.id === page.id) {
        return { ...p, ...fields };
      }
      return p;
    }));
  };

  // State-changing validation handler for individual acts
  const handleValidateCurrentPage = () => {
    if (!page) return;
    
    // Mark this page as verified/validated
    setScannedPages(prev => prev.map(p => {
      if (p.id === page.id) {
        return { 
          ...p, 
          status: 'Indexé', 
          isConflictResolved: true 
        };
      }
      return p;
    }));
    
    // Beautiful alert
    setCustomNotification(`🎉 Acte n° ${page.numActe} (${page.typeActe}) validé avec succès en base de données !`);
    
    // Go to next act if there is one in the current category
    if (selectedPageIndex < filteredPages.length - 1) {
      setSelectedPageIndex(prev => prev + 1);
    }
  };

  // Rotation and zoom simulation for current document viewer
  const handleRotation = () => {
    if (!page) return;
    const nextRot = (page.rotation + 90) % 360;
    updatePage({ rotation: nextRot });
  };

  const handleZoom = (amount: number) => {
    if (!page) return;
    const nextZoom = Math.min(Math.max(page.zoom + amount, 0.8), 2.0);
    updatePage({ zoom: parseFloat(nextZoom.toFixed(1)) });
  };

  // Simulated Virtual Arabic/French keyboard layout keys
  const keysAr = ['أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];
  const keysFr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

  return (
    <div className="space-y-4 relative" id="registry-double-entry-retro-window">
      
      {/* State-based custom Notification Banner */}
      {customNotification && (
        <div className="bg-[#e0f2fe] border-2 border-[#0284c7] text-[#0369a1] px-4 py-2.5 rounded-xl text-xs font-sans font-bold flex justify-between items-center animate-bounce shadow-md z-50">
          <div className="flex items-center gap-2">
            <span>ℹ️ Info:</span>
            <span>{customNotification}</span>
          </div>
          <button 
            onClick={() => setCustomNotification(null)}
            className="text-[#0369a1] hover:text-[#0c4a6e] font-black cursor-pointer px-1.5"
          >
            ✕
          </button>
        </div>
      )}
      
      {/* 💻 Chromium emulated Windows classic frame wrapper */}
      <div className="bg-[#f1f2f6] border-2 border-stone-400 rounded-xl overflow-hidden shadow-clay-md select-none">
        
        {/* Windows title chrome */}
        <div className="bg-[#2a2a2a] p-2 px-3 text-white flex items-center justify-between border-b border-stone-500">
          <div className="flex items-center gap-2">
            <span className="text-sm">💻</span>
            <span className="font-mono text-[11px] font-bold text-stone-200">
              Contrôle des Actes d'État Civil - InfoTeam 1 v1.2 (Saisie active: {page?.typeActe || 'Aucun'})
            </span>
          </div>

          <div className="flex gap-1">
            <span className="w-3.5 h-3.5 rounded bg-amber-400/80 cursor-pointer block border border-amber-500/50" />
            <span className="w-3.5 h-3.5 rounded bg-emerald-500/80 cursor-pointer block border border-emerald-600/50" />
            <span className="w-3.5 h-3.5 rounded bg-rose-500/80 cursor-pointer block border border-rose-650/50" />
          </div>
        </div>

        {/* Windows Body split workspace */}
        <div className="grid grid-cols-1 xl:grid-cols-12 min-h-[580px] text-stone-800">
          
          {/* 1. LEFT SIDE DEKSTOP NAVIGATION MENU (2.5 cols) */}
          <div className="xl:col-span-3 bg-[#e2e8f0] p-3 border-r border-stone-300 flex flex-col justify-between gap-4 font-sans select-none">
            <div className="space-y-4">
              
              {/* Category: Contrôle des Actes */}
              <div className="space-y-1">
                <span className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest bg-stone-300 py-0.5 px-2 rounded-sm mb-1.5 shadow-clay-inner border-b border-stone-400">
                  📁 Contrôle des Actes
                </span>
                
                <button
                  type="button"
                  onClick={() => setCurrentView('naissances')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'naissances' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-naissances"
                >
                  <Landmark className="w-3.5 h-3.5" /> Naissances (الولادات)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('deces')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'deces' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-deces"
                >
                  <FileText className="w-3.5 h-3.5" /> Décès (الوفيات)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('mariages')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'mariages' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-mariages"
                >
                  <Heart className="w-3.5 h-3.5 text-stone-505" /> Mariages (عقود الزواج)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('divorces')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'divorces' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-divorces"
                >
                  <AlertTriangle className="w-3.5 h-3.5" /> Divorces (عقود الطلاق)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCurrentView('po-pf');
                    updatePage({ isOpeningPage: true });
                  }}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'po-pf' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-po-pf"
                >
                  <BookOpen className="w-3.5 h-3.5" /> Saisie PO-PF (صفحات الدفاتر)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('rejets')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'rejets' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md scale-102" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-rejets"
                >
                  <AlertTriangle className="w-3.5 h-3.5" /> Traitement Rejets (المرفوضات)
                </button>
              </div>

              {/* Category: Commun */}
              <div className="space-y-1">
                <span className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest bg-stone-300 py-0.5 px-2 rounded-sm mb-1.5 shadow-clay-inner border-b border-stone-400">
                  💬 Commun
                </span>

                <button
                  type="button"
                  onClick={() => setCurrentView('messagerie')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'messagerie' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-messagerie"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> Messagerie (البريد الإداري)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('clavier')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'clavier' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-clavier"
                >
                  <Keyboard className="w-3.5 h-3.5" /> Clavier (لوحة الأحرف بمساعدة)
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('changer-lot')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'changer-lot' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300 hover:text-stone-900"
                  }`}
                  id="retro-nav-changer-lot"
                >
                  <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" /> Changer LOT (تغيير الدفتر)
                </button>
              </div>

              {/* Category: Suivi & Administration */}
              <div className="space-y-1">
                <span className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest bg-stone-300 py-0.5 px-2 rounded-sm mb-1.5 shadow-clay-inner border-b border-stone-400">
                  ⚙️ Suivi & Administration
                </span>

                <button
                  type="button"
                  onClick={() => setCurrentView('affectations')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'affectations' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300"
                  }`}
                  id="retro-nav-affectations"
                >
                  <Layers className="w-3.5 h-3.5" /> Gestion Affectations
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('utilisateurs')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'utilisateurs' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300"
                  }`}
                  id="retro-nav-utilisateurs"
                >
                  <Users className="w-3.5 h-3.5" /> Gestion Utilisateurs
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('officier')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'officier' 
                      ? "bg-[#ea580c] text-white font-bold shadow-md" 
                      : "text-stone-700 hover:bg-stone-300"
                  }`}
                  id="retro-nav-officier"
                >
                  <UserCheck className="w-3.5 h-3.5" /> Officiers d'État Civil
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('listes')}
                  className={`w-full text-left py-1.5 px-3 rounded flex items-center gap-2.5 transition-all text-xs font-semibold ${
                    currentView === 'listes' 
                      ? "bg-[#ea580c] text-white font-bold" 
                      : "text-stone-700 hover:bg-stone-300"
                  }`}
                  id="retro-nav-listes"
                >
                  <List className="w-3.5 h-3.5" /> Gestion des Listes
                </button>
              </div>

            </div>

            {/* Quick operators tag info */}
            <div className="bg-stone-100 p-2 rounded.5 border border-stone-250 text-[10px] text-stone-500 font-mono space-y-1 shadow-clay-inner">
              <span className="block text-stone-600 font-bold">👤 Opérateur connecté:</span>
              <span className="block font-bold mt-0.5">chaymae.r</span>
              <span className="block text-[9px] text-[#22c55e] font-black">● Serveur PG : Connecté</span>
            </div>
          </div>

          {/* 2. RIGHT CONTENT OR SPLIT VIEWPORT AREA (9.5 cols) */}
          <div className="xl:col-span-9 p-4 bg-stone-100 flex flex-col justify-between gap-4 overflow-x-hidden">
            
            {/* Viewport Router Switch */}
            <div className="flex-1">
              
              {/* SPLIT SCREEN LAYOUT for document-centric forms: Naissances, Décès, Mariages, Divorces */}
              {(currentView === 'naissances' || currentView === 'deces' || currentView === 'mariages' || currentView === 'divorces') ? (
                !page ? (
                  <div className="bg-white p-12 rounded-3xl text-center border border-stone-200 shadow-xs space-y-4 animate-fade-in my-6">
                    <div className="w-16 h-16 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-400 mx-auto border border-stone-150 shadow-sm">
                      <FileText className="w-8 h-8" />
                    </div>
                    <div className="space-y-1.5 animate-fade-in">
                      <h4 className="font-display font-black text-stone-800 text-sm uppercase">
                        Aucun acte de type &quot;{currentView === 'naissances' ? 'Naissance' : currentView === 'deces' ? 'Décès' : currentView === 'mariages' ? 'Mariage' : 'Divorce'}&quot; chargé
                      </h4>
                      <p className="text-stone-500 text-xs max-w-sm mx-auto leading-relaxed">
                        Aucun acte d'État Civil de type <strong>{currentView === 'naissances' ? 'Naissance' : currentView === 'deces' ? 'Décès' : currentView === 'mariages' ? 'Mariage' : 'Divorce'}</strong> n'est disponible dans ce Lot.
                      </p>
                    </div>
                    <div className="bg-amber-50 text-amber-900 text-[10.5px] p-3 rounded-xl border border-amber-200 max-w-xs mx-auto font-medium">
                      💡 Cliquez sur <strong>📁 Moteur d'IA &amp; SQL</strong> à gauche pour charger un autre fichier ou lot JSON contenant ce type d'acte !
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                    
                    {/* Left sub-column: The active digital form inputs (col span 7) */}
                    <div className="xl:col-span-7 space-y-3">
                      <div className="bg-white p-2 rounded border border-stone-300 flex justify-between items-center text-xs">
                        <span className="font-bold text-stone-700 uppercase flex items-center gap-1">
                          📝 Formulaire de saisie: {currentView.toUpperCase()}
                        </span>
                        <span className="text-[10px] font-bold text-stone-400">
                          FICHIER : {page.filename}
                        </span>
                      </div>

                      {currentView === 'naissances' && (
                        <ActFormNaissance page={page} updatePage={updatePage} />
                      )}

                      {currentView === 'deces' && (
                        <ActFormDeces page={page} updatePage={updatePage} />
                      )}

                    {currentView === 'mariages' && (
                      <div className="bg-white p-4 rounded-lg border border-stone-300 space-y-4 text-xs font-sans">
                        <div className="bg-pink-50 p-2.5 rounded border border-pink-200 text-pink-900 font-bold flex items-center gap-1">
                          💍 Saisie de l'Acte de Mariage n° {page.numActe}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] mt-1 font-bold text-stone-500 text-right">رقم الرسم</label>
                            <input type="text" value={page.numActe} className="w-full p-2 border border-stone-250 rounded font-mono text-center text-stone-800" readOnly />
                          </div>
                          <div>
                            <label className="block text-[10px] mt-1 font-bold text-stone-400 text-right">عنوان م ك</label>
                            <input type="text" defaultValue="فاس المدينة" className="w-full p-2 border border-stone-250 rounded text-right font-display" dir="rtl" />
                          </div>
                        </div>

                        <div className="space-y-2 pt-2 border-t border-stone-150">
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">الزوج (Nom Époux)</label>
                              <input type="text" defaultValue="أحمد بناني" className="w-full p-2 border border-stone-300 rounded text-right font-display" dir="rtl" />
                            </div>
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">الزوجة (Nom Épouse)</label>
                              <input type="text" defaultValue="نادية الفاسي" className="w-full p-2 border border-stone-300 rounded text-right font-display" dir="rtl" />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">العدل الأول (Adoul 1)</label>
                              <input type="text" defaultValue="سليم بنجلون" className="w-full p-2 border border-stone-300 rounded text-right font-display text-xs" dir="rtl" />
                            </div>
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">العدل الثاني (Adoul 2)</label>
                              <input type="text" defaultValue="حماد الدكالي" className="w-full p-2 border border-stone-300 rounded text-right font-display text-xs" dir="rtl" />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] text-stone-400 font-bold col-span-1">تاريخ عقد الهامش (Date de l'acte)</label>
                            <input type="date" defaultValue="1994-04-18" className="w-full p-2 border border-stone-300 rounded text-stone-800 font-mono" />
                          </div>
                        </div>

                        <div className="bg-pink-50/40 p-2.5 rounded border border-pink-100 text-[10.5px] text-pink-850">
                          💍 L'acte de mariage nécessite la saisie conforme des tuteurs légaux (Adad-Sadaq).
                        </div>
                      </div>
                    )}

                    {currentView === 'divorces' && (
                      <div className="bg-white p-4 rounded-lg border border-stone-300 space-y-4 text-xs font-sans animate-fade-in">
                        <div className="bg-purple-50 p-2.5 rounded border border-purple-200 text-purple-950 font-bold flex items-center gap-1">
                          💔 Saisie de l'Acte de Divorce n° {page.numActe}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] mt-1 font-bold text-stone-500 text-right">رقم الرسم</label>
                            <input type="text" value={page.numActe} className="w-full p-2 border border-stone-250 rounded font-mono text-center text-stone-800" readOnly />
                          </div>
                          <div>
                            <label className="block text-[10px] mt-1 font-bold text-stone-400 text-right">عنوان م ك</label>
                            <input type="text" defaultValue="فاس المدينة" className="w-full p-2 border border-stone-250 rounded text-right font-display" dir="rtl" />
                          </div>
                        </div>

                        <div className="space-y-2 pt-2 border-t border-stone-150">
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">المطلق (Époux)</label>
                              <input type="text" defaultValue="أحمد بناني" className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800" dir="rtl" />
                            </div>
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">المطلقة (Épouse)</label>
                              <input type="text" defaultValue="نادية الفاسي" className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800" dir="rtl" />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">المحكمة المصدرة للحكم (Tribunal)</label>
                              <input type="text" defaultValue="المحكمة الابتدائية بفاس" className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800 text-xs" dir="rtl" />
                            </div>
                            <div>
                              <label className="block text-[10px] text-stone-400 font-bold">تاريخ صدور الحكم (Date jugement)</label>
                              <input type="date" defaultValue="1994-04-18" className="w-full p-2 border border-stone-300 rounded text-stone-800 font-mono" />
                            </div>
                          </div>
                        </div>

                        <div className="bg-purple-50/40 p-2.5 rounded border border-purple-150 text-[10.5px] text-purple-900 font-medium">
                          💔 L'acte de divorce requiert le numéro et la date de la décision judiciaire prononçant la dissolution du lien conjugal.
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Right sub-column: The interactive Scanned Document viewport (col span 5) */}
                  <div className="xl:col-span-5 space-y-3">
                    
                    {/* Toolbar on top of document */}
                    <div className="bg-white p-2 rounded border border-stone-305 flex justify-between items-center">
                      <span className="text-[10px] font-bold text-stone-500 font-sans uppercase">
                        📂 Image du Registre Original
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleZoom(0.1)}
                          className="p-1 bg-stone-100 border border-stone-300 hover:bg-stone-200 rounded text-stone-700"
                          title="Zoom In"
                          id="btn-doc-zoomin"
                        >
                          <ZoomIn className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleZoom(-0.1)}
                          className="p-1 bg-stone-100 border border-stone-300 hover:bg-stone-200 rounded text-stone-700"
                          title="Zoom Out"
                          id="btn-doc-zoomout"
                        >
                          <ZoomOut className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={handleRotation}
                          className="p-1 bg-stone-100 border border-stone-300 hover:bg-stone-200 rounded text-stone-700"
                          title="Faire pivoter"
                          id="btn-doc-rotate"
                        >
                          <RotateCw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Ledger layout box rendering (copied from QualityControl to display perfectly conforming certificate!) */}
                    <div className="h-[430px] border border-stone-300 rounded-lg overflow-hidden relative shadow-clay-inner bg-[#faf4ea] p-4 text-xs select-none flex items-center justify-center">
                      
                      {page.customPreview ? (
                        <div 
                          style={{
                            transform: `scale(${page.zoom})`,
                            transition: 'all 0.2s ease-in-out',
                          }}
                          className={`w-full h-full flex items-center justify-center ${
                            page.rotation === 90 ? 'rotate-90' :
                            page.rotation === 180 ? 'rotate-180' :
                            page.rotation === 270 ? 'rotate-270' : 'rotate-0'
                          }`}
                        >
                          <img 
                            src={page.customPreview} 
                            className="max-h-full max-w-full object-contain mx-auto" 
                            alt="Scan Registre" 
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      ) : (
                        <div 
                          style={{
                            transform: `scale(${page.zoom})`,
                            transition: 'all 0.2s ease-in-out',
                          }}
                          className={`w-full h-full flex flex-col justify-between font-serif ${
                            page.rotation === 90 ? 'rotate-90' :
                            page.rotation === 180 ? 'rotate-180' :
                            page.rotation === 270 ? 'rotate-270' : 'rotate-0'
                          }`}
                        >
                          {/* Header */}
                          <div className="flex justify-between items-start border-b border-[#c8b495] pb-1 bg-white/20 p-1 rounded text-[9px] text-stone-600">
                            <div>
                              <strong>ROYAUME DU MAROC</strong><br />
                              MUNICIPALITÉ DE FÈS
                            </div>
                            <div className="text-right">
                              <strong>ANNEXE ACCUEIL</strong><br />
                              {page.numBEC}
                            </div>
                          </div>

                          {/* Middle contents */}
                          <div className="grid grid-cols-12 gap-2 my-2 h-full items-stretch flex-1">
                            <div className="col-span-3 border-r border-[#decbb0] pr-1 flex flex-col justify-between text-[8px] text-[#c9184a] font-bold text-center">
                              <div>الملاحظات الهامشية <span className="block text-[6px] text-stone-400">Marges</span></div>
                              <div className="border border-dashed border-[#ff8fa3] bg-amber-50 p-1 rounded text-[7px]">
                                {page.isActeBis && "رسم مكرر"}
                                {page.marginalMentionsCount > 0 && "🖋️ Notice"}
                              </div>
                              <div className="text-[7px]">T: {page.numTome}</div>
                            </div>

                            <div className="col-span-9 pl-1.5 text-right flex flex-col justify-between">
                              <div>
                                <h3 className="text-center font-bold text-md text-amber-900 border-b border-[#e6cca0] pb-0.5">
                                  رسم {currentView === 'naissances' ? 'الولادة' : currentView === 'deces' ? 'الوفاة' : currentView === 'mariages' ? 'الزواج' : 'الطلاق'}
                                </h3>
                              </div>

                              <div className="space-y-1 font-sans text-stone-700">
                                <div className="flex justify-between items-center text-[10px]">
                                  <span className="text-[7px] text-stone-400">N° {page.numActe}</span>
                                  <span className="font-bold font-display text-amber-950">في يوم العاشر من أبريل لعام ألف وتسعمائة وأربعة وتسعون</span>
                                </div>
                                <div className="h-0.5 bg-stone-300 w-full" />
                                <div className="font-bold text-[10.5px]">
                                  {currentView === 'divorces' ? 'تم فك العصمة بين الزوجين' : currentView === 'mariages' ? 'تم عقد النكاح بين' : `ولد من الجنس ${currentView === 'naissances' ? 'الأنثوي' : 'الذكري'}`} : {page.operatorA.prenomAr} {page.operatorA.nomAr}
                                </div>
                                <div className="text-[9px] text-stone-400 leading-relaxed text-right">
                                  {currentView === 'divorces' ? 'بموجب القرار القضائي الصادر عن المحكمة الابتدائية بفاس.' : currentView === 'mariages' ? 'بحضور شاهدين مكلفين والولي الصداق فاس.' : `والده ${page.operatorA.perePrenom}، والدته ${page.operatorA.merePrenom}، المقيمين بالمدينة القديمة فاس.`}
                                </div>
                              </div>

                              <div className="flex justify-between items-center text-[7px] text-stone-450 border-t border-[#decbb0] pt-0.5">
                                <span>ANNEXE: OK</span>
                                <span className="font-semibold text-stone-600">المفوض ببلدية فاس</span>
                              </div>
                            </div>
                          </div>

                          {/* Footer */}
                          <div className="border-t border-[#c8b495] pt-0.5 text-center text-[8px] text-stone-400">
                            FILE: {page.filename}
                          </div>

                        </div>
                      )}

                    </div>

                    {/* Side selection of Acts list (from Image 2, showing rows of acts to trigger direct toggle) */}
                    <div className="bg-white p-2.5 rounded border border-stone-300">
                      <span className="block text-[9px] font-bold text-stone-400 uppercase mb-1">
                        🔍 Actes de la catégorie active ({filteredPages.length})
                      </span>
                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-1.5 font-mono text-[11px]">
                        {filteredPages.slice(0, 8).map((p, idx) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => setSelectedPageIndex(idx)}
                            className={`py-1 text-center border rounded transition-all font-bold ${
                              selectedPageIndex === idx 
                                ? "bg-amber-100 text-[#ea580c] border-[#ea580c] font-black" 
                                : "bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200"
                            }`}
                            id={`act-sidebar-toggle-${idx}`}
                          >
                            R {p.numActe} ({p.typeActe})
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>

                </div>
              )) : (
                /* OTHERWISE RENDER OTHER COMMONS/ADMIN INTERACTIVE FORMS */
                <div className="space-y-4 animate-fadeIn">
                  
                  {currentView === 'po-pf' && (
                    <FormPopf page={page} updatePage={updatePage} />
                  )}

                  {currentView === 'rejets' && (
                    <div className="bg-white p-4 rounded-xl border border-stone-300 space-y-4 text-xs font-sans">
                      <span className="text-stone-700 font-bold block uppercase border-b border-stone-200 pb-2">
                        🛡️ Traitement Rejets & Supervision de Double Saisie
                      </span>
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div className="bg-red-50 p-4 border border-red-200 rounded-lg">
                          <span className="block text-xl font-bold font-mono text-red-700">0001</span>
                          <span className="text-[10px] text-stone-400 block mt-1 uppercase">Lots Actifs en Conflit</span>
                        </div>
                        <div className="bg-green-50 p-4 border border-green-200 rounded-lg">
                          <span className="block text-xl font-bold font-mono text-green-700">0024</span>
                          <span className="text-[10px] text-stone-400 block mt-1 uppercase">Écarts Résolus Aujourd'hui</span>
                        </div>
                      </div>
                      <p className="text-[11px] text-stone-500 leading-relaxed">
                        Le système de double saisie (Opérateur A vs Opérateur B) s'intègre à l'étape 4 de l'application. Cette vue simule le rejet lors d'écarts de transcription incompatibles pour validation.
                      </p>
                    </div>
                  )}

                  {currentView === 'messagerie' && (
                    <Messagerie />
                  )}

                  {currentView === 'clavier' && (
                    <div className="bg-white p-4 rounded-xl border border-stone-300 space-y-4 font-sans select-none">
                      <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                        <span className="text-stone-700 font-bold uppercase text-xs">
                          ⌨️ Clavier Virtuel de Saisie Bilingue
                        </span>
                        
                        <div className="flex gap-2">
                          <button 
                            type="button" 
                            onClick={() => setClavierLanguage('AR')}
                            className={`py-1 px-3 border rounded text-xs font-bold ${clavierLanguage === 'AR' ? "bg-amber-100 text-amber-800 border-amber-300" : "bg-stone-50 hover:bg-stone-100"}`}
                          >
                            عربي (Arabic)
                          </button>
                          <button 
                            type="button" 
                            onClick={() => setClavierLanguage('FR')}
                            className={`py-1 px-3 border rounded text-xs font-bold ${clavierLanguage === 'FR' ? "bg-amber-100 text-amber-800 border-amber-300" : "bg-stone-50 hover:bg-stone-100"}`}
                          >
                            Français
                          </button>
                        </div>
                      </div>

                      {/* Display preview typed area */}
                      <div>
                        <label className="block text-[10px] text-stone-400 uppercase font-black mb-1">Zone de saisie d'essai:</label>
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={keyboardBuffer}
                            onChange={(e) => setKeyboardBuffer(e.target.value)}
                            className="w-full p-2 border border-stone-300 rounded font-bold text-center text-lg bg-stone-50 text-stone-850"
                            placeholder={clavierLanguage === 'AR' ? "انقر فوق الأحرف للكتابة..." : "Cliquez sur les lettres pour écrire..."}
                            dir={clavierLanguage === 'AR' ? 'rtl' : 'ltr'}
                          />
                          <button 
                            type="button" 
                            onClick={() => setKeyboardBuffer('')}
                            className="p-2 border border-stone-300 bg-stone-100 hover:bg-stone-200 text-xs font-semibold rounded text-stone-600"
                          >
                            Effacer
                          </button>
                        </div>
                      </div>

                      {/* On-screen tactile keyboard buttons */}
                      <div className="grid grid-cols-6 lg:grid-cols-10 gap-1.5 p-3 bg-stone-50 border border-stone-200 rounded-lg">
                        {(clavierLanguage === 'AR' ? keysAr : keysFr).map((k) => (
                          <button
                            key={k}
                            type="button"
                            onClick={() => setKeyboardBuffer(prev => prev + k)}
                            className="p-3 bg-white hover:bg-amber-50 active:bg-amber-100 border border-stone-300 rounded text-center text-sm font-bold/font-semibold transition-all shadow-xs shrink-0 select-none cursor-pointer text-stone-800"
                          >
                            {k}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {currentView === 'changer-lot' && (
                    <div className="bg-white p-4 rounded-xl border border-stone-300 space-y-4 text-xs font-sans">
                      <span className="text-stone-700 font-bold block uppercase border-b border-stone-200 pb-2">
                        🔄 Recharger ou Changer de Lot Électronique (Tome/BEC)
                      </span>
                      <div className="space-y-3">
                        <p className="text-stone-500 text-[11px]">
                          Veuillez choisir le lot d'actes d'Annexe ou de Bureau Principal que vous souhaitez charger pour validation:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedPageIndex(0);
                              setCurrentView('naissances');
                              setCustomNotification("Lot de Naissances Fès n° 22008001 chargé !");
                            }}
                            className="p-4 border border-orange-200 hover:bg-orange-50/50 rounded-lg text-left"
                          >
                            <span className="block font-black text-orange-800">Lot Naissances Fès Annexe</span>
                            <span className="block text-[10px] text-stone-400 font-mono mt-1">Ref: 22008001085508</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setSelectedPageIndex(1);
                              setCurrentView('deces');
                              setCustomNotification("Lot de Décès Taza chargé !");
                            }}
                            className="p-4 border border-teal-200 hover:bg-teal-50/50 rounded-lg text-left"
                          >
                            <span className="block font-black text-teal-800">Lot Décès Taza Central</span>
                            <span className="block text-[10px] text-stone-400 font-mono mt-1">Ref: 22005001085405</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setCustomNotification("Lot de Mariages en attente de synchro.");
                            }}
                            className="p-4 border border-stone-200 hover:bg-stone-50 rounded-lg text-left opacity-60"
                          >
                            <span className="block font-black text-slate-700">Lot Historique Divorces</span>
                            <span className="block text-[10px] text-stone-400 font-mono mt-1">Lot Non-assigné</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {currentView === 'affectations' && (
                    <GestionAffectations />
                  )}

                  {currentView === 'utilisateurs' && (
                    <GestionUtilisateurs />
                  )}

                  {currentView === 'officier' && (
                    <div className="bg-white p-4 rounded-xl border border-stone-300 space-y-4 text-xs font-sans">
                      <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                        <span className="text-stone-700 font-bold uppercase text-xs">
                          ⚖️ Liste Autorisée des Officiers d’État Civil (Civil Officers)
                        </span>
                        <span className="bg-stone-100 p-1 px-3 border rounded text-[10px] font-mono text-stone-500 uppercase font-black">
                          BEC-341
                        </span>
                      </div>

                      <div className="overflow-x-auto rounded-lg border border-stone-300 shadow-inner">
                        <table className="w-full text-right border-collapse">
                          <thead className="bg-[#f4f4f5] border-b border-stone-300 text-right text-[11px] font-bold text-stone-605">
                            <tr className="divide-x divide-stone-200">
                              <th className="p-2 border-r border-stone-200 text-left">Qualité de l'Officier</th>
                              <th className="p-2">الإسم الشخصي والعائلي لضابط الحالة</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="hover:bg-stone-50">
                              <td className="p-2 border-r border-stone-200 text-left font-sans text-stone-550">Adjoint du Chef d'Annexe / نائب الضابط المفوض</td>
                              <td className="p-2 text-right font-display text-amber-900 font-bold">محمد بنعمر السقاط</td>
                            </tr>
                            <tr className="hover:bg-stone-50">
                              <td className="p-2 border-r border-stone-200 text-left font-sans text-stone-550">Officier de Garde d'Annexe / ضابط الحالة المدنية بالنيابة</td>
                              <td className="p-2 text-right font-display text-amber-900 font-bold">عبد اللطيف البهلي</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {currentView === 'listes' && (
                    <GestionListes />
                  )}

                  {currentView === 'parametrage' && (
                    <div className="bg-white p-4 rounded-xl border border-stone-300 space-y-4 text-xs font-sans">
                      <span className="text-stone-700 font-bold block uppercase border-b border-stone-200 pb-2">
                        ⚙️ Paramétrage du Système InfoTeam 1 local
                      </span>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] text-stone-400 font-bold col-span-1">Port local du Proxy Nginx</label>
                          <input type="text" value="3000" className="w-full p-2 bg-stone-50 border border-stone-305 rounded font-mono text-stone-550 focus:outline-hidden" readOnly />
                        </div>
                        <div>
                          <label className="block text-[10px] text-stone-400 font-bold col-span-1">Moteur d'indexation DB</label>
                          <input type="text" value="PostgreSQL Engine active" className="w-full p-2 bg-stone-50 border border-stone-305 rounded text-stone-550 focus:outline-hidden" readOnly />
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>

            {/* 🔟 NAVIGATION DES PAGES TRAITÉES (DE 1 À 10) POSITIONNÉE DANS LE BAS */}
            <div className="bg-white p-3 rounded-lg border border-stone-300 flex flex-col md:flex-row justify-between items-center gap-3 select-none text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-[#ea580c] rounded-full animate-pulse" />
                <span className="text-[10px] font-bold text-stone-605 uppercase font-sans tracking-wide">
                  Navigation d'actes: Page {filteredPages.length > 0 ? selectedPageIndex + 1 : 0} sur {filteredPages.length}
                </span>
              </div>

              {/* Exact numbered buttons filtered by active category type */}
              <div className="flex flex-wrap gap-1 items-center justify-center">
                <button
                  type="button"
                  onClick={() => setSelectedPageIndex(prev => Math.max(0, prev - 1))}
                  disabled={selectedPageIndex === 0 || filteredPages.length === 0}
                  className="p-1 px-2 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded disabled:opacity-30 disabled:hover:bg-stone-100 text-[10px] font-bold font-sans transition-all flex items-center gap-0.5 text-stone-700 cursor-pointer"
                  id="retro-prev-btn-bottom"
                >
                  <ChevronLeft className="w-3 h-3" /> Préc.
                </button>

                {filteredPages.map((p, idx) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPageIndex(idx)}
                    className={`w-7 h-7 rounded font-mono text-[10.5px] font-bold transition-all border relative flex items-center justify-center ${
                      selectedPageIndex === idx 
                        ? "bg-[#ea580c] text-white border-[#ea580c] shadow-xs font-black scale-105" 
                        : "bg-white text-stone-600 border-stone-300 hover:bg-stone-50"
                    }`}
                    id={`retro-page-btn-bottom-${idx}`}
                  >
                    <span>{idx + 1}</span>
                    {p.status === 'Indexé' && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white flex items-center justify-center text-[7px] text-white font-black" title="Validé">✓</span>
                    )}
                  </button>
                ))}

                <button
                  type="button"
                  onClick={() => setSelectedPageIndex(prev => Math.min(filteredPages.length - 1, prev + 1))}
                  disabled={filteredPages.length === 0 || selectedPageIndex === filteredPages.length - 1}
                  className="p-1 px-2 bg-stone-100 hover:bg-stone-200 border border-stone-305 rounded disabled:opacity-30 disabled:hover:bg-stone-100 text-[10px] font-bold font-sans transition-all flex items-center gap-0.5 text-stone-700 cursor-pointer"
                  id="retro-next-btn-bottom"
                >
                  Suiv. <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Bottom action toolbar mirroring actual Windows buttons bar */}
            <div className="bg-[#dcdcdc] p-2.5 rounded border border-stone-305 flex justify-between items-center text-xs">
              
              <div className="flex gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={handleValidateCurrentPage}
                  disabled={!page}
                  className="py-1 px-4 bg-[#e1e2e6] hover:bg-[#d0d4dc] border border-stone-500 rounded text-stone-850 font-bold shadow-xs select-none cursor-pointer flex items-center gap-1 text-[11px] disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {page?.status === 'Indexé' ? "✅ Acte Validé !" : "💾 Valider cet Acte (حفظ)"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    filteredPages.forEach(p => {
                      p.status = 'Indexé';
                    });
                    setCustomNotification("Tous les actes du lot courant ont été validés et indexés avec succès !");
                  }}
                  className="py-1 px-4 bg-[#e1e2e6] hover:bg-[#d0d4dc] border border-stone-500 rounded text-stone-850 font-bold shadow-xs select-none cursor-pointer flex items-center gap-1 text-[11px]"
                  id="btn-valider-lot-double-saisie"
                >
                  📥 Valider Lot
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (filteredPages.length > 0) {
                      setSelectedPageIndex(prev => Math.min(filteredPages.length - 1, prev + 1));
                      setCustomNotification("Passage à l'acte suivant de cette catégorie.");
                    }
                  }}
                  disabled={filteredPages.length === 0 || selectedPageIndex === filteredPages.length - 1}
                  className="py-1 px-4 bg-[#e1e1e1] hover:bg-stone-300 border border-stone-500 rounded text-stone-850 select-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Acte Suivant
                </button>
                {deleteConfirmId === page?.id ? (
                  <div className="flex items-center gap-1.5 bg-red-100 p-1 rounded border border-red-350 font-sans">
                    <span className="text-[10px] text-red-950 font-bold">Confirmer suppression ?</span>
                    <button
                      type="button"
                      onClick={() => {
                        if (!page) return;
                        setScannedPages(prev => prev.filter(p => p.id !== page.id));
                        setCustomNotification(`L'acte n° ${page.numActe} (${page.typeActe}) et sa capture ont été supprimés.`);
                        setDeleteConfirmId(null);
                        setSelectedPageIndex(0);
                      }}
                      className="px-2 py-0.5 bg-red-650 hover:bg-red-700 text-white rounded text-[10px] font-bold cursor-pointer"
                    >
                      Oui
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmId(null)}
                      className="px-2 py-0.5 bg-stone-300 hover:bg-stone-400 text-stone-850 rounded text-[10px] font-bold cursor-pointer"
                    >
                      Non
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      if (!page) return;
                      setDeleteConfirmId(page.id);
                    }}
                    disabled={!page}
                    className="py-1 px-4 bg-red-50 hover:bg-red-100 border border-red-400 text-red-700 font-bold rounded shadow-xs select-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 text-[11px]"
                  >
                    🗑️ Supprimer l'Acte & Capture
                  </button>
                )}
              </div>

              {/* Master validation triggers the unlocked step 4 transition! */}
              <button
                type="button"
                onClick={onValidateStep3}
                className="py-1.5 px-6 bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-700 hover:to-green-800 text-white font-bold rounded shadow-md select-none transition-all flex items-center gap-1 cursor-pointer"
                id="btn-trigger-validation-retro"
              >
                <span>Terminer et Passer à l'Étape 4 (Arbitrage) </span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
