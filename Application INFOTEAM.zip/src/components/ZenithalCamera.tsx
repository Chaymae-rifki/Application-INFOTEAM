/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, Layers, Check, Sparkles, Image, VideoOff, Grid, AlertCircle, Play, Edit2, Trash2, Plus, X, Upload } from 'lucide-react';
import { PageScan, ActeType } from '../types';
import { PRESET_PAGES, getPresetPool } from '../data';

interface ZenithalCameraProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidateStep1: () => void;
  isStep2Unlocked: boolean;
  resetCounter?: number;
}

export default function ZenithalCamera({
  scannedPages,
  setScannedPages,
  onValidateStep1,
  isStep2Unlocked,
  resetCounter = 0,
}: ZenithalCameraProps) {
  const [cameraActive, setCameraActive] = useState(true);
  const [selectedPresetIndex, setSelectedPresetIndex] = useState(0);
  const [flashActive, setFlashActive] = useState(false);
  const [selectedResolution, setSelectedResolution] = useState("3840x2160 - 4K Ultra-Zenith");
  const [selectedBec, setSelectedBec] = useState("BEC-341");
  
  const activePool = getPresetPool(resetCounter);
  const capturedCount = scannedPages.length;

  const [editingPage, setEditingPage] = useState<PageScan | null>(null);
  const [dragOverImport, setDragOverImport] = useState(false);
  const [modalCamActive, setModalCamActive] = useState(false);
  const modalVideoRef = useRef<HTMLVideoElement | null>(null);

  // Real webcam state management
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraPermissionStatus, setCameraPermissionStatus] = useState<'prompt' | 'granted' | 'denied' | 'no-device'>('prompt');
  const [cameraMode, setCameraMode] = useState<'real' | 'simulated'>('simulated'); // user can toggle or fallback

  useEffect(() => {
    let activeStream: MediaStream | null = null;

    if ((cameraActive || modalCamActive) && cameraMode === 'real') {
      navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: "environment", 
          width: { ideal: 1280 }, 
          height: { ideal: 720 } 
        } 
      })
      .then(s => {
        setStream(s);
        setCameraPermissionStatus('granted');
        activeStream = s;
        if (videoRef.current) {
          videoRef.current.srcObject = s;
        }
        if (modalVideoRef.current) {
          modalVideoRef.current.srcObject = s;
        }
      })
      .catch(err => {
        console.warn("Could not start real webcam, falling back to simulated high-fidelity feed:", err);
        setCameraPermissionStatus('denied');
        setCameraMode('simulated');
      });
    } else {
      if (!cameraActive && !modalCamActive && stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
    }

    return () => {
      if (activeStream && !cameraActive && !modalCamActive) {
        activeStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraActive, modalCamActive, cameraMode]);

  useEffect(() => {
    if (modalCamActive && stream && modalVideoRef.current) {
      modalVideoRef.current.srcObject = stream;
    }
  }, [modalCamActive, stream]);

  // Sound and physical simulate camera clicking with canvas extraction
  const triggerCapture = () => {
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 300);

    let realImageSrc: string | null = null;
    if (videoRef.current && stream && cameraMode === 'real') {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth || 640;
        canvas.height = videoRef.current.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
          realImageSrc = canvas.toDataURL('image/jpeg');
        }
      } catch (err) {
        console.error("Failed to snapshot real camera frame:", err);
      }
    }

    // Create a new simulated page scan from presets to append
    const presetBase = activePool[selectedPresetIndex] || activePool[0] || PRESET_PAGES[0];
    const newPageId = `SCAN-${new Date().getFullYear()}-00${scannedPages.length + 1}`;
    
    const newPage: PageScan = {
      ...presetBase,
      id: newPageId,
      filename: realImageSrc 
        ? `CAM_${selectedBec}_T12_ACTE_${scannedPages.length + 1}.jpg`
        : `REG_${selectedBec}_TOME12_ACTE_NEW_${scannedPages.length + 10}.jpg`,
      captureTime: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      status: 'Brut',
      numBEC: selectedBec,
      customPreview: realImageSrc || undefined,
    };

    setScannedPages(prev => [...prev, newPage]);
  };

  const handleFileUpload = (file: File) => {
    if (!file.type.match('image.*')) {
      alert("Veuillez sélectionner un fichier image valide (.png, .jpg, .jpeg, etc.)");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const newPageId = `UPLOAD-${new Date().getFullYear()}-00${scannedPages.length + 1}`;
      const presetBase = activePool[scannedPages.length % activePool.length] || activePool[0] || PRESET_PAGES[0];
      
      const newPage: PageScan = {
        ...JSON.parse(JSON.stringify(presetBase)),
        id: newPageId,
        filename: file.name,
        captureTime: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        status: 'Brut',
        customPreview: dataUrl,
      };
      
      setScannedPages(prev => [...prev, newPage]);
    };
    reader.readAsDataURL(file);
  };

  const handleUpdatePageInModal = (updated: PageScan) => {
    setScannedPages(prev => prev.map(p => p.id === updated.id ? updated : p));
    setEditingPage(null);
    setModalCamActive(false);
  };

  const handleSnapshotInModal = () => {
    if (!editingPage) return;

    // Simulate flash effect
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 250);

    let realImageSrc: string | null = null;
    if (modalVideoRef.current && stream && cameraMode === 'real') {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = modalVideoRef.current.videoWidth || 640;
        canvas.height = modalVideoRef.current.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(modalVideoRef.current, 0, 0, canvas.width, canvas.height);
          realImageSrc = canvas.toDataURL('image/jpeg');
        }
      } catch (err) {
        console.error("Failed to snapshot real camera frame inside modal:", err);
      }
    }

    if (realImageSrc) {
      setEditingPage({
        ...editingPage,
        customPreview: realImageSrc,
        captureTime: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      });
    } else {
      // Pick a random preset to simulate a new page scan
      const nextPresetIdx = Math.floor(Math.random() * activePool.length);
      const randomPreset = activePool[nextPresetIdx] || activePool[0] || PRESET_PAGES[0];
      
      setEditingPage({
        ...editingPage,
        customPreview: randomPreset.customPreview || undefined,
        captureTime: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        typeActe: randomPreset.typeActe,
        numActe: randomPreset.numActe,
        numTome: randomPreset.numTome,
      });
    }
    setModalCamActive(false);
  };

  const clearCapturedPages = () => {
    setScannedPages([]);
  };

  return (
    <div className="space-y-6" id="zenithal-camera-stage">
      {/* High-visibility Re-scan warning panel for anomalous acts */}
      {scannedPages.some(p => p.isBlurred || p.isFoldedText) && (
        <div className="bg-[#fff0f3] border-2 border-red-500 rounded-3xl p-5 shadow-md space-y-3 animate-bounce">
          <div className="flex gap-3 items-start">
            <span className="text-2xl animate-pulse">📷⚠️</span>
            <div className="space-y-1 flex-1">
              <h4 className="font-display font-black text-[#c9184a] text-sm uppercase">
                Anomalies de Qualité Détectées : Actes à re-scanner obligatoirement !
              </h4>
              <p className="text-[10.5px] text-[#c9184a] leading-relaxed font-sans font-medium">
                Le contrôle qualité a identifié des anomalies physiques (image floue ou pliure &quot;Twya&quot;) sur les documents ci-dessous. 
                Veuillez re-numériser ou corriger ces pages, puis cliquez sur <strong>&quot;Modifier&quot;</strong> pour décocher les cases une fois l'acte rectifié.
              </p>
            </div>
          </div>

          <div className="bg-white/80 border border-red-200/60 p-3 rounded-2xl font-mono text-[10.5px] space-y-1.5 max-h-48 overflow-y-auto">
            <span className="font-bold text-[#c9184a] block uppercase text-[9px] tracking-wide">Liste des actes à re-scanner :</span>
            {scannedPages.map((p, idx) => {
              if (p.isBlurred || p.isFoldedText) {
                return (
                  <div key={p.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-2 rounded-lg border border-red-200 shadow-xs gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-red-600 font-bold">📷⚠️ [ACTE À RE-SCANNER]</span>
                      <span className="text-stone-800 font-bold">Page {idx + 1} ({p.id})</span>
                      <span className="text-stone-500 font-semibold">• Acte N° {p.numActe} ({p.typeActe})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-red-700 bg-red-50 px-2 py-0.5 rounded-full text-[9.5px] font-bold">
                        {p.isBlurred ? "Image floue" : ""}
                        {p.isBlurred && p.isFoldedText ? " + " : ""}
                        {p.isFoldedText ? "Pliure / Twya" : ""}
                      </span>
                      <button
                        onClick={() => setEditingPage(p)}
                        className="bg-[#c9184a] hover:bg-red-800 text-white text-[9.5px] px-2.5 py-0.5 rounded-md font-bold uppercase shadow-xs transition-all cursor-pointer"
                      >
                        Corriger & Décocher ✏️
                      </button>
                    </div>
                  </div>
                );
              }
              return null;
            })}
          </div>
        </div>
      )}

      {/* Simulation Workspace Card */}
      <div className="bg-white rounded-3xl p-6 shadow-clay-md border-2 border-pastel-pink/50">
        
        {/* Cam Control Header */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-pastel-pink/30">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping" />
            <h4 className="font-display font-semibold text-deep-pink text-sm tracking-tight">Flux Caméra Zénithale Ultra-HD</h4>
          </div>

          <div className="flex gap-2 text-xs">
            <select 
              value={selectedBec} 
              onChange={(e) => setSelectedBec(e.target.value)}
              className="px-3 py-1.5 bg-pastel-pink-light/50 border border-pastel-pink text-deep-pink font-medium rounded-xl focus:outline-hidden"
              id="bec-select-camera"
            >
              <option value="BEC-341">Fès Médina (BEC-341)</option>
              <option value="BEC-220">Marrakech Gueliz (BEC-220)</option>
              <option value="BEC-105">Rabat Agdal (BEC-105)</option>
            </select>

            <select 
              value={selectedResolution} 
              onChange={(e) => setSelectedResolution(e.target.value)}
              className="px-3 py-1.5 bg-pastel-pink-light/50 border border-pastel-pink text-deep-pink font-medium rounded-xl focus:outline-hidden"
              id="res-select-camera"
            >
              <option value="3840x2160 - 4K Ultra-Zenith">3840x2160 (Zenith 4K)</option>
              <option value="1920x1080 - 1080p Standard">1920x1080 (FHD 1080p)</option>
            </select>
          </div>
        </div>

        {/* Viewport Split-Screen Simulator */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Box 1: Zenithal Camera Live Stream */}
          <div className="lg:col-span-7 relative h-[360px] bg-slate-950 rounded-2xl border border-pastel-pink overflow-hidden shadow-inner flex flex-col justify-between p-4">
            
            {/* Top Bar inside Viewport */}
            <div className="relative z-10 flex justify-between items-center bg-black/60 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-white/10 text-white font-mono text-[10px]">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                CAM_ONLINE (ZENITH_60HZ)
              </span>
              <span>RES: {selectedResolution.split(" ")[0]}</span>
            </div>

            {/* Flash Overlay Effect */}
            {flashActive && (
              <div className="absolute inset-0 z-40 bg-white/95 animate-fade-out" />
            )}

            {/* Camera Viewport Canvas */}
            {cameraActive ? (
              <div className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden">
                {/* Real Video Elements */}
                {cameraMode === 'real' && (
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                )}

                {/* Simulated Ledger element */}
                {cameraMode === 'simulated' && (
                  <div className="absolute inset-x-0 flex items-center justify-center pointer-events-none select-none">
                    {/* Simulated Ledger Document */}
                    <div className="w-[280px] h-[220px] bg-[#fcf8f2] shadow-md border border-[#e8dcc4] rounded p-2 text-[8px] text-stone-800 flex flex-col justify-between font-serif relative overflow-hidden">
                      
                      {/* Simulated Text lines to feel like Arabic State Register */}
                      <div className="flex justify-between items-center border-b border-stone-300 pb-1 font-sans text-[7px] text-stone-500 font-semibold uppercase">
                        <span>Royaume du Maroc</span>
                        <span>État Civil</span>
                      </div>

                      <div className="space-y-1 my-1">
                        <div className="text-right font-bold font-display text-[9px] text-[#8b5a2b]">
                          {(() => {
                            const activePreset = activePool[selectedPresetIndex] || activePool[0] || PRESET_PAGES[0];
                            const type = activePreset?.typeActe;
                            if (type === 'Naissance') return "عقد ولادة - Naissance";
                            if (type === 'Décès') return "شهادة وفاة - Décès";
                            if (type === 'Mariage') return "رسم زواج - Mariage";
                            if (type === 'Divorce') return "رسم طلاق - Divorce";
                            return "وثيقة - Document";
                          })()}
                        </div>
                        <div className="h-1 bg-stone-300/40 w-3/4 ml-auto rounded" />
                        <div className="h-1 bg-stone-300/40 w-5/6 ml-auto rounded" />
                        <div className="h-1 bg-stone-300/40 w-2/3 ml-auto rounded" />
                        
                        <div className="flex justify-between items-center pt-2 text-[6px] text-stone-400 font-sans">
                          <span>Num: {(activePool[selectedPresetIndex] || activePool[0] || PRESET_PAGES[0]).numActe}</span>
                          <span>BEC: {selectedBec}</span>
                        </div>
                      </div>

                      <div className="border-t border-stone-200 pt-1 text-[6px] flex justify-between font-sans">
                        <span>{(activePool[selectedPresetIndex] || activePool[0] || PRESET_PAGES[0]).captureTime}</span>
                        <span className="text-[#c9184a] font-bold">PREVIEW READY</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Always show custom scanner alignment markings on top of video or mockup */}
                <div className="absolute inset-0 z-10 pointer-events-none select-none flex items-center justify-center">
                  
                  {/* Horizontal & Vertical Crosshair Grids */}
                  <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 border-t border-dashed border-chic-pink/30" />
                  <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 border-l border-dashed border-chic-pink/30" />
                  
                  {/* Calibration Bracket */}
                  <div className="absolute w-[280px] h-[220px] border-2 border-chic-pink/50 rounded-xl">
                    <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-deep-pink" />
                    <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-deep-pink" />
                    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-deep-pink" />
                    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-deep-pink" />
                  </div>

                  {/* Scan guideline laser line animation */}
                  <div className="absolute inset-x-0 w-full h-[2px] bg-red-400 opacity-80 animate-scan" style={{ top: '35%' }} />

                  {/* Laser focal points */}
                  <span className="absolute top-1/4 left-1/4 w-1.5 h-1.5 rounded-full bg-chic-pink/70 animate-ping" />
                  <span className="absolute bottom-1/4 right-1/4 w-1.5 h-1.5 rounded-full bg-chic-pink/70 animate-ping" />
                </div>

              </div>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-pastel-pink-dark">
                <VideoOff className="w-12 h-12 mb-2" />
                <span className="text-xs font-semibold">Flux Caméra Désactivé</span>
              </div>
            )}

            {/* Bottom Feed HUD */}
            <div className="relative z-10 flex justify-between items-center text-white/80 font-mono text-[9px]">
              <span>AUTOFOCUS: DYNAMIC (OK)</span>
              <span>FOCALE: 35mm f/1.8</span>
            </div>
          </div>

          {/* Box 2: Feed Controls & Presets */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div className="bg-pastel-pink-light/30 border border-pastel-pink/40 p-4 rounded-2xl space-y-4">
              
              {/* Presets List */}
              <div>
                <div className="flex justify-between items-center mb-2 gap-2 flex-wrap">
                  <h5 className="font-display font-bold text-deep-pink text-xs flex items-center gap-1.5 mr-auto">
                    <Layers className="w-3.5 h-3.5" /> Sélection Document Registre
                  </h5>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSelectedPresetIndex(prev => (prev - 1 + activePool.length) % activePool.length)}
                      className="px-2 py-1 bg-white border border-pastel-pink text-[#c9184a] text-[10px] font-bold rounded-lg hover:bg-bubble-pink transition-all flex items-center gap-0.5"
                      id="btn-prev-document-preset"
                    >
                      ◀ Doc.
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedPresetIndex(prev => (prev + 1) % activePool.length)}
                      className="px-2.5 py-1.5 bg-gradient-to-r from-chic-pink to-deep-pink hover:from-deep-pink hover:to-chic-pink text-white text-[10px] font-bold rounded-xl transition-all shadow-clay-sm flex items-center gap-1"
                      id="btn-next-document-preset"
                    >
                      Doc. ▶
                    </button>
                  </div>
                </div>
                <div className="space-y-1.5 text-xs">
                  {activePool.map((preset, idx) => {
                    // Match by typeActe and numActe to check if this preset has already been captured
                    const matchingScan = scannedPages.find(p => p.numActe === preset.numActe && p.typeActe === preset.typeActe);
                    const isScanned = !!matchingScan;

                    return (
                      <div
                        key={preset.id}
                        onClick={() => setSelectedPresetIndex(idx)}
                        className={`w-full flex items-center justify-between p-2 rounded-xl border text-left transition-all cursor-pointer ${
                          selectedPresetIndex === idx
                            ? isScanned
                              ? "bg-emerald-50/50 border-emerald-500 text-emerald-900 font-semibold shadow-clay-sm"
                              : "bg-white border-pastel-pink-dark text-deep-pink font-semibold shadow-clay-sm"
                            : isScanned
                              ? "bg-emerald-50/10 border-emerald-200 text-stone-700 hover:bg-emerald-50/20"
                              : "bg-white/50 border-pastel-pink/30 text-stone-700 hover:bg-white"
                        }`}
                        id={`preset-select-${idx}`}
                      >
                        <div className="flex flex-col flex-1 min-w-0 mr-1.5">
                          <span className="font-sans font-medium text-[10.5px] truncate">
                            {preset.typeActe} - Tom. {preset.numTome} {isScanned && "✅"}
                          </span>
                          <span className="text-[9.5px] text-stone-400 font-mono truncate">{preset.filename}</span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {isScanned ? (
                            <div className="flex items-center gap-1">
                              <span className="px-1 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[7.5px] font-bold uppercase font-sans">
                                Numérisé
                              </span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (matchingScan) {
                                    setScannedPages(prev => prev.filter(p => p.id !== matchingScan.id));
                                  }
                                }}
                                className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors cursor-pointer"
                                title="Supprimer cette capture"
                              >
                                <Trash2 className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          ) : (
                            <span className="px-1 py-0.5 rounded bg-stone-100 text-stone-400 text-[7.5px] font-bold uppercase font-sans">
                              À scanner
                            </span>
                          )}
                          <span className="px-1 py-0.5 rounded bg-bubble-pink text-chic-pink text-[7.5px] font-bold uppercase font-sans">
                            P{idx + 1}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status Stats Summary */}
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-white p-2.5 rounded-xl shadow-clay-inner border border-pastel-pink/20">
                  <span className="block text-[10px] text-stone-400 font-medium font-sans">Numérisés</span>
                  <span className="text-xl font-display font-bold text-deep-pink font-mono">{capturedCount}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl shadow-clay-inner border border-pastel-pink/20">
                  <span className="block text-[10px] text-stone-400 font-medium font-sans">Statut Lot</span>
                  <span className="text-[10px] font-display font-bold text-green-600 flex items-center justify-center gap-1 mt-1 font-sans">
                    <Sparkles className="w-3 h-3" /> PRÊT (BRUT)
                  </span>
                </div>
              </div>

            </div>

            {/* Quick Actions Buttons */}
            <div className="space-y-2 mt-4 lg:mt-0">
              <button
                onClick={triggerCapture}
                disabled={!cameraActive}
                className={`w-full py-4 px-4 bg-chic-pink hover:bg-deep-pink text-white font-display font-bold text-sm rounded-2xl shadow-clay-md hover:shadow-clay-lg transition-all transform active:scale-95 flex items-center justify-center gap-2 animate-heartbeat-pink`}
                id="btn-trigger-scandec"
              >
                <Camera className="w-5 h-5 text-white" />
                Déclencher la Capture Caméra 📸
              </button>

              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => setCameraActive(!cameraActive)}
                  className={`py-2 px-1 text-[10px] md:text-xs font-display font-bold rounded-xl border flex items-center justify-center gap-1 transition-all ${
                    cameraActive 
                      ? "bg-[#fff0f3] border-pastel-pink text-[#c9184a]" 
                      : "bg-[#f8f9fa] border-stone-200 text-stone-500"
                  }`}
                  id="btn-toggle-cam-live"
                >
                  <RefreshCw className="w-3 h-3 animate-spin-slow" /> {cameraActive ? "Désactiver" : "Activer"}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const nextMode = cameraMode === 'real' ? 'simulated' : 'real';
                    setCameraMode(nextMode);
                    if (nextMode === 'real') {
                      setCameraActive(true);
                    }
                  }}
                  className={`py-2 px-1 text-[10px] md:text-xs font-display font-bold rounded-xl border flex items-center justify-center gap-1 transition-all ${
                    cameraMode === 'real' 
                      ? "bg-emerald-50 border-emerald-200 text-emerald-700 font-bold" 
                      : "bg-amber-50 border-amber-200 text-amber-700"
                  }`}
                  id="btn-toggle-cam-mode"
                >
                  {cameraMode === 'real' ? "📹 Flux Réel" : "🤖 Lots Démo"}
                </button>

                <button
                  type="button"
                  onClick={clearCapturedPages}
                  className="py-2 px-1 bg-white hover:bg-[#fff0f3] text-[#c9184a] font-display font-bold text-[10px] md:text-xs rounded-xl transition-all border border-pastel-pink/30 flex items-center justify-center"
                  id="btn-clear-captured-lot"
                >
                  Réinitialiser
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Grid Gallery for Captured Pages as Thumbnails */}
      <div className="bg-pastel-pink-light/30 border border-pastel-pink p-5 rounded-3xl">
        <div className="flex items-center justify-between mb-4">
          <h5 className="font-display font-bold text-deep-pink text-xs flex items-center gap-2">
            <Grid className="w-4 h-4 text-chic-pink" /> Galerie Grid : Pages scannées (Capture Actuelle)
          </h5>
          <span className="bg-white px-2.5 py-1 text-[10px] font-bold text-chic-pink rounded-full border border-pastel-pink/50">
            {scannedPages.length} Lot(s) brut(s)
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {/* Direct File Drag & Drop / Single click importer tile */}
          <label 
            onDragOver={(e) => { e.preventDefault(); setDragOverImport(true); }}
            onDragLeave={() => setDragOverImport(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOverImport(false);
              if (e.dataTransfer.files?.[0]) {
                handleFileUpload(e.dataTransfer.files[0]);
              }
            }}
            className={`border-2 border-dashed rounded-xl p-3 flex flex-col items-center justify-center text-center cursor-pointer min-h-[175px] transition-all select-none ${
              dragOverImport 
                ? "border-deep-pink bg-[#fff0f3] text-deep-pink" 
                : "border-pastel-pink hover:border-deep-pink bg-white text-pastel-pink-dark hover:bg-pastel-pink-light/10"
            }`}
          >
            <input 
              type="file" 
              className="hidden" 
              onChange={(e) => {
                if (e.target.files?.[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
              accept="image/*"
            />
            <Upload className={`w-8 h-8 mb-2 text-chic-pink ${dragOverImport ? "animate-bounce" : ""}`} />
            <span className="text-[10px] font-bold uppercase tracking-wider text-deep-pink">Importer un fichier</span>
            <p className="text-[9px] text-stone-400 mt-1">Glissez d'autres captures ou cliquez pour charger</p>
          </label>

          {/* Scanned Pages list */}
          {scannedPages.map((page, index) => {
            const hasQualityIssues = page.isBlurred || page.isFoldedText;
            return (
              <div 
                key={page.id} 
                className={`rounded-xl p-3 border shadow-clay-sm flex flex-col justify-between overflow-hidden transition-all ${
                  hasQualityIssues 
                    ? "bg-red-50/50 border-red-500 ring-2 ring-red-300 animate-pulse" 
                    : "bg-white border-pastel-pink"
                }`}
              >
                {hasQualityIssues && (
                  <div className="bg-red-600 text-white text-[8px] font-bold text-center py-0.5 rounded uppercase tracking-wider mb-1 flex items-center justify-center gap-0.5 font-mono">
                    <span>📷⚠️ RE-SCAN REQUIS</span>
                  </div>
                )}
                <div className="relative h-20 bg-stone-50 rounded-lg flex items-center justify-center text-xs text-stone-400 font-serif border border-stone-200 overflow-hidden mb-2">
                  {page.customPreview ? (
                    <img src={page.customPreview} className="absolute inset-0 w-full h-full object-cover z-0" alt="Capture Réelle" />
                  ) : null}
                  
                  {/* Miniature style register content */}
                  <div className={`p-1.5 w-full h-full flex flex-col justify-between scale-95 relative z-10 ${page.customPreview ? 'bg-black/60 text-white' : 'text-stone-800'}`}>
                    <div className="flex justify-between items-center text-[5.5px] font-sans">
                      <span className={page.customPreview ? 'text-white font-medium' : 'text-stone-400'}>BEC: {page.numBEC}</span>
                      <span className={page.customPreview ? 'text-white font-medium' : 'text-stone-400'}>Tome {page.numTome}</span>
                    </div>
                    <div className="text-center font-bold text-[7.5px] leading-tight font-display">
                      {page.typeActe} #{page.numActe}
                    </div>
                    <div className="flex justify-between text-[4.5px] font-sans uppercase">
                      <span className={page.customPreview ? 'text-white/80' : 'text-stone-400'}>{page.captureTime}</span>
                      <span className="bg-chic-pink text-white font-bold px-1.5 rounded text-[5px] scale-90">
                        {page.customPreview ? 'SNAP' : 'BRUT'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[9px] font-bold text-stone-700 truncate" title={page.filename}>{page.filename}</div>
                  <div className="flex justify-between items-center text-[9px] mb-1">
                  <span className="text-[8px] font-mono font-medium text-stone-400">{page.id}</span>
                  <span className="px-1.5 py-0.5 rounded-full bg-bubble-pink text-chic-pink text-[8px] font-bold uppercase font-sans font-semibold">
                    {page.status}
                  </span>
                </div>
              </div>

              {/* Edit / Delete control buttons */}
              <div className="flex gap-1 mt-1.5 pt-1.5 border-t border-pastel-pink/20">
                <button
                  type="button"
                  onClick={() => setEditingPage(page)}
                  className="flex-1 py-1 px-1.5 bg-pastel-pink-light/60 text-deep-pink hover:bg-chic-pink hover:text-white transition-all rounded-lg text-[9px] font-bold font-sans text-center flex items-center justify-center gap-1 cursor-pointer"
                  id={`btn-edit-capture-${page.id}`}
                >
                  <Edit2 className="w-2.5 h-2.5" /> Modifier
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setScannedPages(prev => prev.filter(p => p.id !== page.id));
                  }}
                  className="py-1 px-1.5 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition-all rounded-lg text-[9px] font-bold font-sans text-center flex items-center justify-center cursor-pointer"
                  title="Supprimer cette capture"
                  id={`btn-delete-capture-${page.id}`}
                >
                  <Trash2 className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>
          );
        })}
        </div>
      </div>

      {/* Validation Action Button for step 1 */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onValidateStep1}
          disabled={scannedPages.length === 0}
          className={`px-8 py-3.5 bg-rose-800 hover:bg-rose-900 text-white font-display font-bold text-sm rounded-2xl shadow-md transition-all flex items-center gap-2 ${
            scannedPages.length === 0 ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
          }`}
          id="btn-validate-step-1"
        >
          <span>Valider le Lot & Aller à l'Étape 2 (Contrôle Qualité) ➡️</span>
        </button>
      </div>

      {/* High-Fidelity Capture Modify Modal Overlay */}
      {editingPage && (
        <div className="fixed inset-0 z-55 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-clay-lg border border-pastel-pink animate-fade-in text-left">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-chic-pink to-deep-pink p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4" />
                <h3 className="font-display font-bold text-sm tracking-tight">Modifier la Capture ({editingPage.id})</h3>
              </div>
              <button 
                type="button"
                onClick={() => setEditingPage(null)}
                className="text-white/80 hover:text-white hover:scale-105 transition-all text-sm p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={(e) => {
              e.preventDefault();
              handleUpdatePageInModal(editingPage);
            }} className="p-6 space-y-4">
              
              {/* Document Image Source & Swap */}
              <div className="p-4 bg-pastel-pink-light/20 rounded-2xl border border-pastel-pink/30 flex flex-col items-center">
                
                {modalCamActive ? (
                  <div className="relative w-full max-w-sm h-52 bg-black rounded-xl border-2 border-deep-pink overflow-hidden flex items-center justify-center shadow-inner">
                    {/* Flash effect overlay */}
                    {flashActive && (
                      <div className="absolute inset-0 z-40 bg-white animate-fade-out" />
                    )}
                    
                    {cameraMode === 'real' ? (
                      <video 
                        ref={modalVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="absolute inset-0 w-full h-full object-cover z-0"
                      />
                    ) : (
                      <div className="absolute inset-0 bg-[#fcf8f2] flex flex-col justify-between p-4 border border-[#e8dcc4] font-serif select-none pointer-events-none text-xs z-0">
                        <div className="flex justify-between items-center text-[8px] font-sans font-bold text-stone-500 uppercase">
                          <span>Appareil Virtuel</span>
                          <span className="text-red-500 animate-pulse flex items-center gap-1 font-sans">
                            <span className="w-1.5 h-1.5 bg-red-500 rounded-full" /> LIVE
                          </span>
                        </div>
                        <div className="space-y-1 my-1">
                          <div className="text-right font-bold text-xs text-[#8b5a2b]">NOUVEL ACTE - عقد جديد</div>
                          <div className="h-1 bg-stone-300 w-3/4 ml-auto rounded" />
                          <div className="h-1 bg-stone-300 w-5/6 ml-auto rounded" />
                          <div className="h-1 bg-stone-200/50 w-2/3 ml-auto rounded" />
                        </div>
                        <div className="flex justify-between items-center text-[8px] font-sans text-stone-400">
                          <span>{editingPage.id}</span>
                          <span>Code BEC: {editingPage.numBEC}</span>
                        </div>
                      </div>
                    )}

                    {/* Calibration Target Markings Overlaid On Top */}
                    <div className="absolute inset-0 z-10 pointer-events-none select-none flex items-center justify-center">
                      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 border-t border-dashed border-deep-pink/30" />
                      <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 border-l border-dashed border-deep-pink/30" />
                      
                      <div className="absolute w-[80%] h-[80%] border border-deep-pink/40 rounded-xl">
                        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-deep-pink" />
                        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-deep-pink" />
                        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-deep-pink" />
                        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-deep-pink" />
                      </div>
                      
                      {/* Interactive scanning animation line */}
                      <div className="absolute inset-x-0 w-full h-[2px] bg-red-400 opacity-70 animate-scan" style={{ top: '40%' }} />
                    </div>

                    {/* Shutter snapshot trigger button */}
                    <button
                      type="button"
                      onClick={handleSnapshotInModal}
                      className="absolute bottom-3 z-20 bg-deep-pink hover:bg-[#ff1e56] text-white py-1.5 px-4 rounded-full text-[10px] font-extrabold shadow-clay-sm cursor-pointer flex items-center gap-1.5 hover:scale-105 active:scale-95 transition-all text-center uppercase tracking-wider"
                    >
                      <Camera className="w-3.5 h-3.5" /> Prendre Photo / Capturer
                    </button>
                  </div>
                ) : (
                  <div className="relative w-64 h-40 bg-[#faf4ea] rounded-xl border border-[#decbb0] overflow-hidden flex items-center justify-center shadow-inner">
                    {editingPage.customPreview ? (
                      <img src={editingPage.customPreview} className="absolute inset-0 w-full h-full object-contain" alt="Aperçu" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="p-3 text-center text-stone-500 font-serif text-[9px] leading-tight flex flex-col justify-between h-full w-full">
                        <div className="font-sans font-bold text-[8px] text-stone-400 uppercase tracking-widest">Aperçu Registre</div>
                        <div className="font-display font-medium text-[11px] text-amber-900">{editingPage.typeActe} #{editingPage.numActe}</div>
                        <div className="text-stone-400">Tome {editingPage.numTome}</div>
                      </div>
                    )}
                  </div>
                )}

                <div className="mt-3.5 w-full text-center flex flex-col sm:flex-row items-center justify-center gap-2">
                  {modalCamActive ? (
                    <>
                      <button
                        type="button"
                        onClick={() => setModalCamActive(false)}
                        className="bg-stone-100 hover:bg-stone-200 text-stone-700 px-3.5 py-1.5 transition-all rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer border border-stone-200"
                      >
                        <X className="w-3.5 h-3.5" /> Annuler la caméra
                      </button>

                      <button
                        type="button"
                        onClick={() => setCameraMode(prev => prev === 'real' ? 'simulated' : 'real')}
                        className="bg-white hover:bg-stone-50 border border-pastel-pink text-deep-pink px-3.5 py-1.5 transition-all rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Client: {cameraMode === 'real' ? 'Appareil Physique' : 'Simulation'}
                      </button>
                    </>
                  ) : (
                    <>
                      <label className="cursor-pointer bg-white px-3.5 py-1.5 border border-pastel-pink hover:border-deep-pink transition-all rounded-xl text-stone-700 hover:text-deep-pink hover:bg-pastel-pink-light/10 text-xs font-semibold flex items-center gap-1.5 shadow-xs">
                        <input 
                          type="file" 
                          className="hidden" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (loadEv) => {
                                setEditingPage({
                                  ...editingPage,
                                  filename: file.name,
                                  customPreview: loadEv.target?.result as string
                                });
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          accept="image/*"
                        />
                        📁 Sélectionner fichier
                      </label>

                      <button
                        type="button"
                        onClick={() => setModalCamActive(true)}
                        className="bg-gradient-to-r from-chic-pink to-deep-pink text-white px-3.5 py-1.5 hover:opacity-95 transition-all rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-clay-sm"
                        id="btn-modal-trigger-rescan"
                      >
                        <Camera className="w-3.5 h-3.5" /> 📸 Rescanner l'Acte (Cam)
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Editable Fields Grid */}
              <div className="grid grid-cols-2 gap-3.5">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-stone-700 mb-1">Nom du Fichier</label>
                  <input 
                    type="text" 
                    value={editingPage.filename}
                    onChange={(e) => setEditingPage({ ...editingPage, filename: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Type d'Acte</label>
                  <select 
                    value={editingPage.typeActe}
                    onChange={(e) => setEditingPage({ ...editingPage, typeActe: e.target.value as ActeType })}
                    className="w-full px-3 py-1.5 bg-stone-100 border border-stone-200 rounded-xl text-xs font-medium text-stone-800 focus:outline-hidden focus:border-chic-pink"
                  >
                    <option value="Naissance">Naissance (ولادة)</option>
                    <option value="Décès">Décès (وفاة)</option>
                    <option value="Mariage">Mariage (زواج)</option>
                    <option value="Divorce">Divorce (طلاق)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Numéro Acte</label>
                  <input 
                    type="text" 
                    value={editingPage.numActe}
                    onChange={(e) => setEditingPage({ ...editingPage, numActe: e.target.value })}
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Numéro Tome</label>
                  <input 
                    type="text" 
                    value={editingPage.numTome}
                    onChange={(e) => setEditingPage({ ...editingPage, numTome: e.target.value })}
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Code BEC</label>
                  <select 
                    value={editingPage.numBEC}
                    onChange={(e) => setEditingPage({ ...editingPage, numBEC: e.target.value })}
                    className="w-full px-3 py-1.5 bg-stone-100 border border-stone-200 rounded-xl text-xs font-medium text-stone-800 focus:outline-hidden focus:border-chic-pink"
                  >
                    <option value="BEC-341">Fès Médina (BEC-341)</option>
                    <option value="BEC-220">Marrakech Gueliz (BEC-220)</option>
                    <option value="BEC-105">Rabat Agdal (BEC-105)</option>
                  </select>
                </div>

                <div className="col-span-2 pt-2 border-t border-stone-100 flex gap-4 text-xs font-semibold text-stone-700">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={editingPage.isBlurred} 
                      onChange={(e) => setEditingPage({ ...editingPage, isBlurred: e.target.checked })}
                      className="rounded border-stone-300 text-deep-pink focus:ring-deep-pink"
                    />
                    Image floue
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={editingPage.isFoldedText} 
                      onChange={(e) => setEditingPage({ ...editingPage, isFoldedText: e.target.checked })}
                      className="rounded border-stone-300 text-deep-pink focus:ring-deep-pink"
                    />
                    Pliure / Twya
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={editingPage.isStrikethrough} 
                      onChange={(e) => setEditingPage({ ...editingPage, isStrikethrough: e.target.checked })}
                      className="rounded border-stone-300 text-deep-pink focus:ring-deep-pink"
                    />
                    Acte barré
                  </label>
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-stone-200 flex justify-end gap-2.5">
                <button 
                  type="button" 
                  onClick={() => setEditingPage(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Annuler
                </button>
                <button 
                  type="submit" 
                  className="px-5 py-2 bg-gradient-to-r from-chic-pink to-deep-pink hover:opacity-95 text-white text-xs font-bold rounded-xl shadow-clay-sm transition-all cursor-pointer"
                >
                  💾 Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
