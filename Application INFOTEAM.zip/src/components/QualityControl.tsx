/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  RotateCw, ZoomIn, ZoomOut, Compass, CheckCircle, ChevronLeft, ChevronRight,
  Sparkles, FileText, AlertTriangle, CheckSquare, Square, ToggleLeft, ToggleRight
} from 'lucide-react';
import { PageScan, ActeType } from '../types';

interface QualityControlProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidateStep2: () => void;
  isStep3Unlocked: boolean;
}

export default function QualityControl({
  scannedPages,
  setScannedPages,
  onValidateStep2,
  isStep3Unlocked,
}: QualityControlProps) {
  const [selectedPageIndex, setSelectedPageIndex] = useState(0);
  const [activeCorrectionModal, setActiveCorrectionModal] = useState<'blurry' | 'folded' | 'strike' | null>(null);
  const [successOverlayMessage, setSuccessOverlayMessage] = useState<string | null>(null);
  
  // Local state mirrored from current page
  const page = scannedPages[selectedPageIndex] || null;

  // Make sure we have a selection or fallback if elements are cleared
  useEffect(() => {
    if (scannedPages.length > 0 && selectedPageIndex >= scannedPages.length) {
      setSelectedPageIndex(0);
    }
  }, [scannedPages, selectedPageIndex]);

  if (!page) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center border-2 border-pastel-pink/50">
        <p className="font-sans text-sm text-pastel-pink-dark">Veuillez d'abord capturer des pages de registre à l'Étape 1 🎞️</p>
      </div>
    );
  }

  // Update specific fields of the current page
  const updatePage = (fields: Partial<PageScan>) => {
    setScannedPages(prev => prev.map((p, idx) => {
      if (idx === selectedPageIndex) {
        return { ...p, ...fields };
      }
      return p;
    }));
  };

  const handleRotation = () => {
    const nextRot = (page.rotation + 90) % 360;
    updatePage({ rotation: nextRot });
  };

  const handleZoom = (amount: number) => {
    const nextZoom = Math.min(Math.max(page.zoom + amount, 0.8), 1.8);
    updatePage({ zoom: parseFloat(nextZoom.toFixed(1)) });
  };

  const toggleDeskew = () => {
    updatePage({ deskew: !page.deskew });
  };

  const toggleBinarized = () => {
    updatePage({ binarized: !page.binarized });
  };

  // Render simulated Arabic cursive text to feel authentic
  const renderLedgerContent = () => {
    // Determine styled classes
    let filterClass = "";
    if (page.binarized) {
      filterClass = "grayscale contrast-200 brightness-150 invert-0";
    }
    
    // Rotate class
    let rotClass = "rotate-0";
    if (page.rotation === 90) rotClass = "rotate-90";
    if (page.rotation === 180) rotClass = "rotate-180";
    if (page.rotation === 270) rotClass = "rotate-270";

    // Zoom scale styling
    const styleObj = {
      transform: `scale(${page.zoom}) ${page.deskew ? 'rotate(0deg)' : 'rotate(-2.5deg)'}`,
      transition: 'all 0.3s ease-in-out',
    };

    return (
      <div className="w-full h-full relative overflow-hidden bg-[#faf4ea] rounded-xl border border-[#decbb0] shadow-inner flex flex-col justify-between p-6">
        
        {/* Real-time filters and transforms wrapper */}
        {page.customPreview ? (
          <div 
            style={styleObj}
            className={`w-full h-full flex items-center justify-center ${filterClass} ${rotClass}`}
          >
            <img 
              src={page.customPreview} 
              className="max-h-full max-w-full object-contain mx-auto" 
              alt="Scan Registre" 
              referrerPolicy="no-referrer"
            />
          </div>
        ) : (
          <div 
            style={styleObj}
            className={`w-full h-full flex flex-col justify-between ${filterClass} ${rotClass}`}
          >
            {/* Header */}
            <div className="flex justify-between items-start border-b border-[#c8b495] pb-2 text-[10px]">
              <div className="text-stone-600 font-sans tracking-wider">
                <strong>ROYAUME DU MAROC</strong><br />
                MUNICIPALITÉ DE FÈS
              </div>
              <div className="text-right text-stone-600 font-sans">
                <strong>OFFICE DEL ÉTAT CIVIL</strong><br />
                {page.numBEC}
              </div>
            </div>

            {/* Main Book columns */}
            <div className="grid grid-cols-12 gap-2 my-4 h-full items-stretch">
              {/* Margins */}
              <div className="col-span-3 border-r border-[#decbb0] pr-1.5 flex flex-col justify-between text-[8px] text-[#c9184a] font-serif font-bold text-center">
                <div>
                  <span>الملاحظات الهامشية</span>
                  <span className="block text-[6px] text-stone-400">Mentions Marginales</span>
                </div>
                
                {/* Optional marginal line indicator */}
                <div className="border border-dashed border-[#ff8fa3] bg-pastel-pink-light/30 p-1 rounded my-1 text-[7px]">
                  {page.isOpeningPage && "📚 Page Ouverture"}
                  {page.isClosingPage && "🔒 Page Clôture"}
                  {page.isFoldedText && "⚠️ Twya (Pliure)"}
                  {page.isStrikethrough && "⚠️ Acte Barré"}
                </div>

                <div className="text-[7px] text-stone-400">TOME: {page.numTome}</div>
              </div>

              {/* Core certificate details */}
              <div className="col-span-9 pl-2 text-right font-serif flex flex-col justify-between">
                <div>
                  <h3 className="text-center font-bold text-lg text-amber-900 border-b border-[#e6cca0] pb-1 font-display">
                    رسم {page.typeActe === 'Naissance' ? 'الولادة' : page.typeActe === 'Décès' ? 'الوفاة' : page.typeActe === 'Mariage' ? 'الزواج' : 'الطلاق'}
                  </h3>
                  <span className="block text-left text-[8px] text-stone-400 font-sans">Acte de {page.typeActe}</span>
                </div>

                {/* Dynamic simulated handwriting Arabic blocks */}
                <div className="space-y-1 my-3 text-stone-800">
                  <div className="flex justify-between items-center text-[10px] w-full">
                    <span className="text-stone-400 font-sans text-[8px]">Numéro d'acte: {page.numActe}</span>
                    <span className="font-bold font-display text-amber-950">في يوم العاشر من أبريل لعام ألف وتسعمائة وأربعة وتسعون</span>
                  </div>
                  <div className="h-0.5 bg-stone-300 w-full" />
                  <div className="font-bold flex justify-between items-center text-[11px]">
                    <span className="text-stone-400 font-sans text-[8px]">Nom: {page.operatorA.nom}</span>
                    <span className="text-amber-900">ولد من الجنس {page.typeActe === 'Naissance' ? 'الأنثوي' : 'الذكري'} : فاطمة خلوى</span>
                  </div>
                  <div className="h-0.5 bg-stone-300 w-5/6 ml-auto" />
                  <div className="text-[9px] text-stone-600">
                    والدها أحمد خلوى، والدتها عائشة شقرون، المقيمين بالفاس المدينة
                  </div>
                </div>

                <div className="flex justify-between items-center text-[8px] text-stone-400 border-t border-[#decbb0] pt-1">
                  <span>INDEXED: NO</span>
                  <span className="font-semibold text-stone-600">القاضي المفوض ببلدية فاس</span>
                </div>
              </div>
            </div>

            {/* Footer of the page */}
            <div className="border-t border-[#c8b495] pt-1 flex justify-between text-[8px] text-stone-400 font-sans">
              <span>FILE: {page.filename}</span>
              <span>IDENTIFIANT ARCHIVE REGIONAL</span>
            </div>
          </div>
        )}

        {/* Static Skew laser indicator if page deskewed is active/inactive */}
        {!page.deskew && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-[8px] font-bold font-mono">
            <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse" /> SKEWED 2.5°
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6" id="preparation-quality-control">
      
      {/* Current page header status */}
      <div className="flex items-center justify-between bg-stone-100 p-3.5 rounded-2xl border border-stone-200">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 rounded-full bg-amber-600 animate-pulse" />
          <h4 className="font-display font-bold text-stone-700 text-xs uppercase">
            Document en cours d'analyse : <span className="text-amber-900 font-mono">{page.filename}</span> ({page.typeActe})
          </h4>
        </div>
        <div className="text-[10px] font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200 px-2.5 py-1 rounded-lg">
          Qualité : Brut
        </div>
      </div>

      {/* Split-Screen layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        
        {/* Left Side: interactive photo viewer inside simulated microchip block */}
        <div className="space-y-3">
          <div className="h-[430px] bg-white rounded-3xl p-4 shadow-clay-md border border-pastel-pink relative">
            {renderLedgerContent()}
          </div>

          {/* Action buttons under image */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <button
              onClick={handleRotation}
              className="py-2 bg-white text-deep-pink border border-pastel-pink rounded-xl shadow-clay-sm hover:bg-pastel-pink-light/30 transition-all text-xs font-display font-semibold flex items-center justify-center gap-1"
              id="qc-btn-rotate"
            >
              <RotateCw className="w-3.5 h-3.5" /> Rotation 90°
            </button>
            
            <div className="flex rounded-xl overflow-hidden border border-pastel-pink shadow-clay-sm">
              <button
                onClick={() => handleZoom(0.1)}
                className="w-1/2 py-2 bg-white text-deep-pink hover:bg-pastel-pink-light/30 text-xs font-bold flex justify-center items-center"
                id="qc-btn-zoom-in"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleZoom(-0.1)}
                className="w-1/2 py-2 bg-white text-deep-pink hover:bg-pastel-pink-light/30 border-l border-pastel-pink/30 text-xs font-bold flex justify-center items-center"
                id="qc-btn-zoom-out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={toggleDeskew}
              className={`py-2 px-1 text-xs border rounded-xl shadow-clay-sm font-display font-semibold flex items-center justify-center gap-1 transition-all ${
                page.deskew 
                  ? "bg-chic-pink text-white border-chic-pink" 
                  : "bg-white text-deep-pink border-pastel-pink hover:bg-pastel-pink-light/30"
              }`}
              id="qc-btn-deskew"
            >
              <Compass className="w-3.5 h-3.5" /> {page.deskew ? "Redressé ✔" : "Redresser Page"}
            </button>

            <button
              onClick={toggleBinarized}
              className={`py-2 px-1 text-xs border rounded-xl shadow-clay-sm font-display font-semibold flex items-center justify-center gap-1 transition-all ${
                page.binarized 
                  ? "bg-stone-900 text-white border-stone-900" 
                  : "bg-white text-deep-pink border-pastel-pink hover:bg-pastel-pink-light/30"
              }`}
              id="qc-btn-binarize"
            >
              <Sparkles className="w-3.5 h-3.5" /> {page.binarized ? "Binarisé ✔" : "Saisie N&B Net"}
            </button>
          </div>
        </div>

        {/* Right Side: Quality Form in "Cute Pink" workspace */}
        <div className="bg-white rounded-3xl p-6 shadow-clay-md border-2 border-pastel-pink/50 space-y-5">
          <div className="flex items-center gap-2 border-b border-pastel-pink/30 pb-3">
            <span className="p-2 bg-bubble-pink rounded-xl text-chic-pink">
              <FileText className="w-5 h-5" />
            </span>
            <div>
              <h4 className="font-display font-bold text-deep-pink text-sm uppercase">INDEXATION MÉTADONNÉES</h4>
              <p className="text-[10px] text-stone-400 font-semibold uppercase tracking-wider">Identifiants obligatoires du registre</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-display font-bold text-deep-pink mb-1">Type d'acte d'État Civil</label>
              <select
                value={page.typeActe}
                onChange={(e) => updatePage({ typeActe: e.target.value as ActeType })}
                className="w-full px-3 py-2 bg-pastel-pink-light/30 border border-pastel-pink rounded-xl text-xs text-stone-800 font-medium focus:outline-hidden focus:border-chic-pink"
                id="qc-select-type"
              >
                <option value="Naissance">Naissance (ﻋﻘﺪ ولادة)</option>
                <option value="Décès">Décès (شهادة وفاة)</option>
                <option value="Mariage">Mariage (رسم زواج)</option>
                <option value="Divorce">Divorce (رسم طلاق)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-display font-bold text-deep-pink mb-1">Numéro du BEC</label>
              <input
                type="text"
                value={page.numBEC}
                onChange={(e) => updatePage({ numBEC: e.target.value })}
                className="w-full px-3 py-1.5 bg-pastel-pink-light/30 border border-pastel-pink rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                placeholder="Ex. BEC-341"
                id="qc-input-bec"
              />
            </div>

            <div>
              <label className="block text-[11px] font-display font-bold text-deep-pink mb-1">Numéro du Tome</label>
              <input
                type="text"
                value={page.numTome}
                onChange={(e) => updatePage({ numTome: e.target.value })}
                className="w-full px-3 py-1.5 bg-pastel-pink-light/30 border border-pastel-pink rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                placeholder="Ex. 12"
                id="qc-input-tome"
              />
            </div>

            <div>
              <label className="block text-[11px] font-display font-bold text-deep-pink mb-1">Numéro de l'Acte</label>
              <input
                type="text"
                value={page.numActe}
                onChange={(e) => updatePage({ numActe: e.target.value })}
                className="w-full px-3 py-1.5 bg-pastel-pink-light/30 border border-pastel-pink rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-chic-pink"
                placeholder="Ex. 248"
                id="qc-input-acte"
              />
            </div>
          </div>

          {/* Checklist Spécificités */}
          <div className="bg-bubble-pink/30 p-3.5 rounded-2xl border border-pastel-pink/30 space-y-2">
            <h5 className="text-[11px] font-display font-bold text-deep-pink uppercase tracking-wider">Spécificités de Page</h5>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => updatePage({ isOpeningPage: !page.isOpeningPage })}
                className="flex items-center gap-2 text-left bg-white p-2 border border-pastel-pink rounded-xl transition-all hover:bg-pastel-pink-light/45"
                id="qc-check-opening"
              >
                {page.isOpeningPage ? (
                  <CheckSquare className="w-4 h-4 text-chic-pink" />
                ) : (
                  <Square className="w-4 h-4 text-pastel-pink-dark" />
                )}
                <span className="font-medium text-stone-700">Page d'ouverture</span>
              </button>

              <button
                onClick={() => updatePage({ isClosingPage: !page.isClosingPage })}
                className="flex items-center gap-2 text-left bg-white p-2 border border-pastel-pink rounded-xl transition-all hover:bg-pastel-pink-light/45"
                id="qc-check-closing"
              >
                {page.isClosingPage ? (
                  <CheckSquare className="w-4 h-4 text-chic-pink" />
                ) : (
                  <Square className="w-4 h-4 text-pastel-pink-dark" />
                )}
                <span className="font-medium text-stone-700">Page de clôture</span>
              </button>
            </div>
          </div>

          {/* Checklist Qualité (Alerte Rose Foncé) */}
          <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200 space-y-3">
            <h5 className="text-[11px] font-display font-bold text-amber-800 uppercase tracking-widest flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Contrôle Qualité Saisie (Alerte)
            </h5>
            
            <div className="space-y-2 text-xs">
              <button
                onClick={() => {
                  const nextVal = !page.isBlurred;
                  updatePage({ isBlurred: nextVal });
                  if (nextVal) {
                    setActiveCorrectionModal('blurry');
                  }
                }}
                className={`w-full flex items-center justify-between bg-white p-2 border rounded-xl transition-all hover:bg-amber-100/50 cursor-pointer ${
                  page.isBlurred ? 'border-amber-500 bg-amber-50/50' : 'border-amber-200'
                }`}
                id="qc-qual-blurry"
              >
                <span className="font-medium text-amber-900">Image floue (besoin de rescanner)</span>
                {page.isBlurred ? (
                  <span className="px-2 py-0.5 bg-amber-500 text-white rounded-lg text-[9px] font-bold">ALERTE</span>
                ) : (
                  <span className="text-stone-400 text-[10px]">Non détecté</span>
                )}
              </button>

              <button
                onClick={() => {
                  const nextVal = !page.isFoldedText;
                  updatePage({ isFoldedText: nextVal });
                  if (nextVal) {
                    setActiveCorrectionModal('folded');
                  }
                }}
                className={`w-full flex items-center justify-between bg-white p-2 border rounded-xl transition-all hover:bg-amber-100/50 cursor-pointer ${
                  page.isFoldedText ? 'border-red-500 bg-red-50/50' : 'border-amber-200'
                }`}
                id="qc-qual-folded"
              >
                <div className="flex flex-col text-left">
                  <span className="font-medium text-amber-900">Texte masqué / pliure (Twya)</span>
                  <span className="text-[8px] text-stone-400">Pli caractéristique du papier d'archive</span>
                </div>
                {page.isFoldedText ? (
                  <span className="px-2 py-0.5 bg-red-500 text-white rounded-lg text-[9px] font-bold animate-pulse">ACTIVE TWYA</span>
                ) : (
                  <span className="text-stone-400 text-[10px]">Non détecté</span>
                )}
              </button>

              <button
                onClick={() => {
                  const nextVal = !page.isStrikethrough;
                  updatePage({ isStrikethrough: nextVal });
                  if (nextVal) {
                    setActiveCorrectionModal('strike');
                  }
                }}
                className={`w-full flex items-center justify-between bg-white p-2 border rounded-xl transition-all hover:bg-amber-100/50 cursor-pointer ${
                  page.isStrikethrough ? 'border-red-500 bg-red-50/50' : 'border-amber-200'
                }`}
                id="qc-qual-strike"
              >
                <span className="font-medium text-amber-900">Acte annulé / barré</span>
                {page.isStrikethrough ? (
                  <span className="px-2 py-0.5 bg-red-500 text-white rounded-lg text-[9px] font-bold">BARRÉ</span>
                ) : (
                  <span className="text-stone-400 text-[10px]">Non détecté</span>
                )}
              </button>

              <div className="flex items-center justify-between bg-white p-2 border border-amber-200 rounded-xl">
                <span className="font-medium text-amber-900">Nombre de parties de l'acte</span>
                <select
                  value={page.partsCount}
                  onChange={(e) => updatePage({ partsCount: parseInt(e.target.value) })}
                  className="px-2.5 py-1 bg-amber-100/30 border border-amber-200 rounded-lg text-xs font-bold text-amber-800"
                  id="qc-select-parts"
                >
                  <option value="1">1 partie</option>
                  <option value="2">2 parties</option>
                  <option value="3">3 parties ou plus</option>
                </select>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* 🔟 Navigation des Pages Traitées (de 1 à 10) positionnée dans le bas */}
      <div className="bg-white p-4 rounded-2xl border-2 border-stone-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4 my-2 select-none">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-rose-700 rounded-full animate-pulse" />
          <span className="text-xs font-bold text-stone-700 uppercase">
            Traitement des Documents : Page {selectedPageIndex + 1} sur {scannedPages.length}
          </span>
        </div>

        {/* List of numbered buttons 1 to 10 */}
        <div className="flex flex-wrap gap-1.5 items-center justify-center">
          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.max(0, prev - 1))}
            disabled={selectedPageIndex === 0}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
            id="qc-prev-btn-bottom"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Préc.
          </button>

          {scannedPages.map((p, idx) => {
            const hasIssue = p.isBlurred || p.isFoldedText;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPageIndex(idx)}
                className={`w-9 h-8 rounded-lg font-mono text-xs font-bold transition-all border flex items-center justify-center gap-0.5 ${
                  selectedPageIndex === idx 
                    ? "bg-rose-800 text-white border-rose-800 shadow-sm font-black scale-110" 
                    : hasIssue
                      ? "bg-red-50 text-red-700 border-red-500 hover:bg-red-100 animate-pulse font-extrabold"
                      : "bg-white text-stone-600 border-stone-200 hover:bg-stone-50"
                }`}
                id={`qc-page-btn-bottom-${idx}`}
                title={hasIssue ? "Re-scan Requis ⚠️" : ""}
              >
                {idx + 1}{hasIssue ? "⚠️" : ""}
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.min(scannedPages.length - 1, prev + 1))}
            disabled={selectedPageIndex === scannedPages.length - 1}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
            id="qc-next-btn-bottom"
          >
            Suiv. <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Validation workflow step 2 with strict quality block checks */}
      <div className="pt-4 border-t border-stone-200 space-y-4">
        {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-5 text-xs font-sans text-red-800 flex flex-col md:flex-row gap-4 shadow-sm">
            <div className="text-2xl">⚠️</div>
            <div className="space-y-2 flex-1">
              <span className="font-bold uppercase tracking-wider block text-red-950 font-display">
                ÉLÉMENTS BLOQUANTS DÉTECTÉS - ÉTAPE CONTRÔLE QUALITÉ INTERROMPUE !
              </span>
              <p className="leading-relaxed font-medium">
                Saisie stoppée réglementairement selon la charte d'État Civil. Il est interdit de poursuivre si une page présente un <strong>texte masqué/plié (Twya)</strong>, une <strong>image floue</strong> ou si l'acte est <strong>barré/annulé</strong>.
              </p>
              
              <div className="bg-red-100/50 border border-red-200/60 p-3 rounded-xl font-mono text-[10px] text-red-950 space-y-1">
                <span className="font-bold block uppercase mb-1">Rapport d'erreur enregistré :</span>
                {scannedPages.map((p, idx) => {
                  const issues = [];
                  if (p.isBlurred) issues.push("Image floue");
                  if (p.isFoldedText) issues.push("Texte masqué (pliure / Twya)");
                  if (p.isStrikethrough) issues.push("Acte annulé ou barré");
                  
                  if (issues.length > 0) {
                    return (
                      <div key={p.id} className="flex justify-between items-center bg-white/60 p-1.5 rounded-lg border border-red-200">
                        <span>Page {idx + 1} ({p.id}) : <strong className="text-red-700">{issues.join(", ")}</strong></span>
                        <button
                          onClick={() => {
                            setScannedPages(prev => prev.map((item, i) => i === idx ? { ...item, isBlurred: false, isFoldedText: false, isStrikethrough: false } : item));
                          }}
                          className="bg-green-600 hover:bg-green-700 text-white text-[9px] px-2 py-0.5 rounded-md font-bold uppercase transition-all"
                        >
                          Corriger l'erreur ✅
                        </button>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  onClick={() => {
                    setScannedPages(prev => prev.map(p => ({
                      ...p,
                      isBlurred: false,
                      isFoldedText: false,
                      isStrikethrough: false
                    })));
                  }}
                  className="px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-1.5"
                >
                  ⚡ Corriger toutes les anomalies qualité d'un coup
                </button>
                <p className="text-[10px] text-red-700 italic">
                  Une fois tous les problèmes corrigés de la liste ci-dessus, le bouton de passage à l'étape suivante sera automatiquement libéré.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end gap-3 items-center">
          {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) && (
            <span className="text-xs font-sans font-bold text-red-600 animate-pulse">
              [ Passage Bloqué - Erreurs Qualité en Cours de Résolution ]
            </span>
          )}
          
          <button
            onClick={onValidateStep2}
            disabled={scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough)}
            className={`px-8 py-3.5 font-display font-bold text-sm rounded-2xl shadow-sm transition-all flex items-center gap-2 ${
              scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough)
                ? "bg-stone-200 text-stone-400 border border-stone-300 cursor-not-allowed opacity-50"
                : "bg-rose-800 hover:bg-rose-900 text-white cursor-pointer"
            }`}
            id="btn-validate-step-2"
          >
            <CheckCircle className="w-5 h-5" />
            Corriger & Passer à l'Étape 3 🌸
          </button>
        </div>
      </div>

      {/* Dynamic Correction Modals (triggered after checking quality buttons) */}
      {activeCorrectionModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 transition-all duration-300">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border-2 border-amber-300 transform scale-100 transition-all space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-amber-100 text-amber-800 rounded-2xl">
                <AlertTriangle className="w-6 h-6 animate-bounce" />
              </div>
              <div className="flex-1 space-y-1">
                <h3 className="font-display font-black text-stone-900 text-base uppercase">
                  Instruction de Correction Requise ⚠️
                </h3>
                <p className="text-[10px] text-stone-400 font-bold uppercase tracking-wider">
                  Signalement de Non-Conformité d'Acte
                </p>
              </div>
            </div>

            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 text-xs font-sans text-stone-700 leading-relaxed">
              {activeCorrectionModal === 'blurry' && (
                <p>
                  <strong>Image signalée comme floue :</strong> L'image de l'acte <strong>{page.filename}</strong> n'offre pas la résolution requise pour une reconnaissance ou saisie optimale. Il est recommandé de <strong>re-numériser l'acte</strong> immédiatement.
                </p>
              )}
              {activeCorrectionModal === 'folded' && (
                <p>
                  <strong>Texte masqué / Pliure (Twya) :</strong> Une pliure sur la page au niveau du registre d'archive de Fès masque des lignes d'écriture manuscrite en cursive arabe. Vous devez aplatir le registre et <strong>re-numériser l'acte</strong>.
                </p>
              )}
              {activeCorrectionModal === 'strike' && (
                <p>
                  <strong>Acte annulé ou barré :</strong> Ce paragraphe a été barré ou marqué comme annulé par l'officier de l'État Civil. Si c'est une fausse alerte d'ombrage, renumérisez ou ignorez.
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={() => {
                  // Simulate immediate high-precision re-scan fix!
                  if (activeCorrectionModal === 'blurry') updatePage({ isBlurred: false, zoom: 1.2 });
                  if (activeCorrectionModal === 'folded') updatePage({ isFoldedText: false, deskew: true });
                  if (activeCorrectionModal === 'strike') updatePage({ isStrikethrough: false });
                  
                  setActiveCorrectionModal(null);
                  setSuccessOverlayMessage(
                    "✨ L'appareil de numérisation zénithal a corrigé la page ! L'image est maintenant d'une netteté parfaite, plane et 100% conforme."
                  );
                  setTimeout(() => setSuccessOverlayMessage(null), 8000);
                }}
                className="w-full py-3 bg-green-700 hover:bg-green-800 text-white font-display font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                ⚡ Re-scanner l'acte zénithalement (Corriger l'erreur)
              </button>
              
              <button
                onClick={() => {
                  // Keep the anomaly flag active and close modal
                  setActiveCorrectionModal(null);
                }}
                className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-display font-bold text-xs rounded-xl cursor-pointer transition-all text-center"
              >
                ⚠️ Conserver l'anomalie active pour le rapport
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Instant Dynamic Success Notification Overlay */}
      {successOverlayMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-green-900 text-white px-5 py-4 rounded-2xl shadow-xl border border-green-700 flex gap-3 animate-bounce transition-all">
          <div className="text-xl">✨</div>
          <div className="space-y-1 flex-1">
            <span className="font-bold text-xs font-display uppercase block text-green-200">
              Scanneur Corrigé avec Succès !
            </span>
            <p className="text-[11px] leading-relaxed font-medium">
              {successOverlayMessage}
            </p>
          </div>
          <button 
            onClick={() => setSuccessOverlayMessage(null)}
            className="text-white/50 hover:text-white text-xs font-bold font-sans self-start"
          >
            ✕
          </button>
        </div>
      )}

    </div>
  );
}
