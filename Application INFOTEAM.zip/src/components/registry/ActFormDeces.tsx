/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageScan } from '../../types';
import { Landmark, Link, Calendar, CheckSquare, Square, Minus, Plus, Users, Clock } from 'lucide-react';

interface ActFormDecesProps {
  page: PageScan;
  updatePage: (fields: Partial<PageScan>) => void;
}

type SubTab = 'data' | 'officer' | 'declaration' | 'mother' | 'father' | 'birth';

export default function ActFormDeces({ page, updatePage }: ActFormDecesProps) {
  const [subTab, setSubTab] = useState<SubTab>('data');

  const operator = page.operatorA || {
    prenom: '', nom: '', prenomAr: '', nomAr: '',
    dateGregoirienne: '', dateHegirienne: '', perePrenom: '', merePrenom: ''
  };

  const updateOperator = (fields: Partial<typeof operator>) => {
    updatePage({
      operatorA: {
        ...operator,
        ...fields
      }
    });
  };

  return (
    <div className="bg-[#f3f4f6] p-3 rounded-lg border border-stone-300 shadow-sm font-sans select-none" id="act-form-deces">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
        
        {/* Main form input grid */}
        <div className="md:col-span-12 space-y-3">
          
          {/* Row 1: Language and codes */}
          <div className="bg-white p-2.5 rounded border border-stone-300 md:flex md:justify-between md:items-center space-y-2 md:space-y-0 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-stone-700">لغة التحرير (Langue rédigée):</span>
              <div className="flex gap-2">
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" defaultChecked className="text-[#ea580c] focus:ring-0 rounded" />
                  <span className="font-medium text-[11px]">العربية (Arabe)</span>
                </label>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" className="text-[#ea580c] focus:ring-0 rounded" />
                  <span className="font-medium text-[11px]">Français</span>
                </label>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="bg-teal-100 text-teal-800 border border-teal-200 py-0.5 px-3 rounded font-mono font-bold">
                Tome Code: {page.numTome}
              </span>
              <span className="bg-red-100 text-red-800 border border-red-200 py-0.5 px-3 rounded font-mono font-bold animate-pulse">
                DECÈS | BEC: {page.numBEC}
              </span>
            </div>
          </div>

          {/* Row 2: Year, Number & Death Place */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                سنة الرسم (Année Décès)
              </label>
              <div className="flex gap-1">
                <input
                  type="text"
                  defaultValue="2026"
                  className="w-full p-1 border border-stone-300 rounded font-mono focus:outline-hidden text-center text-stone-800"
                />
                <button type="button" className="p-1.5 bg-stone-100 border border-stone-300 hover:bg-stone-200 rounded text-stone-600 font-bold text-[10px]" id="deces-btn-year-play">
                  ▶
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                رقم الرسم (Numéro Acte Décès)
              </label>
              <input
                type="text"
                value={page.numActe}
                onChange={(e) => updatePage({ numActe: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-semibold font-mono text-center text-stone-850"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-[10px] text-red-700 font-bold mb-1 text-right">
                مكان الوفاة (Lieu de décès)
              </label>
              <input
                type="text"
                defaultValue="المصحة الإقليمية ابن سينا، فاس"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-xs text-stone-800 font-semibold"
                dir="rtl"
              />
            </div>
          </div>

          {/* Row 3: Death Dates & Hours */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                تاريخ الوفاة ميلادي (Date Grégorienne)
              </label>
              <input
                type="text"
                value={operator.dateGregoirienne || '15/05/2026'}
                onChange={(e) => updateOperator({ dateGregoirienne: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-mono text-center text-stone-800"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                تاريخ الوفاة هجري (Date Hégirienne)
              </label>
              <input
                type="text"
                value={operator.dateHegirienne || '26/10/1447'}
                onChange={(e) => updateOperator({ dateHegirienne: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-mono text-center text-stone-800 text-right pr-2"
                dir="rtl"
              />
            </div>

            <div className="md:col-span-2 grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                  على الساعة (À l'heure)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    defaultValue="03"
                    className="w-full p-1.5 pl-6 border border-stone-300 rounded text-center pr-2 font-mono text-stone-800"
                  />
                  <Clock className="w-3.5 h-3.5 text-stone-400 absolute left-2 top-2.5" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                  و الدقيقة (Et minute)
                </label>
                <input
                  type="number"
                  defaultValue="15"
                  className="w-full p-1.5 border border-stone-300 rounded text-center font-mono text-stone-800"
                />
              </div>
            </div>
          </div>

          {/* Row 4: Names & Surnames (Corps VS Margins) */}
          <div className="bg-white p-3 rounded border border-stone-300 space-y-3 text-xs">
            <h5 className="font-bold text-red-900 border-b border-red-100 pb-1 uppercase tracking-wider text-[10px]">
              👤 اسم المتوفى بالصلب و الهامش (Prénoms/Noms du Défunt)
            </h5>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-[9px] text-[#1e293b] font-bold mb-0.5">
                  Prénom Corps FR
                </label>
                <input
                  type="text"
                  value={operator.prenom || 'MOHAMED'}
                  onChange={(e) => updateOperator({ prenom: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded font-semibold text-stone-800"
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-red-800 font-bold mb-0.5">
                  الإسم الشخصي بالصلب AR
                </label>
                <input
                  type="text"
                  value={operator.prenomAr || 'محمد'}
                  onChange={(e) => updateOperator({ prenomAr: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-medium text-stone-800"
                  dir="rtl"
                />
              </div>
              <div>
                <label className="block text-[9px] text-[#1e293b] font-bold mb-0.5">
                  Nom Corps FR
                </label>
                <input
                  type="text"
                  value={operator.nom || 'BENCHEKROUN'}
                  onChange={(e) => updateOperator({ nom: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded font-semibold text-stone-800"
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-red-800 font-bold mb-0.5">
                  الاسم العائلي بالصلب AR
                </label>
                <input
                  type="text"
                  value={operator.nomAr || 'بن شقرون'}
                  onChange={(e) => updateOperator({ nomAr: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-medium text-stone-800"
                  dir="rtl"
                />
              </div>
            </div>
          </div>

          {/* Row 5: Family situation, Gender, Nationalite, Profession, Residence */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                الحالة العائلية (Marital)
              </label>
              <select className="w-full p-1.5 border border-stone-300 rounded font-sans text-stone-700 bg-stone-50" id="deces-select-marital">
                <option value="Marie">Marié(e) / متزوج</option>
                <option value="Celibataire">Célibataire / عازب</option>
                <option value="Veuf">Veuf(ve) / أرمل</option>
                <option value="Divorce">Divorcé(e) / مطلق</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                جنسه (Sexe)
              </label>
              <select className="w-full p-1.5 border border-stone-300 rounded font-sans text-stone-700 bg-stone-50" id="deces-select-sexe">
                <option value="Male">Masculin / ذكر</option>
                <option value="Femelle">Féminin / أنثى</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                جنسيته (Nationalité)
              </label>
              <input
                type="text"
                defaultValue="مغربية"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-semibold text-[#0a0a0a]"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                مهنته (Profession)
              </label>
              <input
                type="text"
                defaultValue="متقاعد"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-semibold text-[#0a0a0a]"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                عنوان السكن (Résidence)
              </label>
              <input
                type="text"
                defaultValue="زقاق الزهور، عين قادوس بفاس"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-semibold text-[#0a0a0a]"
                dir="rtl"
              />
            </div>
          </div>

          {/* Subtabs viewport */}
          <div className="bg-white rounded border border-stone-300 overflow-hidden text-xs">
            
            {/* Nav */}
            <div className="flex border-b border-stone-300 bg-[#f8fafc] text-[11px] font-bold text-stone-500 overflow-x-auto select-none">
              <button
                type="button"
                onClick={() => setSubTab('data')}
                className={`py-2 px-3 border-r border-stone-300 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'data' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                💾 البيانات (Infos Décès)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('officer')}
                className={`py-2 px-3 border-r border-stone-300 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'officer' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                ⚖️ ضابط ح م (Officier)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('declaration')}
                className={`py-2 px-3 border-r border-stone-300 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'declaration' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                🗣️ التصريح (Déclarant)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('father')}
                className={`py-2 px-3 border-r border-stone-300 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'father' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                👨‍🦳 الأب (Père)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('mother')}
                className={`py-2 px-3 border-r border-stone-300 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'mother' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                👩‍🦰 الأم (Mère)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('birth')}
                className={`py-2 px-3 flex items-center gap-1 shrink-0 transition-all ${
                  subTab === 'birth' ? "bg-white text-red-800 font-black border-t-2 border-t-red-650" : "hover:text-red-700 hover:bg-stone-50"
                }`}
              >
                👶 الولادة (Lieu/Date Naiss.)
              </button>
            </div>

            {/* Pane contents */}
            <div className="p-3 bg-white text-xs space-y-3">
              {subTab === 'data' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1">Mélange des d’annotations / remarques de décès</label>
                    <textarea
                      rows={2}
                      defaultValue="Liaison directe avec l'acte de naissance d'origine d'après la notice n° 341. Certifié conforme."
                      className="w-full text-xs font-sans p-2 border border-stone-200 rounded focus:outline-hidden"
                    />
                  </div>
                  <div className="space-y-1 bg-stone-50 p-2.5 rounded border border-stone-200">
                    <span className="font-bold text-[10px] text-[#b91c1c] block">⚖️ Constat Médical Obligatoire:</span>
                    <p className="text-[10px] text-stone-500">Certificat de décès fourni par la Clinique Ibn Sina sous référence REF-M-9921.</p>
                  </div>
                </div>
              )}

              {subTab === 'officer' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 animate-fadeIn">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      بمقتضى التفويض الصادر عن رئيس (Par délégation de l'Officier Chef)
                    </label>
                    <input
                      type="text"
                      defaultValue="ضابط الحالة المدنية بالنيابة"
                      className="w-full p-2 border border-stone-300 rounded text-right text-stone-850 font-display"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-red-700 font-bold mb-1 text-right animate-pulse">
                      اسم ضابط الحالة المدنية المتلقي (Nom de l'Officier)
                    </label>
                    <input
                      type="text"
                      defaultValue="عبد اللطيف البهلي"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display font-medium text-stone-850"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'declaration' && (
                <div>
                  <label className="block text-[10px] text-stone-405 font-bold mb-1 text-right">
                    صاحب التصريح بالوفاة وعلاقته بالمتوفى (Déclarant du Décès)
                  </label>
                  <input
                    type="text"
                    defaultValue="عبد الكريم بن شقرون، ابن المتوفى البالغ من العمر 42 سنة"
                    className="w-full p-2 border border-stone-300 rounded text-right text-stone-850 font-display font-semibold"
                    dir="rtl"
                  />
                </div>
              )}

              {subTab === 'father' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      اسم والد المتوفى بالكامل (Nom Père)
                    </label>
                    <input
                      type="text"
                      defaultValue="عبد القادر بن شقرون"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800 font-semibold"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      حالة والده (Son État)
                    </label>
                    <input
                      type="text"
                      defaultValue="متوفى"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-red-700 font-bold"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'mother' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      اسم والدة المتوفى الكامل (Nom Mère)
                    </label>
                    <input
                      type="text"
                      defaultValue="فاطمة الصقلي"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800 font-semibold"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      حالة والدته (Son État)
                    </label>
                    <input
                      type="text"
                      defaultValue="متوفاة"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-red-700 font-bold"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'birth' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right animate-pulse">
                      مكان ولادة المتوفى الأصلي (Lieu de Naissance Défunt)
                    </label>
                    <input
                      type="text"
                      defaultValue="مدينة فاس، حي السويقة القديم"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-stone-800 font-medium"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      تاريخ ولادة المتوفى الأصلي (Date de Naissance)
                    </label>
                    <input
                      type="text"
                      defaultValue="1948-03-12"
                      className="w-full p-2 border border-stone-300 rounded text-center text-stone-800 font-mono font-bold"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
