/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RefreshCw, Play, CheckCircle2, Circle, Search, Ban } from 'lucide-react';

interface AssignmentRow {
  id: string; // generated
  bec: string;
  lot: string;
  agent: string;
  dateAff: string;
  objet: string;
  nbActes: number;
  nbControles: number;
  reste: number;
  statut: 'EC' | 'TERM' | 'NON_DEC'; // En Cours, Terminé, Non Déclaré
}

export default function GestionAffectations() {
  const [filterLot, setFilterLot] = useState('');
  const [selectedRowId, setSelectedRowId] = useState<string | null>("row-1");
  const [assignmentList, setAssignmentList] = useState<AssignmentRow[]>([
    {
      id: "row-1",
      bec: "855",
      lot: "22008001085508",
      agent: "Nouhaila ADDA",
      dateAff: "6/23/2026 10:14",
      objet: "Controle",
      nbActes: 367,
      nbControles: 2,
      reste: 365,
      statut: "EC"
    },
    {
      id: "row-2",
      bec: "855",
      lot: "22004001085517",
      agent: "HAFIDA ELHAMRI",
      dateAff: "6/23/2026 10:15",
      objet: "Controle",
      nbActes: 32,
      nbControles: 3,
      reste: 29,
      statut: "EC"
    },
    {
      id: "row-3",
      bec: "855",
      lot: "22004001085501",
      agent: "Hajar Mir",
      dateAff: "6/23/2026 10:11",
      objet: "Controle",
      nbActes: 132,
      nbControles: 4,
      reste: 128,
      statut: "EC"
    },
    {
      id: "row-4",
      bec: "855",
      lot: "22003001085514",
      agent: "Bouchra Oudra",
      dateAff: "6/23/2026 10:30",
      objet: "Controle",
      nbActes: 34,
      nbControles: 6,
      reste: 28,
      statut: "TERM"
    },
    {
      id: "row-5",
      bec: "854",
      lot: "22008002085408",
      agent: "Naima Boutili",
      dateAff: "6/23/2026 10:02",
      objet: "Controle",
      nbActes: 213,
      nbControles: 6,
      reste: 207,
      statut: "EC"
    },
    {
      id: "row-6",
      bec: "854",
      lot: "22008001085406",
      agent: "Fikhlef",
      dateAff: "6/23/2026 10:04",
      objet: "Controle",
      nbActes: 399,
      nbControles: 7,
      reste: 392,
      statut: "EC"
    },
    {
      id: "row-7",
      bec: "854",
      lot: "22005001085405",
      agent: "Laila lakhal",
      dateAff: "6/23/2026 10:05",
      objet: "Controle",
      nbActes: 399,
      nbControles: 16,
      reste: 383,
      statut: "TERM"
    }
  ]);

  const handleStatusChange = (status: 'EC' | 'TERM') => {
    if (!selectedRowId) return;
    setAssignmentList(prev => prev.map(row => {
      if (row.id === selectedRowId) {
        return {
          ...row,
          statut: status,
          reste: status === 'TERM' ? 0 : row.reste
        };
      }
      return row;
    }));
  };

  const handleAffecter = () => {
    // Toggle simulated add
    const newLot: AssignmentRow = {
      id: `row-${Date.now()}`,
      bec: "1848",
      lot: "220010010184801",
      agent: "chaymae.r (Moi)",
      dateAff: new Date().toLocaleDateString('fr-FR') + " " + new Date().toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'}),
      objet: "Controle",
      nbActes: 250,
      nbControles: 0,
      reste: 250,
      statut: "EC"
    };
    setAssignmentList(prev => [newLot, ...prev]);
    setSelectedRowId(newLot.id);
  };

  const handleDesaffecter = () => {
    if (!selectedRowId) return;
    setAssignmentList(prev => prev.filter(row => row.id !== selectedRowId));
    setSelectedRowId(null);
  };

  // Filter items matching input Lot
  const filteredRows = assignmentList.filter(row => {
    if (!filterLot.trim()) return true;
    return row.lot.includes(filterLot.trim());
  });

  return (
    <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 shadow-xs max-w-full font-sans select-none" id="affectations-component">
      
      {/* Top Windows Chrome */}
      <div className="bg-stone-200 px-3 py-1.5 rounded-t-lg border-b border-stone-300 flex items-center justify-between text-stone-700 font-bold text-xs select-none shadow-xs">
        <span className="flex items-center gap-1.5 font-mono">📁 Gestion des Affectations de Saisie / Contrôle</span>
        <span className="text-[10px] bg-amber-100 text-amber-800 border border-amber-200 px-2.5 py-0.5 rounded font-bold">MODE SUPERVISEUR</span>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 mt-3 bg-stone-100 p-3 rounded-b-lg border border-stone-200">
        
        {/* Left Side Table Grid */}
        <div className="xl:col-span-9 bg-white rounded-lg border border-stone-300 shadow-inner overflow-hidden flex flex-col justify-between">
          <div className="overflow-x-auto h-[280px]">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-[#e4e4e7] sticky top-0 font-bold border-b border-stone-300 text-stone-700 select-none z-10">
                <tr className="divide-x divide-stone-300">
                  <th className="p-2 text-center w-12">Bec</th>
                  <th className="p-2 w-28 text-center">Lot</th>
                  <th className="p-2">Agent de saisie</th>
                  <th className="p-2 w-32">Date d'Affectation</th>
                  <th className="p-2 text-center">Objet</th>
                  <th className="p-2 text-center">Nbr Actes</th>
                  <th className="p-2 text-center">Nbr Contrôles</th>
                  <th className="p-2 text-center">Restant</th>
                  <th className="p-2 text-center">État Aff.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200 font-mono text-[11px] text-stone-800 bg-white">
                {filteredRows.map((r) => {
                  const isSelected = selectedRowId === r.id;
                  return (
                    <tr 
                      key={r.id} 
                      onClick={() => setSelectedRowId(r.id)}
                      className={`cursor-pointer divide-x divide-stone-200 ${
                        isSelected 
                          ? "bg-amber-100 text-[#7c2d12] font-black border-y-2 border-amber-500 scale-[0.998]" 
                          : "hover:bg-amber-50/30"
                      }`}
                    >
                      <td className="p-2 text-stone-500 text-center font-bold">{r.bec}</td>
                      <td className="p-2 font-mono font-bold text-stone-800 text-center">{r.lot}</td>
                      <td className="p-2 text-stone-700 font-sans font-medium">{r.agent}</td>
                      <td className="p-2 text-stone-400 font-medium">{r.dateAff}</td>
                      <td className="p-2 text-center text-stone-600 font-sans">{r.objet}</td>
                      <td className="p-2 text-center text-stone-800 font-bold">{r.nbActes}</td>
                      <td className="p-3 text-center text-rose-800 font-medium">{r.nbControles}</td>
                      <td className="p-2 text-center font-black text-[#15803d]">{r.reste}</td>
                      <td className="p-2 text-center font-sans font-bold">
                        {r.statut === 'TERM' ? (
                          <span className="bg-green-150 px-2 py-0.5 rounded text-green-800 border border-green-200 text-[10px]">
                            TERM
                          </span>
                        ) : (
                          <span className="bg-amber-150 px-2 py-0.5 rounded text-amber-850 border border-amber-200 text-[10px] animate-pulse">
                            EC
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {filteredRows.length === 0 && (
                  <tr>
                    <td colSpan={9} className="p-12 text-center text-stone-400 font-sans">
                      Aucun lot ne correspond à la recherche.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Side Buttons Layout */}
        <div className="xl:col-span-3 flex flex-col justify-between gap-4 bg-white p-3.5 rounded-lg border border-stone-300 shadow-xs">
          <div className="space-y-2">
            <button
              onClick={handleAffecter}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-800 transition-all flex items-center justify-start gap-2 select-none shadow-xs"
              id="aff-btn-add"
            >
              <Play className="w-3.5 h-3.5 text-stone-600 rotate-90" /> Affecter un Lot
            </button>
            <button
              onClick={handleDesaffecter}
              disabled={!selectedRowId}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-red-100 hover:border-red-400 hover:text-red-800 border border-stone-400 rounded text-xs font-bold text-stone-800 transition-all disabled:opacity-30 disabled:hover:bg-stone-200 disabled:hover:text-stone-800 flex items-center justify-start gap-2 select-none shadow-xs"
              id="aff-btn-remove"
            >
              <Ban className="w-3.5 h-3.5 text-red-500" /> Désaffecter Lot
            </button>
            
            <div className="h-px bg-stone-200 my-2" />

            <button
              onClick={() => handleStatusChange('TERM')}
              disabled={!selectedRowId}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-green-100 hover:border-green-400 hover:text-green-800 border border-stone-400 rounded text-xs font-bold text-stone-800 transition-all disabled:opacity-30 disabled:hover:bg-stone-200 disabled:hover:text-stone-850 flex items-center justify-start gap-2 select-none shadow-xs"
              id="aff-btn-term"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Marquer Terminé
            </button>
            <button
              onClick={() => handleStatusChange('EC')}
              disabled={!selectedRowId}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-800 transition-all disabled:opacity-30 disabled:hover:bg-stone-200 flex items-center justify-start gap-2 select-none"
              id="aff-btn-ec"
            >
              <Circle className="w-3.5 h-3.5 text-amber-600 animate-pulse" /> Marquer EC (En Cours)
            </button>
            <button
              onClick={() => {
                setFilterLot('');
                setSelectedRowId("row-1");
              }}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-800 transition-all flex items-center justify-start gap-2 select-none"
              id="aff-btn-refresh"
            >
              <RefreshCw className="w-3.5 h-3.5 text-stone-600" /> Actualiser
            </button>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Filtrer par Lot :</label>
            <div className="relative">
              <input
                type="text"
                value={filterLot}
                onChange={(e) => setFilterLot(e.target.value)}
                placeholder="Entrez le lot..."
                className="w-full p-1.5 pl-7 pr-2 text-xs bg-stone-50 border border-stone-300 rounded font-mono focus:outline-hidden text-stone-800"
                id="aff-input-filter"
              />
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2 top-2" />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
