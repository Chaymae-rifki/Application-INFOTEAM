/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash, Edit, Check } from 'lucide-react';

interface UserRow {
  login: string;
  nom: string;
  actif: boolean;
  profils: string[];
}

export default function GestionUtilisateurs() {
  const [filterActif, setFilterActif] = useState(true);
  const [selectedLogin, setSelectedLogin] = useState<string | null>("naithmida");
  
  const [users, setUsers] = useState<UserRow[]>([
    { login: "naithmida", nom: "AIT HMIDA NOUHAYLA", actif: true, profils: ["Opérateur Saisie", "Validation Niveau 1"] },
    { login: "aelkharta", nom: "Aouatif Elkharta", actif: true, profils: ["Opérateur Saisie"] },
    { login: "ibntahir", nom: "asmaa ibntahir", actif: true, profils: ["Opérateur Saisie"] },
    { login: "aibentahir", nom: "Asmae Ibentahir", actif: true, profils: ["Opérateur Saisie"] },
    { login: "aelotmani", nom: "atika el otmani", actif: true, profils: ["Opérateur Saisie"] },
    { login: "satlas", nom: "Atlas Siham", actif: true, profils: ["Opérateur Saisie", "Superviseur Direct"] },
    { login: "bboumour", nom: "Badia Boumour", actif: true, profils: ["Opérateur Saisie"] },
    { login: "boudra", nom: "Bouchra Oudra", actif: false, profils: ["Opérateur Saisie"] }
  ]);

  const selectedUser = users.find(u => u.login === selectedLogin);

  const handleAddUser = () => {
    const login = prompt("Entrez le Login de l'utilisateur :");
    const nom = prompt("Entrez le Nom Complet :");
    if (login && nom) {
      setUsers(prev => [...prev, { login, nom, actif: true, profils: ["Opérateur Saisie"] }]);
      setSelectedLogin(login);
    }
  };

  const handleToggleActif = () => {
    if (!selectedLogin) return;
    setUsers(prev => prev.map(u => {
      if (u.login === selectedLogin) {
        return { ...u, actif: !u.actif };
      }
      return u;
    }));
  };

  const handleDeleteUser = () => {
    if (!selectedLogin) return;
    setUsers(prev => prev.filter(u => u.login !== selectedLogin));
    setSelectedLogin(null);
  };

  return (
    <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 shadow-xs max-w-full font-sans select-none" id="utilisateurs-component">
      <div className="bg-stone-200 px-3 py-1.5 rounded-t-lg border-b border-stone-300 flex items-center justify-between text-stone-700 font-bold text-xs select-none shadow-xs">
        <span className="flex items-center gap-1.5 font-mono">👥 Gestion des Utilisateurs du Système de Saisie</span>
        <span className="text-[10px] bg-sky-100 text-sky-800 px-2.5 py-0.5 rounded font-bold border border-sky-200">Réseau Local d'État Civil</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3 bg-stone-100 p-3 rounded-b-lg border border-stone-200">
        
        {/* Left Side Active Table */}
        <div className="lg:col-span-8 flex flex-col justify-between space-y-3">
          <div className="bg-white rounded-lg border border-stone-300 shadow-inner overflow-hidden">
            <div className="overflow-y-auto h-[240px]">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-[#e4e4e7] sticky top-0 font-bold border-b border-stone-300 text-stone-700">
                  <tr className="divide-x divide-stone-300">
                    <th className="p-2 w-1/3">Login de connexion</th>
                    <th className="p-2">Nom Complet de l'Agent</th>
                    <th className="p-2 text-center w-24">Statut Actif</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 font-mono text-[11px] text-stone-850 bg-white">
                  {users
                    .filter(u => !filterActif || u.actif)
                    .map((user) => {
                      const isSelected = selectedLogin === user.login;
                      return (
                        <tr 
                          key={user.login}
                          onClick={() => setSelectedLogin(user.login)}
                          className={`cursor-pointer divide-x divide-stone-200 ${
                            isSelected ? "bg-amber-100 text-[#7c2d12] font-bold border-y-2 border-amber-400" : "hover:bg-amber-50/20"
                          }`}
                        >
                          <td className="p-2 font-bold">{user.login}</td>
                          <td className="p-2 font-sans">{user.nom}</td>
                          <td className="p-2 text-center">
                            {user.actif ? (
                              <span className="text-green-700 font-bold text-[10px] bg-green-50 px-1.5 py-0.5 rounded border border-green-200">Oui</span>
                            ) : (
                              <span className="text-stone-400 text-[10px] bg-stone-50 px-1.5 py-0.5 rounded border border-stone-200">Non</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Lower Panel Tools */}
          <div className="flex gap-2">
            <button
              onClick={handleAddUser}
              className="py-1 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-700 flex items-center gap-1.5"
              id="user-btn-add"
            >
              <Plus className="w-3.5 h-3.5 text-stone-600" /> Ajouter
            </button>
            <button
              onClick={handleToggleActif}
              disabled={!selectedLogin}
              className="py-1 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-700 flex items-center gap-1.5 disabled:opacity-35"
              id="user-btn-modify"
            >
              <Edit className="w-3.5 h-3.5 text-stone-600" /> Profil Actif/Inactif
            </button>
            <button
              onClick={handleDeleteUser}
              disabled={!selectedLogin}
              className="py-1 px-3 bg-stone-200 hover:bg-red-50 hover:text-red-700 hover:border-red-300 border border-stone-400 rounded text-xs font-bold text-stone-700 flex items-center gap-1.5 disabled:opacity-35"
              id="user-btn-delete"
            >
              <Trash className="w-3 h-3 text-stone-600" /> Supprimer
            </button>
          </div>
        </div>

        {/* Right Side Roles Pane */}
        <div className="lg:col-span-4 bg-white p-3 rounded-lg border border-stone-300 flex flex-col justify-between shadow-xs">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                checked={filterActif} 
                onChange={(e) => setFilterActif(e.target.checked)}
                className="w-4 h-4 text-[#ea580c] bg-stone-50 border-stone-400 rounded"
                id="user-check-actifs"
              />
              <label htmlFor="user-check-actifs" className="text-xs font-bold text-stone-700 select-none cursor-pointer">
                Uniquement les Actifs
              </label>
            </div>

            <div className="border border-stone-200 rounded-lg overflow-hidden shrink-0">
              <div className="bg-[#f4f4f5] p-2 text-stone-700 font-bold text-[10px] border-b border-stone-200 uppercase font-sans">
                Profils Accordés à l'Utilisateur
              </div>
              <div className="p-3 bg-stone-50 space-y-1.5 min-h-[120px] font-mono text-[11px]">
                {selectedUser ? (
                  selectedUser.profils.map((prof, i) => (
                    <div key={i} className="flex items-center gap-2 text-stone-800 bg-white border border-stone-200 p-1.5 rounded">
                      <Check className="w-3.5 h-3.5 text-green-600 shrink-0" />
                      <span>{prof}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-stone-400 font-sans p-2 text-center">Aucun utilisateur sélectionné</p>
                )}
              </div>
            </div>
          </div>

          <div className="text-[10px] text-stone-400 font-sans flex items-center gap-1 bg-stone-50 p-2 rounded border border-stone-200 mt-2">
            <span>🛡️</span> Nom d'utilisateur unique lié à la base sécurisée PostgreSQL.
          </div>
        </div>

      </div>
    </div>
  );
}
