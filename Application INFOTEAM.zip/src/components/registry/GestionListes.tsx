/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash, Edit2, Bookmark } from 'lucide-react';

interface DictRow {
  valeurAr: string;
  valeurFr: string;
}

export default function GestionListes() {
  const [selectedBec, setSelectedBec] = useState("859");
  const [selectedList, setSelectedList] = useState("Professions");
  const [selectedRowIndex, setSelectedRowIndex] = useState<number | null>(0);

  const [dietList, setDietList] = useState<Record<string, DictRow[]>>({
    Professions: [
      { valeurAr: "تاجر", valeurFr: "Commerçant" },
      { valeurAr: "صانع تقليدي", valeurFr: "Artisan" },
      { valeurAr: "فلاح", valeurFr: "Agriculteur" },
      { valeurAr: "موظف", valeurFr: "Fonctionnaire" },
      { valeurAr: "طبيب", valeurFr: "Médecin" },
      { valeurAr: "بدون مهنة", valeurFr: "Sans profession" }
    ],
    Villes: [
      { valeurAr: "فاس", valeurFr: "Fès" },
      { valeurAr: "مكناس", valeurFr: "Meknès" },
      { valeurAr: "الرباط", valeurFr: "Rabat" },
      { valeurAr: "البيضاء", valeurFr: "Casablanca" },
      { valeurAr: "تازة", valeurFr: "Taza" }
    ]
  });

  const activeDict = dietList[selectedList] || [];

  const handleAddField = () => {
    const valeurAr = prompt("Entrez la valeur en Arabe :");
    const valeurFr = prompt("Entrez la valeur en Français :");
    if (valeurAr && valeurFr) {
      setDietList(prev => ({
        ...prev,
        [selectedList]: [...(prev[selectedList] || []), { valeurAr, valeurFr }]
      }));
    }
  };

  const handleEditField = () => {
    if (selectedRowIndex === null) return;
    const target = activeDict[selectedRowIndex];
    if (!target) return;

    const valeurAr = prompt("Modifier la valeur en Arabe :", target.valeurAr);
    const valeurFr = prompt("Modifier la valeur en Français :", target.valeurFr);
    if (valeurAr && valeurFr) {
      setDietList(prev => {
        const nextList = [...prev[selectedList]];
        nextList[selectedRowIndex] = { valeurAr, valeurFr };
        return { ...prev, [selectedList]: nextList };
      });
    }
  };

  const handleDeleteField = () => {
    if (selectedRowIndex === null) return;
    setDietList(prev => {
      const nextList = prev[selectedList].filter((_, i) => i !== selectedRowIndex);
      return { ...prev, [selectedList]: nextList };
    });
    setSelectedRowIndex(null);
  };

  return (
    <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 shadow-xs max-w-full font-sans select-none" id="listes-component">
      <div className="bg-stone-200 px-3 py-1.5 rounded-t-lg border-b border-stone-300 flex items-center justify-between text-stone-700 font-bold text-xs select-none shadow-xs">
        <span className="flex items-center gap-1.5 font-mono">📖 Gestion des Listes & Dictionnaire de Saisie</span>
        <span className="text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded font-bold">Standardisation</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3 bg-stone-100 p-3 rounded-b-lg border border-stone-200">
        
        {/* Left Side: Selectors & Table */}
        <div className="lg:col-span-9 flex flex-col justify-between space-y-3">
          
          {/* selectors bar */}
          <div className="grid grid-cols-2 gap-3 bg-white p-3 rounded-lg border border-stone-300 shadow-xs">
            <div>
              <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Bureau d'État Civil (BEC)</label>
              <select
                value={selectedBec}
                onChange={(e) => setSelectedBec(e.target.value)}
                className="w-full p-1 border border-stone-300 rounded text-xs text-stone-700 font-mono focus:outline-hidden"
                id="dict-select-bec"
              >
                <option value="859">859 - FÈS/ANNEXE DOKKARAT</option>
                <option value="1848">1848 - TAZA CENTRAL</option>
                <option value="1934">1934 - TAZA GHIATA</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1 font-sans">Type de Table / Liste</label>
              <select
                value={selectedList}
                onChange={(e) => {
                  setSelectedList(e.target.value);
                  setSelectedRowIndex(0);
                }}
                className="w-full p-1 border border-[#decbb0] rounded text-xs text-stone-700 font-sans focus:outline-hidden"
                id="dict-select-table"
              >
                <option value="Professions">Professions (المهن)</option>
                <option value="Villes">Lieux / Villes (المدن)</option>
              </select>
            </div>
          </div>

          {/* Grid list viewer */}
          <div className="bg-white rounded-lg border border-stone-300 shadow-inner overflow-hidden">
            <div className="overflow-y-auto h-[160px]">
              <table className="w-full text-right border-collapse text-xs">
                <thead className="bg-[#e4e4e7] sticky top-0 font-bold border-b border-stone-300 text-stone-700 text-center select-none">
                  <tr className="divide-x divide-stone-300">
                    <th className="p-2 w-1/2 text-right pr-4 border-r border-stone-300">الترجمة بالعربية (Arabe)</th>
                    <th className="p-2 w-1/2 text-left pl-4">Équivalence en Français</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 font-mono text-stone-850 bg-white">
                  {activeDict.map((d, i) => {
                    const isSelected = selectedRowIndex === i;
                    return (
                      <tr 
                        key={i}
                        onClick={() => setSelectedRowIndex(i)}
                        className={`cursor-pointer divide-x divide-stone-200 ${
                          isSelected ? "bg-amber-100 text-[#7c2d12] font-bold border-y-2 border-amber-400" : "hover:bg-amber-50/20"
                        }`}
                      >
                        <td className="p-2 text-right pr-4 font-black font-display text-[12px] border-r border-stone-200">{d.valeurAr}</td>
                        <td className="p-2 text-left pl-4 font-sans font-medium text-[11px]">{d.valeurFr}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Side Control Panel */}
        <div className="lg:col-span-3 flex flex-col justify-between bg-white p-3.5 rounded-lg border border-stone-300 shadow-xs">
          <div className="space-y-2">
            <button
              onClick={handleAddField}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-850 flex items-center gap-2 select-none justify-start"
              id="dict-btn-add"
            >
              <Plus className="w-3.5 h-3.5 text-stone-600" /> Ajouter Valeur
            </button>
            <button
              onClick={handleEditField}
              disabled={selectedRowIndex === null}
              className="w-full py-1.5 px-3 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-850 flex items-center gap-2 select-none justify-start disabled:opacity-35"
              id="dict-btn-edit"
            >
              <Edit2 className="w-3 h-3 text-stone-600" /> Modifier Valeur
            </button>
            <button
              onClick={handleDeleteField}
              disabled={selectedRowIndex === null}
              className="w-full py-1.5 px-4 bg-stone-90 hover:bg-red-50 hover:text-red-700 hover:border-red-300 border border-stone-400 rounded text-xs font-bold text-stone-850 flex items-center gap-2 select-none justify-start disabled:opacity-35"
              id="dict-btn-delete"
            >
              <Trash className="w-3.5 h-3.5 text-stone-600" /> Supprimer
            </button>
          </div>

          <div className="text-[10px] text-stone-400 flex items-center gap-1.5 bg-stone-50 p-2 rounded border border-stone-200 mt-2">
            <Bookmark className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <p>Ces listes de traduction assistent la validation des actes de naissance et de décès.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
