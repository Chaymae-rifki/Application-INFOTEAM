/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Send, Plus, Trash } from 'lucide-react';

interface Message {
  id: string;
  date: string;
  de: string;
  a: string;
  message: string;
}

export default function Messagerie() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "M-1",
      date: "23/06/2026 09:12",
      de: "chaymae.r",
      a: "admin",
      message: "Bonjour, le lot 22008001085508 a été complètement validé."
    },
    {
      id: "M-2",
      date: "23/06/2026 09:15",
      de: "admin",
      a: "chaymae.r",
      message: "Reçu. Vous pouvez passer au lot de décès Taza."
    }
  ]);

  const [selectedRecipient, setSelectedRecipient] = useState('admin');
  const [messageText, setMessageText] = useState('Lot 2026/05 validé pour injection');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    const newMsg: Message = {
      id: `M-${Date.now().toString().slice(-4)}`,
      date: new Date().toLocaleString('fr-FR'),
      de: "chaymae.r (Moi)",
      a: selectedRecipient,
      message: messageText
    };

    setMessages(prev => [...prev, newMsg]);
    setMessageText('');
  };

  const handleAddBlank = () => {
    setMessageText('Saisie prête pour vérification');
  };

  return (
    <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 shadow-xs max-w-full font-sans select-none" id="messagerie-component">
      <div className="bg-stone-200 px-3 py-1.5 rounded-t-lg border-b border-stone-300 flex items-center justify-between text-stone-700 font-bold text-xs select-none shadow-xs">
        <span className="flex items-center gap-1.5 font-mono">💬 Messagerie Interne - InfoTeam 1</span>
        <span className="text-[10px] bg-stone-100 px-2 py-0.5 rounded text-stone-500">Actif</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3 bg-stone-100 p-3 rounded-b-lg border border-stone-200">
        
        {/* Messages List Grid */}
        <div className="lg:col-span-8 space-y-3 flex flex-col justify-between">
          <div className="bg-white rounded-lg border border-stone-300 shadow-inner overflow-hidden">
            <div className="overflow-x-auto h-[240px]">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-[#e4e4e7] text-stone-700 sticky top-0 font-bold border-b border-stone-300 select-none">
                  <tr>
                    <th className="p-2 border-r border-stone-300 w-1/4">Date</th>
                    <th className="p-2 border-r border-stone-300 w-1/6">De</th>
                    <th className="p-2 border-r border-stone-300 w-1/6">A</th>
                    <th className="p-2">Message</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 font-mono text-[11px] text-stone-800 bg-white">
                  {messages.map((m) => (
                    <tr key={m.id} className="hover:bg-amber-50/40">
                      <td className="p-2 border-r border-stone-300 align-top text-stone-500">{m.date}</td>
                      <td className="p-2 border-r border-stone-300 align-top font-bold text-[#b91c1c]">{m.de}</td>
                      <td className="p-2 border-r border-stone-300 align-top text-stone-600">{m.a}</td>
                      <td className="p-2 align-top text-stone-700 font-sans break-words">{m.message}</td>
                    </tr>
                  ))}
                  {messages.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-stone-400 font-sans">
                        Aucun message enregistré.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-start">
            <button
              type="button"
              onClick={handleAddBlank}
              className="py-1 px-4 bg-stone-200 hover:bg-stone-300 border border-stone-400 rounded text-xs font-bold text-stone-700 flex items-center gap-1.5"
              id="msg-btn-add"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter
            </button>
          </div>
        </div>

        {/* Compose Form */}
        <form onSubmit={handleSend} className="lg:col-span-4 bg-white p-3 rounded-lg border border-stone-300 flex flex-col justify-between gap-3 shadow-xs">
          <div className="space-y-3">
            <div>
              <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Destinataire</label>
              <select
                value={selectedRecipient}
                onChange={(e) => setSelectedRecipient(e.target.value)}
                className="w-full p-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-hidden text-stone-800 font-mono"
                id="msg-select-dest"
              >
                <option value="admin">admin (Administrateur)</option>
                <option value="supervisor">supervisor (Superviseur)</option>
                <option value="meryem_h">meryem_h (Opérateur A)</option>
                <option value="salma_m">salma_m (Opérateur B)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Message</label>
              <textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="w-full p-2 h-[120px] text-xs bg-stone-50 border border-stone-300 rounded font-mono focus:outline-hidden text-stone-800"
                placeholder="Saisissez votre message..."
                id="msg-textarea"
              />
            </div>
          </div>

          <div className="flex gap-2 justify-end">
            <button
              type="submit"
              className="py-1 px-4 bg-stone-200 hover:bg-[#16a34a] hover:text-white border border-[#16a34a]/40 hover:border-[#16a34a] rounded text-xs font-bold text-stone-800 transition-all flex items-center gap-1"
              id="msg-btn-send"
            >
              <Send className="w-3 h-3" /> Envoyer
            </button>
            <button
              type="button"
              onClick={() => setMessageText('')}
              className="py-1 px-4 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded text-xs text-stone-600"
              id="msg-btn-cancel"
            >
              Annuler
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
