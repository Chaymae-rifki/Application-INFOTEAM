/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageScan } from '../../types';
import { Landmark, Link, Calendar, CheckSquare, Square, Minus, Plus, Users, Clock } from 'lucide-react';

interface ActFormNaissanceProps {
  page: PageScan;
  updatePage: (fields: Partial<PageScan>) => void;
}

type SubTab = 'data' | 'officer' | 'declaration' | 'mother' | 'father';

export default function ActFormNaissance({ page, updatePage }: ActFormNaissanceProps) {
  const [subTab, setSubTab] = useState<SubTab>('data');

  // Local mirror fallback states for testing if fields are missing in operatorData
  const operator = page.operatorA || {
    prenom: '', nom: '', prenomAr: '', nomAr: '',
    dateGregoirienne: '', dateHegirienne: '', perePrenom: '', merePrenom: ''
  };

  const updateOperator = (fields: Partial<typeof operator>) => {
    updatePage({
      operatorA: {
        ...operator,
        ...fields
      }
    });
  };

  return (
    <div className="bg-[#f3f4f6] p-3 rounded-lg border border-stone-300 shadow-sm font-sans select-none" id="act-form-naissance">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
        
        {/* Main form grid on the left */}
        <div className="md:col-span-12 space-y-3">
          
          {/* Row 1: Language checkboxes & Tome Badge */}
          <div className="bg-white p-2.5 rounded border border-stone-300 md:flex md:justify-between md:items-center space-y-2 md:space-y-0 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-stone-700">لغة التحرير (Langue rédigée):</span>
              <div className="flex gap-2">
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" defaultChecked className="text-[#ea580c] focus:ring-0 rounded" />
                  <span className="font-medium text-[11px]">العربية (Arabe)</span>
                </label>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" className="text-[#ea580c] focus:ring-0 rounded" />
                  <span className="font-medium text-[11px]">Français</span>
                </label>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="bg-teal-100 text-teal-800 border border-teal-200 py-0.5 px-3 rounded font-mono font-bold">
                Tome Code: {page.numTome}
              </span>
              <span className="bg-orange-100 text-orange-850 border border-orange-200 py-0.5 px-3 rounded font-mono font-bold animate-pulse">
                BEC: {page.numBEC}
              </span>
            </div>
          </div>

          {/* Row 2: Tome year & Act Number */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                سنة الرسم (Année Acte)
              </label>
              <div className="flex gap-1">
                <input
                  type="text"
                  defaultValue="1994"
                  className="w-full p-1 border border-stone-300 rounded font-mono focus:outline-hidden text-center text-stone-800"
                />
                <button type="button" className="p-1.5 bg-stone-100 border border-stone-300 hover:bg-stone-200 rounded text-stone-600 font-bold text-[10px]" id="btn-year-play">
                  ▶
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                رقم الرسم (Numéro de l'Acte)
              </label>
              <input
                type="text"
                value={page.numActe}
                onChange={(e) => updatePage({ numActe: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-semibold font-mono text-center text-stone-850"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-[10px] text-[#2563eb] font-bold mb-1 text-right">
                مكان الولادة (Lieu de Naissance)
              </label>
              <input
                type="text"
                defaultValue="فاس، المشفى الإقليمي"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-xs text-stone-800 font-semibold"
                dir="rtl"
              />
            </div>
          </div>

          {/* Row 3: Birthdates (Gregorian + Hijri), Hours and Minutes */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                تاريخ الولادة ميلادي (Date Grégorienne)
              </label>
              <input
                type="text"
                value={operator.dateGregoirienne}
                onChange={(e) => updateOperator({ dateGregoirienne: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-mono text-center text-stone-800"
                placeholder="JJ/MM/AAAA"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                تاريخ الولادة هجري (Date Hégirienne)
              </label>
              <input
                type="text"
                value={operator.dateHegirienne}
                onChange={(e) => updateOperator({ dateHegirienne: e.target.value })}
                className="w-full p-1.5 border border-stone-300 rounded font-mono text-center text-stone-800 text-right pr-2"
                placeholder="العام الهجري"
                dir="rtl"
              />
            </div>

            <div className="md:col-span-2 grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                  على الساعة (À l'heure)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    defaultValue="11"
                    className="w-full p-1.5 pl-6 border border-stone-300 rounded text-center pr-2 font-mono text-stone-800"
                  />
                  <Clock className="w-3.5 h-3.5 text-stone-400 absolute left-2 top-2.5" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right col-span-1">
                  و الدقيقة (Et minute)
                </label>
                <input
                  type="number"
                  defaultValue="30"
                  className="w-full p-1.5 border border-stone-300 rounded text-center font-mono text-stone-800"
                />
              </div>
            </div>
          </div>

          {/* Row 4: Names & Surnames (Corps VS Margins) */}
          <div className="bg-white p-3 rounded border border-stone-300 space-y-3 text-xs">
            <h5 className="font-bold text-amber-900 border-b border-amber-100 pb-1 uppercase tracking-wider text-[10px] flex items-center gap-1">
              🏷️ الاسم المكتوب بالصلب و الهامش (Prénoms/Noms du titulaire)
            </h5>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              {/* Corps */}
              <div>
                <label className="block text-[9px] text-[#1e293b] font-bold mb-0.5">
                  Prenom Corps FR
                </label>
                <input
                  type="text"
                  value={operator.prenom}
                  onChange={(e) => updateOperator({ prenom: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded font-semibold text-stone-800"
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-emerald-800 font-bold mb-0.5">
                  الإسم الشخصي بالصلب AR
                </label>
                <input
                  type="text"
                  value={operator.prenomAr}
                  onChange={(e) => updateOperator({ prenomAr: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-medium text-stone-800"
                  dir="rtl"
                />
              </div>
              <div>
                <label className="block text-[9px] text-[#1e293b] font-bold mb-0.5">
                  Nom Corps FR
                </label>
                <input
                  type="text"
                  value={operator.nom}
                  onChange={(e) => updateOperator({ nom: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded font-semibold text-stone-800"
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-emerald-800 font-bold mb-0.5">
                  الاسم العائلي بالصلب AR
                </label>
                <input
                  type="text"
                  value={operator.nomAr}
                  onChange={(e) => updateOperator({ nomAr: e.target.value })}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-medium text-stone-800"
                  dir="rtl"
                />
              </div>

              {/* Marge */}
              <div>
                <label className="block text-[9px] text-stone-400 font-bold mb-0.5">
                  Prénom Marge FR
                </label>
                <input
                  type="text"
                  defaultValue={operator.prenom || "FATIMA"}
                  className="w-full p-1.5 border border-stone-300 rounded text-stone-400 font-semibold"
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-stone-400 font-bold mb-0.5">
                  الإسم الشخصي بالهامش AR
                </label>
                <input
                  type="text"
                  value={operator.prenomAr || "فاطمة"}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-stone-400 focus:outline-hidden"
                  dir="rtl"
                  readOnly
                />
              </div>
              <div>
                <label className="block text-[9px] text-stone-400 font-bold mb-0.5">
                  Nom Marge FR
                </label>
                <input
                  type="text"
                  value={operator.nom || "KHALOUI"}
                  className="w-full p-1.5 border border-stone-300 rounded text-stone-400 font-semibold font-sans"
                  readOnly
                />
              </div>
              <div>
                <label className="block text-[9px] text-right text-stone-400 font-bold mb-0.5">
                  الاسم العائلي بالهامش AR
                </label>
                <input
                  type="text"
                  value={operator.nomAr || "خلوى"}
                  className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-stone-400 focus:outline-hidden"
                  dir="rtl"
                  readOnly
                />
              </div>
            </div>
          </div>

          {/* Row 5: Twin dropdown, Sexe dropdown, Nationality */}
          <div className="bg-white p-3 rounded border border-stone-300 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                التوأم (Jumeau)
              </label>
              <select className="w-full p-1.5 border border-stone-300 rounded font-sans text-stone-700 bg-stone-50" id="birth-select-jumeau">
                <option value="Non">Non / لا</option>
                <option value="Oui">Oui / نعم</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                جنسه (Sexe)
              </label>
              <select className="w-full p-1.5 border border-stone-300 rounded font-sans text-stone-700 bg-stone-50" id="birth-select-sexe">
                <option value="Femelle">Féminin / أنثى</option>
                <option value="Male">Masculin / ذكر</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right col-span-1">
                جنسيته (Nationalité)
              </label>
              <input
                type="text"
                defaultValue="مغربية"
                className="w-full p-1.5 border border-stone-300 rounded text-right font-semibold text-stone-800"
                dir="rtl"
              />
            </div>
          </div>

          {/* Core Subtabs bar designed horizontally (blue color theme) */}
          <div className="bg-white rounded border border-stone-300 overflow-hidden text-xs">
            
            {/* subtabs toggler */}
            <div className="flex border-b border-stone-300 bg-[#f8fafc] text-[11px] font-bold text-stone-500 overflow-x-auto select-none">
              <button
                type="button"
                onClick={() => setSubTab('data')}
                className={`py-2 px-4 border-r border-stone-300 flex items-center gap-1.5 shrink-0 transition-all ${
                  subTab === 'data' ? "bg-white text-blue-700 font-black shadow-inner border-t-2 border-t-blue-600" : "hover:text-blue-600 hover:bg-stone-50"
                }`}
              >
                💾 البيانات (Informations de l'acte)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('officer')}
                className={`py-2 px-4 border-r border-stone-300 flex items-center gap-1.5 shrink-0 transition-all ${
                  subTab === 'officer' ? "bg-white text-blue-700 font-black shadow-inner border-t-2 border-t-blue-600" : "hover:text-blue-600 hover:bg-stone-50"
                }`}
              >
                ⚖️ ضابط ح م (Officier EC)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('declaration')}
                className={`py-2 px-4 border-r border-stone-300 flex items-center gap-1.5 shrink-0 transition-all ${
                  subTab === 'declaration' ? "bg-white text-blue-700 font-black shadow-inner border-t-2 border-t-blue-600" : "hover:text-blue-600 hover:bg-stone-50"
                }`}
              >
                🗣️ التصريح (Déclaration/BEC)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('father')}
                className={`py-2 px-4 border-r border-stone-300 flex items-center gap-1.5 shrink-0 transition-all ${
                  subTab === 'father' ? "bg-white text-blue-700 font-black shadow-inner border-t-2 border-t-blue-600" : "hover:text-blue-600 hover:bg-stone-50"
                }`}
              >
                👨‍🦳 الأب (Informations Père)
              </button>
              <button
                type="button"
                onClick={() => setSubTab('mother')}
                className={`py-2 px-4 flex items-center gap-1.5 shrink-0 transition-all ${
                  subTab === 'mother' ? "bg-white text-blue-700 font-black shadow-inner border-t-2 border-t-blue-600" : "hover:text-blue-600 hover:bg-stone-50"
                }`}
              >
                👩‍🦰 الأم (Informations Mère)
              </button>
            </div>

            {/* Sub-tab viewport panels */}
            <div className="p-3 bg-white text-xs space-y-3">
              {subTab === 'data' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <button
                      onClick={() => updatePage({ isActeBis: !page.isActeBis })}
                      className="w-full flex items-center gap-2.5 text-left p-2 border border-stone-200 hover:bg-stone-50 rounded-lg text-xs"
                    >
                      {page.isActeBis ? (
                        <CheckSquare className="w-4 h-4 text-[#ea580c]" />
                      ) : (
                        <Square className="w-4 h-4 text-stone-400" />
                      )}
                      <div>
                        <span className="font-bold text-stone-800">Assigner "Acte Bis" (رسم مكرر)</span>
                      </div>
                    </button>

                    <div className="flex items-center justify-between p-2.5 bg-stone-50 rounded-lg border border-stone-200">
                      <div>
                        <span className="font-bold block text-stone-700">عدد الإدخالات الهامشية</span>
                        <span className="text-[10px] text-stone-400">Nombre d'annotations marginales</span>
                      </div>

                      <div className="flex items-center gap-2 bg-white px-2 py-1 rounded border border-stone-300 shadow-clay-inner">
                        <button
                          onClick={() => updatePage({ marginalMentionsCount: Math.max(0, page.marginalMentionsCount - 1) })}
                          className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 rounded text-stone-800"
                        >
                          -
                        </button>
                        <span className="font-bold font-mono text-stone-800 w-5 text-center">{page.marginalMentionsCount}</span>
                        <button
                          onClick={() => updatePage({ marginalMentionsCount: page.marginalMentionsCount + 1 })}
                          className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 rounded text-stone-800"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-stone-500 mb-1">Mélange des d’annotations / remarques</label>
                    <textarea
                      rows={2}
                      value={page.declarationDetails || ''}
                      onChange={(e) => updatePage({ declarationDetails: e.target.value })}
                      className="w-full text-xs font-sans p-2 border border-stone-300 rounded focus:outline-hidden"
                      placeholder="Mentions additionnelles..."
                    />
                  </div>
                </div>
              )}

              {subTab === 'officer' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      بمقتضى التفويض الصادر عن رئيس (Par délégation de l'Officier Chef)
                    </label>
                    <input
                      type="text"
                      defaultValue="ضابط الحالة المدنية بالنيابة"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display text-xs text-stone-800"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-[#2563eb] font-bold mb-1 text-right">
                      اسم ضابط الحالة المدنية (Nom de l'Officier d'État Civil)
                    </label>
                    <input
                      type="text"
                      defaultValue="محمد بنعمر السقاط"
                      className="w-full p-2 border border-stone-300 rounded text-right font-display font-bold text-stone-850"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'declaration' && (
                <div className="space-y-2">
                  <div>
                    <label className="block text-[10px] text-[#2563eb] font-bold mb-1 text-right">
                      صاحب التصريح بالولادة (Déclarant de la Naissance)
                    </label>
                    <input
                      type="text"
                      value={page.statutDeclarative || ''}
                      onChange={(e) => updatePage({ statutDeclarative: e.target.value })}
                      className="w-full p-2 border border-stone-300 rounded text-right text-stone-850 font-display font-medium text-xs"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'father' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      اسم الأب بالكامل (Nom complet du Père)
                    </label>
                    <input
                      type="text"
                      value={operator.perePrenom ? `أحمد ${operator.nomAr || 'خلوى'}` : 'أحمد خلوى'}
                      className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-bold text-stone-800"
                      dir="rtl"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      عمره (Son âge)
                    </label>
                    <input
                      type="number"
                      defaultValue="32"
                      className="w-full p-1.5 border border-stone-300 rounded text-center font-mono text-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      مهنته (Profession du Père)
                    </label>
                    <input
                      type="text"
                      defaultValue="تاجر"
                      className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-stone-800"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}

              {subTab === 'mother' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                      اسم الأم بالكامل (Nom complet de la Mère)
                    </label>
                    <input
                      type="text"
                      value={operator.merePrenom ? `عائشة ${operator.merePrenom}` : 'عائشة شقرون'}
                      className="w-full p-1.5 border border-stone-300 rounded text-right font-display font-semibold text-stone-800"
                      dir="rtl"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right col-span-1">
                      عمرها (Son âge)
                    </label>
                    <input
                      type="number"
                      defaultValue="27"
                      className="w-full p-1.5 border border-stone-300 rounded text-center font-mono text-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right col-span-1">
                      مهنتها (Profession Mère)
                    </label>
                    <input
                      type="text"
                      defaultValue="ربة بيت"
                      className="w-full p-1.5 border border-stone-300 rounded text-right font-display text-stone-800"
                      dir="rtl"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
