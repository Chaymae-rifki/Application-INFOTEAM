/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageScan } from '../../types';
import { ShieldAlert, BookOpen, UserCheck, Calendar, FileText, CheckCircle2 } from 'lucide-react';

interface FormPopfProps {
  page: PageScan;
  updatePage: (fields: Partial<PageScan>) => void;
}

export default function FormPopf({ page, updatePage }: FormPopfProps) {
  // Checkbox states for interactive demo feedback
  const [isCheckedPO, setIsCheckedPO] = useState(true);
  const [isCheckedPF, setIsCheckedPF] = useState(true);
  const [isSceauProc, setIsSceauProc] = useState(true);
  const [isSignOff, setIsSignOff] = useState(true);
  const [isSceauOff, setIsSceauOff] = useState(true);

  return (
    <div className="bg-[#f3f4f6] p-3 rounded-lg border border-stone-300 shadow-sm font-sans select-none" id="form-popf">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        
        {/* Frame 1: Register Core Information */}
        <div className="bg-white p-3.5 rounded border border-stone-300 shadow-xs flex flex-col justify-between gap-3 text-xs">
          <div className="space-y-3">
            <h5 className="font-bold text-[#b45309] border-b border-amber-100 pb-1.5 uppercase text-[10px] flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-amber-600" /> معلومات حول السجل (Infos Registre)
            </h5>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                رمز السجل الفريد (Code Registre)
              </label>
              <input
                type="text"
                value={`REG-${page.numBEC}-${page.numTome}`}
                className="w-full p-2 bg-stone-50 border border-stone-300 rounded font-mono font-bold text-stone-800"
                readOnly
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                الجماعة ومكتب ح م (Bureau d'État Civil)
              </label>
              <input
                type="text"
                defaultValue="جماعة فاس، الملحقة الإدارية الدكارات"
                className="w-full p-2 border border-stone-300 rounded font-medium text-stone-800 text-right font-display"
                dir="rtl"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <label className="block text-[9px] text-stone-400 font-bold mb-0.5" htmlFor="popf-pages-count">عدد الصفحات</label>
                <input
                  type="number"
                  defaultValue="200"
                  className="w-full p-1.5 border border-stone-300 rounded font-mono text-center text-stone-800 font-bold"
                  id="popf-pages-count"
                />
              </div>
              <div className="flex items-end pb-1 pl-2">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="checkbox" defaultChecked className="text-[#ea580c] focus:ring-0 rounded" id="popf-printed-check" />
                  <span className="font-bold text-stone-600 text-[10px]" htmlFor="popf-printed-check">أوراق مطبوعة</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                تاريخ فتح السجل (Date d'Ouverture)
              </label>
              <input
                type="date"
                defaultValue="1994-01-01"
                className="w-full p-2 border border-stone-300 rounded text-stone-800"
              />
            </div>
          </div>

          <div className="bg-amber-50 p-2 rounded border border-amber-200 text-[10.5px] text-amber-800 font-sans mt-2">
            ℹ️ Saisie d'ouverture obligatoire pour certifier la validité juridique de l'ensemble du Tome.
          </div>
        </div>

        {/* Frame 2: Royal Prosecutor Details */}
        <div className="bg-white p-3.5 rounded border border-stone-300 shadow-xs flex flex-col justify-between gap-3 text-xs">
          <div className="space-y-3">
            <h5 className="font-bold text-[#1d4ed8] border-b border-blue-100 pb-1.5 uppercase text-[10px] flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-blue-600" /> معلومات حول وكيل الملك (Infos Tribunal)
            </h5>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                رئيس المحكمة الإبتدائية أو نائبه (Magistrat Autorité)
              </label>
              <input
                type="text"
                defaultValue="الأستاذ بوشعيب الدهبي، وكيل جلالة الملك"
                className="w-full p-2 border border-stone-300 rounded text-right font-display text-xs text-stone-800 font-bold"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1">
                تاريخ التأشير (Date d'Homologation)
              </label>
              <input
                type="date"
                defaultValue="1993-12-15"
                className="w-full p-2 border border-stone-300 rounded text-stone-800"
              />
            </div>

            {/* Verification Checkboxes */}
            <div className="space-y-2 pt-2 bg-stone-50 p-2.5 rounded border border-stone-200">
              <span className="font-bold text-[9px] text-stone-400 block uppercase">Contrôles juridiques (المصادقة)</span>
              
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={isCheckedPO} 
                  onChange={(e) => setIsCheckedPO(e.target.checked)}
                  className="text-[#ea580c] focus:ring-0 rounded"
                  id="popf-check-po"
                />
                <span className="text-[11px] font-medium text-stone-700" htmlFor="popf-check-po">توقيع وكيل الملك بالصفحة الأولى</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={isCheckedPF} 
                  onChange={(e) => setIsCheckedPF(e.target.checked)}
                  className="text-[#ea580c] focus:ring-0 rounded"
                  id="popf-check-pf"
                />
                <span className="text-[11px] font-medium text-stone-700" htmlFor="popf-check-pf">توقيع وكيل الملك بالصفحة الأخيرة</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={isSceauProc} 
                  onChange={(e) => setIsSceauProc(e.target.checked)}
                  className="text-[#ea580c] focus:ring-0 rounded"
                  id="popf-check-sceau-mag"
                />
                <span className="text-[11px] font-medium text-stone-700" htmlFor="popf-check-sceau-mag">خاتم طابع المحكمة المصدر للبداية والنهاية</span>
              </label>
            </div>
          </div>

          <div className="flex gap-1 bg-blue-50/50 p-2 rounded border border-blue-100 text-[10.5px] text-blue-800 font-mono mt-2">
            ⚖️ SIGNATURE VALIDE PAR PROCUREUR
          </div>
        </div>

        {/* Frame 3: Civil Status Officer closure details */}
        <div className="bg-white p-3.5 rounded border border-stone-300 shadow-xs flex flex-col justify-between gap-3 text-xs">
          <div className="space-y-3">
            <h5 className="font-bold text-[#15803d] border-b border-green-100 pb-1.5 uppercase text-[10px] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-green-600" /> معلومات حول ضابط الحالة المدنية (Clôture EC)
            </h5>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                اسم ضابط الحالة المدنية القائم بالختم (Officier signataire)
              </label>
              <input
                type="text"
                defaultValue="عبد العزيز الوزاني، ضابط الحالة المدنية"
                className="w-full p-2 border border-stone-300 rounded text-right font-display text-xs text-stone-850 font-bold"
                dir="rtl"
              />
            </div>

            <div>
              <label className="block text-[10px] text-stone-400 font-bold mb-1 text-right">
                صيغة الختم التلقائية (Déclaration de clôture)
              </label>
              <textarea
                rows={2}
                defaultValue="قفل هذا السجل الخاص برسم الولادة والوفاة لعام ألف وتسعمائة وأربعة وتسعون بعد أن أثبتت به مائتان صفحة مرقمة ومختومة."
                className="w-full p-2 border border-stone-300 rounded text-right font-display text-[11px] text-stone-700 focus:outline-hidden"
                dir="rtl"
              />
            </div>

            {/* Checkboxes */}
            <div className="space-y-2 pt-1 bg-stone-50 p-2.5 rounded border border-stone-200">
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={isSignOff} 
                  onChange={(e) => setIsSignOff(e.target.checked)}
                  className="text-[#ea580c] focus:ring-0 rounded"
                  id="popf-check-sign-off"
                />
                <span className="text-[11px] font-medium text-stone-700" htmlFor="popf-check-sign-off">إمضاء ضابط الحالة المدنية بالختم</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={isSceauOff} 
                  onChange={(e) => setIsSceauOff(e.target.checked)}
                  className="text-[#ea580c] focus:ring-0 rounded"
                  id="popf-check-sceau-off"
                />
                <span className="text-[11px] font-medium text-stone-700" htmlFor="popf-check-sceau-off">ختم ضابط الحالة المدنية بالختم</span>
              </label>
            </div>
          </div>

          <div className="bg-green-50 p-2 rounded border border-green-200 text-[10px] text-green-800 font-sans mt-2">
            ✅ Clôture enregistrée en fin de registre avec succès.
          </div>
        </div>

      </div>
    </div>
  );
}
