/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, AlertTriangle, Check, ShieldCheck, 
  HelpCircle, ChevronLeft, ChevronRight, UserCheck, Sparkles, ArrowRight, Table, Info, FileJson, Download
} from 'lucide-react';
import { PageScan, OperatorSaisieData } from '../types';

interface RejectionSupervisorProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidateStep4: () => void;
  isStep5Unlocked: boolean;
}

export default function RejectionSupervisor({
  scannedPages,
  setScannedPages,
  onValidateStep4,
  isStep5Unlocked,
}: RejectionSupervisorProps) {
  const [selectedPageIndex, setSelectedPageIndex] = useState(0);

  // Grab the page
  const page = scannedPages[selectedPageIndex] || null;

  // Form states for the final consolidated values
  const [correctedNom, setCorrectedNom] = useState('');
  const [correctedPrenom, setCorrectedPrenom] = useState('');
  const [correctedHegire, setCorrectedHegire] = useState('');
  const [correctedMere, setCorrectedMere] = useState('');
  const [correctedPere, setCorrectedPere] = useState('');
  const [correctedNumActe, setCorrectedNumActe] = useState('');
  const [correctedTypeActe, setCorrectedTypeActe] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState(false);

  // Synchronise whenever the current page changes
  useEffect(() => {
    if (page) {
      if (page.supervisorCorrection) {
        setCorrectedNom(page.supervisorCorrection.nom);
        setCorrectedPrenom(page.supervisorCorrection.prenom);
        setCorrectedHegire(page.supervisorCorrection.dateHegirienne);
        setCorrectedMere(page.supervisorCorrection.merePrenom);
        setCorrectedPere(page.supervisorCorrection.perePrenom);
        setCorrectedNumActe(page.supervisorCorrection.numActe || page.numActe);
        setCorrectedTypeActe(page.supervisorCorrection.typeActe || page.typeActe);
      } else {
        // Default to Operator A
        setCorrectedNom(page.operatorA.nom);
        setCorrectedPrenom(page.operatorA.prenom);
        setCorrectedHegire(page.operatorA.dateHegirienne);
        setCorrectedMere(page.operatorA.merePrenom);
        setCorrectedPere(page.operatorA.perePrenom);
        setCorrectedNumActe(page.operatorA.numActe || page.numActe);
        setCorrectedTypeActe(page.operatorA.typeActe || page.typeActe);
      }
      setSuccessMsg(page.isConflictResolved);
    }
  }, [page, selectedPageIndex]);

  if (!page) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center border border-stone-200">
         <p className="font-sans text-sm text-stone-500">Aucun registre disponible pour le contrôle de double saisie 📑</p>
      </div>
    );
  }

  // Detect discrepancies
  const diffNom = page.operatorA.nom !== page.operatorB.nom;
  const diffPrenom = page.operatorA.prenom !== page.operatorB.prenom;
  const diffHegire = page.operatorA.dateHegirienne !== page.operatorB.dateHegirienne;
  const diffMere = page.operatorA.merePrenom !== page.operatorB.merePrenom;
  const diffPere = page.operatorA.perePrenom !== page.operatorB.perePrenom;
  const diffNumActe = page.operatorA.numActe !== page.operatorB.numActe;
  const diffTypeActe = page.operatorA.typeActe !== page.operatorB.typeActe;

  const totalConflicts = [diffNom, diffPrenom, diffHegire, diffMere, diffPere, diffNumActe, diffTypeActe].filter(Boolean).length;

  // Let's check if ANY page in the lot still has different identifiers which has NOT been resolved yet
  const hasIdentifierDiscrepancyInLot = scannedPages.some(p => 
    !p.isConflictResolved && (p.operatorA.numActe !== p.operatorB.numActe || p.operatorA.typeActe !== p.operatorB.typeActe)
  );

  const hasUnresolvedConflictsInLot = scannedPages.some(p => !p.isConflictResolved);

  // Corporate standard JSON mapper
  const mapPageToCorporateJson = (p: PageScan) => {
    const data = p.supervisorCorrection || p.operatorA;
    const gParts = data.dateGregoirienne ? data.dateGregoirienne.split('/') : [];
    const hParts = data.dateHegirienne ? data.dateHegirienne.split('/') : [];

    return {
      "lot_id": "21951001191102",
      "act_num": p.numActe || data.numActe || "1",
      "act_type": (p.typeActe || data.typeActe) === "Naissance" ? "EC" : "DE",
      "source_file": p.filename || "scan_image.jpg",
      "extracted_at": "2605041320",
      "extraction": {
        "acte": {
          "acte.num_acte": p.numActe || data.numActe || "1",
          "acte.nom_ar": data.nomAr || "",
          "acte.prenom_ar": data.prenomAr || "",
          "acte.nom_fr": data.nom || "",
          "acte.prenom_fr": data.prenom || "",
          "acte.jd_naissance_h": hParts[0] || "15",
          "acte.md_naissance_h": hParts[1] || "05",
          "acte.ad_naissance_h": hParts[2] || "1414",
          "acte.jd_naissance_g": gParts[0] || "12",
          "acte.md_naissance_g": gParts[1] || "10",
          "acte.ad_naissance_g": gParts[2] || "1994",
          "acte.lieu_naissance": p.numBEC || "BEC-341",
          "acte.sexe": "M",
          "acte.nationalite": "Marocaine",
          "acte.prenom_pere_ar": data.perePrenom || "",
          "acte.prenom_mere_ar": data.merePrenom || "",
          "acte.prenom_pere_fr": data.perePrenom || "",
          "acte.prenom_mere_fr": data.merePrenom || "",
          "acte.officier_fr": "SI BAHAJ MOHAMMED",
          "acte.lieu_naissance_fr": "TRIBU OULAD ALI OUALLAOUANE"
        },
        "deces": (p.typeActe || data.typeActe) === "Décès" ? {
          "deces.jd_deces_g": gParts[0] || "12",
          "deces.md_deces_g": gParts[1] || "12",
          "deces.ad_deces_g": gParts[2] || "2026",
          "deces.lieu_deces": "DOUAR AIDI"
        } : {},
        "declaration": {},
        "transcription": {},
        "jugement": {},
        "mentions": []
      }
    };
  };

  const downloadStudiedActsJson = () => {
    const corporateList = scannedPages.map(mapPageToCorporateJson);
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(corporateList, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "actes_etudies_lot_21951001191102.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleApplyResolution = (fields: Partial<OperatorSaisieData>) => {
    if (fields.nom !== undefined) setCorrectedNom(fields.nom);
    if (fields.prenom !== undefined) setCorrectedPrenom(fields.prenom);
    if (fields.dateHegirienne !== undefined) setCorrectedHegire(fields.dateHegirienne);
    if (fields.merePrenom !== undefined) setCorrectedMere(fields.merePrenom);
    if (fields.perePrenom !== undefined) setCorrectedPere(fields.perePrenom);
    if (fields.numActe !== undefined) setCorrectedNumActe(fields.numActe);
    if (fields.typeActe !== undefined) setCorrectedTypeActe(fields.typeActe);

    setScannedPages(prev => prev.map((p, idx) => {
      if (idx === selectedPageIndex) {
        const updatedA = { ...p.operatorA };
        const updatedB = { ...p.operatorB };
        if (fields.numActe !== undefined) {
          updatedA.numActe = fields.numActe;
          updatedB.numActe = fields.numActe;
        }
        if (fields.typeActe !== undefined) {
          updatedA.typeActe = fields.typeActe;
          updatedB.typeActe = fields.typeActe;
        }

        const updatedCorrection: OperatorSaisieData = {
          ...(p.supervisorCorrection || p.operatorA),
          ...fields
        };

        return { 
          ...p, 
          operatorA: updatedA,
          operatorB: updatedB,
          supervisorCorrection: updatedCorrection,
          numActe: fields.numActe !== undefined ? fields.numActe : p.numActe,
          typeActe: fields.typeActe !== undefined ? fields.typeActe : p.typeActe,
          isConflictResolved: true,
          status: 'DoubleSaisie'
        };
      }
      return p;
    }));
    setSuccessMsg(true);
  };

  const handleResolveDirectly = () => {
    const finalData: OperatorSaisieData = {
      ...page.operatorA,
      nom: correctedNom,
      prenom: correctedPrenom,
      dateHegirienne: correctedHegire,
      merePrenom: correctedMere,
      perePrenom: correctedPere,
      numActe: correctedNumActe,
      typeActe: correctedTypeActe as any,
    };

    setScannedPages(prev => prev.map((p, idx) => {
      if (idx === selectedPageIndex) {
        const updatedA = { ...p.operatorA, numActe: correctedNumActe, typeActe: correctedTypeActe as any };
        const updatedB = { ...p.operatorB, numActe: correctedNumActe, typeActe: correctedTypeActe as any };
        return { 
          ...p, 
          operatorA: updatedA,
          operatorB: updatedB,
          supervisorCorrection: finalData,
          numActe: correctedNumActe,
          typeActe: correctedTypeActe as any,
          isConflictResolved: true,
          status: 'DoubleSaisie'
        };
      }
      return p;
    }));
    setSuccessMsg(true);
  };

  const autoResolvePage = () => {
    handleApplyResolution({
      nom: page.operatorA.nom,
      prenom: page.operatorA.prenom,
      dateHegirienne: page.operatorA.dateHegirienne,
      merePrenom: page.operatorA.merePrenom,
      perePrenom: page.operatorA.perePrenom,
      numActe: page.operatorA.numActe || page.numActe,
      typeActe: page.operatorA.typeActe || page.typeActe,
    });
  };

  const autoResolveAllPages = () => {
    setScannedPages(prev => prev.map(p => {
      const parentNum = p.operatorA.numActe || p.numActe;
      const parentType = p.operatorA.typeActe || p.typeActe;
      
      const newA = { ...p.operatorA, numActe: parentNum, typeActe: parentType };
      const newB = { ...p.operatorB, numActe: parentNum, typeActe: parentType };
      
      return {
        ...p,
        operatorA: newA,
        operatorB: newB,
        supervisorCorrection: p.supervisorCorrection || {
          ...p.operatorA,
          numActe: parentNum,
          typeActe: parentType
        },
        isConflictResolved: true,
        status: 'DoubleSaisie'
      };
    }));
    setSuccessMsg(true);
  };

  return (
    <div className="space-y-6" id="rejection-supervisor-stage">
      
      {/* Upper Explanation Banner */}
      <div className="bg-amber-50 border border-amber-200 p-5 rounded-2xl space-y-2">
        <h4 className="font-display font-bold text-amber-900 text-sm flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-700" />
          Comprendre l'Arbitrage & la Double Saisie en 1 minute 💡
        </h4>
        <p className="text-xs text-amber-800 leading-relaxed">
          Pour garantir <strong>zéro erreur d'orthographe</strong> dans la base de données, deux agents différents (Saisie A et Saisie B) ont retapé les informations de l'acte d'État Civil.
          <br />
          S'ils ont écrit exactement la même chose, l'acte est validé. S'il y a une différence (surlignée en <strong className="text-red-700">rouge</strong>), <strong>cliquez simplement sur l'une des cases ci-dessous</strong> pour choisir la bonne spelling et corriger l'écart instantly !
        </p>
      </div>

      {/* Current Page Identifier Static Banner */}
      <div className="bg-stone-100 p-4 rounded-2xl border border-stone-200 flex flex-col md:flex-row justify-between items-center gap-3">
        <div className="flex items-center gap-3">
          <div className="py-1.5 px-3 bg-rose-800 rounded-xl text-xs font-black text-white font-sans uppercase">
            PAGE {selectedPageIndex + 1}
          </div>
          <div>
            <h4 className="font-display font-black text-stone-900 text-sm">
              Arbitrage de l'acte : {page.typeActe} N° {page.numActe}
            </h4>
            <span className="text-[10px] font-mono font-bold text-stone-500">
              BEC : {page.numBEC} | TOME : {page.numTome} | DOCUMENT : {page.filename}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-rose-700 rounded-full animate-pulse" />
          <span className="text-xs font-bold text-stone-700 uppercase">
            Correction Écart Double Saisie
          </span>
        </div>
      </div>

      {/* Discrepancies direct table selection */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 space-y-4">
        <div className="flex justify-between items-center border-b border-stone-100 pb-3">
          <h4 className="font-display font-bold text-stone-900 text-sm">
            Comparatif des deux saisies & Arbitrage direct
          </h4>
          <span className="text-[10px] bg-stone-100 font-mono px-2 py-0.5 rounded text-stone-600">
            {totalConflicts} Écart(s) détecté(s)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-200 text-stone-500">
                <th className="p-3 font-semibold">Attribut de l'Acte</th>
                <th className="p-3 font-semibold text-rose-800">Saisie Opératrice A (Bureau 13)</th>
                <th className="p-3 font-semibold text-stone-700">Saisie Opératrice B (Bureau 14)</th>
                <th className="p-3 font-semibold text-center text-green-700">Valeur validée</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              
              {/* Row: Numéro d'Acte discrepant */}
              {diffNumActe && (
                <tr className="hover:bg-stone-50/50 bg-red-100/50">
                  <td className="p-3 font-bold text-red-950 flex items-center gap-1.5 shrink-0">
                    <span className="w-2 h-2 rounded-full bg-red-600 animate-ping shrink-0" />
                    Numéro de l'Acte
                  </td>
                  <td className="p-3">
                    <button 
                      onClick={() => handleApplyResolution({ numActe: page.operatorA.numActe })}
                      className="w-full text-left p-2.5 rounded-lg border border-red-300 bg-white hover:bg-rose-50 text-stone-900 font-extrabold transition-all flex justify-between items-center"
                    >
                      <span>{page.operatorA.numActe}</span>
                      <span className="text-[9px] bg-rose-100 border border-rose-200 text-rose-800 px-1.5 py-0.5 rounded font-black">Garder A (Identifiant)</span>
                    </button>
                  </td>
                  <td className="p-3">
                    <button 
                      onClick={() => handleApplyResolution({ numActe: page.operatorB.numActe })}
                      className="w-full text-left p-2.5 rounded-lg border border-red-350 bg-white hover:bg-rose-50 text-stone-900 font-extrabold transition-all flex justify-between items-center"
                    >
                      <span>{page.operatorB.numActe}</span>
                      <span className="text-[9px] bg-stone-100 border border-stone-250 text-stone-700 px-1.5 py-0.5 rounded font-black">Garder B (Identifiant)</span>
                    </button>
                  </td>
                  <td className="p-3 text-center">
                    <span className="bg-red-50 border border-red-300 text-red-950 font-mono font-black px-3.5 py-2 rounded-lg text-xs">
                      {correctedNumActe}
                    </span>
                  </td>
                </tr>
              )}

              {/* Row: Type d'Acte discrepant */}
              {diffTypeActe && (
                <tr className="hover:bg-stone-50/50 bg-red-100/50">
                  <td className="p-3 font-bold text-red-950 flex items-center gap-1.5 shrink-0">
                    <span className="w-2 h-2 rounded-full bg-red-600 animate-ping shrink-0" />
                    Type de l'Acte
                  </td>
                  <td className="p-3">
                    <button 
                      onClick={() => handleApplyResolution({ typeActe: page.operatorA.typeActe })}
                      className="w-full text-left p-2.5 rounded-lg border border-red-300 bg-white hover:bg-rose-50 text-stone-900 font-extrabold transition-all flex justify-between items-center"
                    >
                      <span>{page.operatorA.typeActe}</span>
                      <span className="text-[9px] bg-rose-100 border border-rose-200 text-rose-800 px-1.5 py-0.5 rounded font-black">Garder A (Identifiant)</span>
                    </button>
                  </td>
                  <td className="p-3">
                    <button 
                      onClick={() => handleApplyResolution({ typeActe: page.operatorB.typeActe })}
                      className="w-full text-left p-2.5 rounded-lg border border-red-350 bg-white hover:bg-rose-50 text-stone-900 font-extrabold transition-all flex justify-between items-center"
                    >
                      <span>{page.operatorB.typeActe}</span>
                      <span className="text-[9px] bg-stone-100 border border-stone-250 text-stone-700 px-1.5 py-0.5 rounded font-black">Garder B (Identifiant)</span>
                    </button>
                  </td>
                  <td className="p-3 text-center">
                    <span className="bg-red-50 border border-red-300 text-red-950 font-mono font-black px-3.5 py-2 rounded-lg text-xs">
                      {correctedTypeActe}
                    </span>
                  </td>
                </tr>
              )}
              
              {/* Nom attribute row */}
              <tr className={`hover:bg-stone-50/50 ${diffNom ? 'bg-red-50/40' : ''}`}>
                <td className="p-3 font-bold text-stone-700">Nom de Famille</td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ nom: page.operatorA.nom })}
                    className="w-full text-left p-2.5 rounded-lg border border-red-200 bg-white hover:bg-rose-50 text-stone-800 font-bold transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorA.nom}</span>
                    <span className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 px-1.5 py-0.5 rounded">Garder A</span>
                  </button>
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ nom: page.operatorB.nom })}
                    className="w-full text-left p-2.5 rounded-lg border border-red-200 bg-white hover:bg-rose-50 text-stone-800 font-bold transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorB.nom}</span>
                    <span className="text-[9px] bg-stone-100 border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded">Garder B</span>
                  </button>
                </td>
                <td className="p-3 text-center">
                  <span className="bg-green-50 border border-green-200 text-green-800 font-mono font-bold px-3 py-1.5 rounded-lg text-xs">
                    {correctedNom}
                  </span>
                </td>
              </tr>

              {/* Prenom row */}
              <tr className={`hover:bg-stone-50/50 ${diffPrenom ? 'bg-red-50/40' : ''}`}>
                <td className="p-3 font-bold text-stone-700">Prénom Civil</td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ prenom: page.operatorA.prenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 font-medium transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorA.prenom}</span>
                    <span className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 px-1.5 py-0.5 rounded">Garder A</span>
                  </button>
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ prenom: page.operatorB.prenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 font-medium transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorB.prenom}</span>
                    <span className="text-[9px] bg-stone-100 border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded">Garder B</span>
                  </button>
                </td>
                <td className="p-3 text-center">
                  <span className="bg-green-50 border border-green-200 text-green-800 font-mono font-bold px-3 py-1.5 rounded-lg text-xs">
                    {correctedPrenom}
                  </span>
                </td>
              </tr>

              {/* Hegirienne Date row */}
              <tr className={`hover:bg-stone-50/50 ${diffHegire ? 'bg-red-50/40' : ''}`}>
                <td className="p-3 font-bold text-stone-700">Date de l'acte (Hégirienne)</td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ dateHegirienne: page.operatorA.dateHegirienne })}
                    className="w-full text-left p-2.5 rounded-lg border border-red-200 bg-white hover:bg-rose-50 text-stone-800 font-mono transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorA.dateHegirienne}</span>
                    <span className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 px-1.5 py-0.5 rounded">Garder A</span>
                  </button>
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ dateHegirienne: page.operatorB.dateHegirienne })}
                    className="w-full text-left p-2.5 rounded-lg border border-red-200 bg-white hover:bg-rose-50 text-stone-800 font-mono transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorB.dateHegirienne}</span>
                    <span className="text-[9px] bg-stone-100 border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded">Garder B</span>
                  </button>
                </td>
                <td className="p-3 text-center">
                  <span className="bg-green-50 border border-green-200 text-green-800 font-mono font-bold px-3 py-1.5 rounded-lg text-xs">
                    {correctedHegire}
                  </span>
                </td>
              </tr>

              {/* Pere row */}
              <tr className={`hover:bg-stone-50/50 ${diffPere ? 'bg-red-50/40' : ''}`}>
                <td className="p-3 font-bold text-stone-700">Nom du Père</td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ perePrenom: page.operatorA.perePrenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorA.perePrenom}</span>
                    <span className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 px-1.5 py-0.5 rounded">Garder A</span>
                  </button>
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ perePrenom: page.operatorB.perePrenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorB.perePrenom}</span>
                    <span className="text-[9px] bg-stone-100 border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded">Garder B</span>
                  </button>
                </td>
                <td className="p-3 text-center">
                  <span className="bg-green-50 border border-green-200 text-green-800 font-mono font-bold px-3 py-1.5 rounded-lg text-xs">
                    {correctedPere}
                  </span>
                </td>
              </tr>

              {/* Mere row */}
              <tr className={`hover:bg-stone-50/50 ${diffMere ? 'bg-red-50/40' : ''}`}>
                <td className="p-3 font-bold text-stone-700">Nom de la Mère</td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ merePrenom: page.operatorA.merePrenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorA.merePrenom}</span>
                    <span className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 px-1.5 py-0.5 rounded">Garder A</span>
                  </button>
                </td>
                <td className="p-3">
                  <button 
                    onClick={() => handleApplyResolution({ merePrenom: page.operatorB.merePrenom })}
                    className="w-full text-left p-2.5 rounded-lg border border-stone-200 bg-white hover:bg-rose-50 text-stone-800 transition-all flex justify-between items-center"
                  >
                    <span>{page.operatorB.merePrenom}</span>
                    <span className="text-[9px] bg-stone-100 border border-stone-200 text-stone-600 px-1.5 py-0.5 rounded">Garder B</span>
                  </button>
                </td>
                <td className="p-3 text-center">
                  <span className="bg-green-50 border border-green-200 text-green-800 font-mono font-bold px-3 py-1.5 rounded-lg text-xs">
                    {correctedMere}
                  </span>
                </td>
              </tr>

            </tbody>
          </table>
        </div>

        {/* Unified decision confirmation */}
        <div className="pt-3 border-t border-stone-100 flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="text-xs font-sans font-medium text-stone-500">
            {page.isConflictResolved ? (
              <span className="text-green-700 font-bold flex items-center gap-1.5 bg-green-50 px-3 py-1 rounded-full border border-green-100">
                <Check className="w-4 h-4 text-green-600" /> Arbitrage complété avec succès ! L'acte est cohérent pour cet enregistrement.
              </span>
            ) : (
              <span className="text-stone-500 italic block">
                [ Vous pouvez modifier directement en cliquant sur un bouton ou corriger manuellement ]
              </span>
            )}
          </div>

          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={autoResolvePage}
              className="flex-1 sm:flex-initial px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl border border-stone-200 transition-all"
            >
              🔄 Choisir Saisie A par défaut (Page active)
            </button>
            <button
              onClick={handleResolveDirectly}
              className="flex-1 sm:flex-initial px-5 py-2 bg-rose-800 hover:bg-rose-900 text-white rounded-xl text-xs font-bold shadow-sm transition-all text-center"
            >
              Enregistrer l'évaluation ✔
            </button>
          </div>
        </div>
      </div>

      {/* 🔟 Navigation des Pages Traitées (de 1 à 10) positionnée dans le bas */}
      <div className="bg-white p-4 rounded-2xl border-2 border-stone-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4 my-2 select-none">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-rose-700 rounded-full animate-pulse" />
          <span className="text-xs font-bold text-stone-700 uppercase">
            Traitement des Documents : Page {selectedPageIndex + 1} sur {scannedPages.length}
          </span>
        </div>

        {/* List of numbered buttons 1 to 10 */}
        <div className="flex flex-wrap gap-1.5 items-center justify-center">
          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.max(0, prev - 1))}
            disabled={selectedPageIndex === 0}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
            id="rs-prev-btn-bottom"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Préc.
          </button>

          {scannedPages.map((p, idx) => {
            const hasConflict = p.operatorA.nom !== p.operatorB.nom || p.operatorA.dateHegirienne !== p.operatorB.dateHegirienne;
            const isResolved = p.isConflictResolved;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedPageIndex(idx)}
                className={`py-1.5 px-3 rounded-lg font-mono text-xs font-bold transition-all border flex items-center gap-1.5 ${
                  selectedPageIndex === idx 
                    ? "bg-rose-800 text-white border-rose-800 shadow-sm font-black scale-105" 
                    : "bg-white text-stone-600 border-stone-200 hover:bg-stone-50"
                }`}
                id={`rs-page-btn-bottom-${idx}`}
              >
                <span>{idx + 1}</span>
                {hasConflict && !isResolved ? (
                  <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                )}
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setSelectedPageIndex(prev => Math.min(scannedPages.length - 1, prev + 1))}
            disabled={selectedPageIndex === scannedPages.length - 1}
            className="p-1.5 px-3 bg-stone-50 border border-stone-200 hover:bg-stone-100 rounded-lg disabled:opacity-30 disabled:hover:bg-stone-50 text-xs font-bold font-sans transition-all flex items-center gap-1 text-stone-750"
            id="rs-next-btn-bottom"
          >
            Suiv. <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Footer Navigation Bar */}
      <div className="flex flex-col gap-4 pt-4 border-t border-stone-200">
        
        {/* Beautiful Cute JSON Download Box */}
        <div className="bg-bubble-pink border border-pastel-pink rounded-3xl p-5 shadow-clay-sm animate-fade-in">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex gap-3">
              <div className="w-9 h-9 bg-deep-pink rounded-xl flex items-center justify-center text-white shrink-0 shadow-sm">
                <FileJson className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-black text-xs md:text-sm text-stone-900 uppercase">
                  📦 TÉLÉCHARGEMENT DES ACTES ÉTUDIÉS (FORMAT JSON)
                </h4>
                <p className="text-[11px] text-stone-600 mt-0.5 font-sans font-medium">
                  Avant de passer à l'étape IA, téléchargez les actes validés durant l'étape de préparation sous le format JSON officiel de la société (structure à 5 actes).
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={downloadStudiedActsJson}
              className="w-full sm:w-auto px-5 py-2.5 bg-deep-pink hover:bg-light-pink text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
              id="btn-download-studied-acts-json"
            >
              <Download className="w-4 h-4" /> Télécharger les Actes (.json)
            </button>
          </div>
        </div>

        {hasIdentifierDiscrepancyInLot && (
          <div className="bg-red-55 border bg-white border-red-200 rounded-2xl p-5 text-red-900 shadow-xs">
            <div className="flex gap-3">
              <span className="text-xl shrink-0">⚠️</span>
              <div>
                <h4 className="font-display font-black text-xs md:text-sm text-red-950 uppercase">
                  Passage Bloqué : Identifiants Multiples Détectés !
                </h4>
                <p className="text-[10.5px] text-red-800 mt-1 leading-relaxed font-sans font-medium">
                  Un ou plusieurs actes de ce lot possèdent des <strong>identifiants discordants entre Saisie A et Saisie B</strong> (Numéro d'Acte ou Type d'Acte non identiques). 
                  Il est strictement interdit de passer à l'étape suivante tant que ces incohérences majeures d'identifiants ne sont pas arbitrées et unifiées.
                  <br />
                  <span className="font-bold underline">Solution :</span> Parcourez les pages marquées avec des écarts d'identifiants et cliquez sur les boutons d'arbitrage <strong>"Garder A"</strong> ou <strong>"Garder B"</strong> correspondants pour certifier l'identifiant légal.
                </p>
              </div>
            </div>
          </div>
        )}

        {!hasUnresolvedConflictsInLot && !hasIdentifierDiscrepancyInLot ? (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-emerald-950 shadow-xs animate-fade-in">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex gap-3">
                <span className="text-2xl shrink-0">🎉</span>
                <div>
                  <h4 className="font-display font-black text-xs md:text-sm text-emerald-900 uppercase">
                    ✨ TOUS LES ACTES SONT VALIDÉS ET ARBITRÉS !
                  </h4>
                  <p className="text-[11px] text-stone-700 mt-0.5 font-sans font-medium">
                    Excellent ! Aucun écart de double saisie ou anomalie ne subsiste. Vous pouvez désormais passer à l'étape suivante : <strong>Moteur d'IA & SQL (Partie 4)</strong>.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onValidateStep4}
                className="w-full sm:w-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                id="btn-shortcut-ia-step"
              >
                Passer à l'Étape IA 🧠 ➡️
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-amber-900 shadow-xs">
            <div className="flex gap-3">
              <span className="text-xl shrink-0">💡</span>
              <div>
                <h4 className="font-display font-black text-xs md:text-sm text-amber-950 uppercase">
                  Certains actes nécessitent votre arbitrage
                </h4>
                <p className="text-[11px] text-amber-800 mt-0.5 font-sans font-medium">
                  Pour valider l'étape de traitement des rejets et passer à l'étape IA, résolvez les écarts sur les <strong>{scannedPages.filter(p => !p.isConflictResolved).length} actes restants</strong> en cliquant sur Saisie A / Saisie B, ou utilisez le bouton d'auto-arbitrage rapide ci-dessous.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center flex-wrap gap-4">
          
          <div className="flex items-center gap-2">
            {/* Bulk auto correction tool */}
            <button
              type="button"
              disabled={hasIdentifierDiscrepancyInLot}
              onClick={autoResolveAllPages}
              className={`px-5 py-3.5 border text-xs font-bold rounded-2xl transition-all flex items-center gap-2 ${
                hasIdentifierDiscrepancyInLot
                  ? "bg-stone-105 border-stone-200 text-stone-400 cursor-not-allowed opacity-50"
                  : "bg-green-50 border-green-350 text-green-800 hover:bg-green-100/50 cursor-pointer"
              }`}
            >
              ⚡ Auto-Arbitrer et Valider tout le Lot (1-clic)
            </button>

            <button
              type="button"
              onClick={downloadStudiedActsJson}
              className="px-5 py-3.5 border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-bold rounded-2xl transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-stone-500" /> Export JSON
            </button>
          </div>

          {/* Continue on next step button */}
          <button
            onClick={() => {
              if (hasIdentifierDiscrepancyInLot) {
                alert("🚨 Impossible de valider : Vous ne pouvez pas passer à l'étape suivante si un acte a deux identifiants différents.");
                return;
              }
              onValidateStep4();
            }}
            disabled={hasIdentifierDiscrepancyInLot}
            className={`px-8 py-3.5 font-display font-bold text-sm rounded-2xl shadow-sm transition-all flex items-center gap-2 shrink-0 ${
              hasIdentifierDiscrepancyInLot
                ? "bg-stone-200 text-stone-400 border border-stone-300 cursor-not-allowed opacity-50"
                : hasUnresolvedConflictsInLot
                ? "bg-amber-600 hover:bg-amber-700 text-white cursor-pointer"
                : "bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer animate-pulse"
            }`}
            id="btn-validate-step-4"
          >
            <span>
              {hasUnresolvedConflictsInLot 
                ? "Valider l'Arbitrage & Forcer Passage IA ➡️" 
                : "Valider l'Arbitrage & Passer à l'Étape IA 🧠 ➡️"}
            </span>
          </button>

        </div>
      </div>

    </div>
  );
}
