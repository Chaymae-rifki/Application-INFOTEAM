/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * WorkflowPreparation.tsx - Replicates "Numérisation & Préparation" Moroccan Civil Digitization suite
 */

import React, { useState, useEffect } from 'react';
import { 
  FolderOpen, Grid, Camera, Image as ImageIcon, CheckCircle, AlertTriangle, 
  ChevronLeft, ChevronRight, RotateCw, ZoomIn, ZoomOut, Check, ArrowRight,
  Database, UserCheck, List, FileText, Landmark, ShieldAlert, Sparkles, RefreshCw, BarChart2
} from 'lucide-react';
import { PageScan, ActeType, PieceJointe } from '../types';
import ZenithalCamera from './ZenithalCamera';
import { PRESET_PAGES, getPresetPool } from '../data';

interface WorkflowPreparationProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidatePreparation: () => void;
  isIAStageUnlocked: boolean;
  forceMode?: 'scan' | 'controle_image' | 'rejets' | 'identification';
  resetCounter?: number;
}

type SubView = 
  | 'inventaire' | 'importer' | 'rejets-manques' | 'affectations'
  | 'controle-images' | 'id-rc' | 'id-rp' | 'rejets-id' | 'acte-final'
  | 'statistiques' | 'affectations-suivi' | 'utilisateurs' | 'pvs' | 'status-bec';

export default function WorkflowPreparation({
  scannedPages,
  setScannedPages,
  onValidatePreparation,
  isIAStageUnlocked,
  forceMode,
  resetCounter = 0,
}: WorkflowPreparationProps) {
  const [activeTab, setActiveTab] = useState<'num' | 'prep' | 'suivi' | 'admin'>(() => {
    if (forceMode === 'controle_image' || forceMode === 'identification') return 'prep';
    return 'num';
  });
  const [currentSubView, setCurrentSubView] = useState<SubView>(() => {
    if (forceMode === 'controle_image') return 'controle-images';
    if (forceMode === 'identification') return 'id-rc';
    if (forceMode === 'rejets') return 'rejets-manques';
    return 'inventaire';
  });

  useEffect(() => {
    if (forceMode === 'controle_image') {
      setActiveTab('prep');
      setCurrentSubView('controle-images');
    } else if (forceMode === 'identification') {
      setActiveTab('prep');
      setCurrentSubView('id-rc');
    } else if (forceMode === 'rejets') {
      setActiveTab('num');
      setCurrentSubView('rejets-manques');
    } else if (forceMode === 'scan') {
      setActiveTab('num');
      setCurrentSubView('importer');
    }
  }, [forceMode]);

  const [selectedPageIndex, setSelectedPageIndex] = useState<number>(0);

  // Filters for scan selection
  const [becFilter, setBecFilter] = useState('BEC-341');
  const [typeFilter, setTypeFilter] = useState('Naissance');

  // Popup state for new registry
  const [showAddRegisterDialog, setShowAddRegisterDialog] = useState(false);
  const [newRegisterYear, setNewRegisterYear] = useState('2026');
  const [newRegisterBEC, setNewRegisterBEC] = useState('BEC-341');
  const [newRegisterType, setNewRegisterType] = useState('Naissance');

  const page = scannedPages[selectedPageIndex] || scannedPages[0] || null;

  useEffect(() => {
    if (scannedPages.length > 0 && selectedPageIndex >= scannedPages.length) {
      setSelectedPageIndex(0);
    }
  }, [scannedPages, selectedPageIndex]);

  const updatePage = (fields: Partial<PageScan>) => {
    setScannedPages(prev => prev.map((p, idx) => {
      if (idx === selectedPageIndex) {
        return { ...p, ...fields };
      }
      return p;
    }));
  };

  const handleDownloadJson = () => {
    // Standardized mapping + original PageScan attributes for robustness
    const exportData = scannedPages.map(page => ({
      id: page.id,
      acte_id: page.id,
      numero_acte: page.numActe,
      tome: page.numTome,
      code_bec: page.numBEC,
      type_acte: page.typeActe,
      prenom: page.operatorA?.prenom || "",
      nom: page.operatorA?.nom || "",
      prenom_arabe: page.operatorA?.prenomAr || "",
      nom_arabe: page.operatorA?.nomAr || "",
      date_gregoirienne: page.operatorA?.dateGregoirienne || "",
      date_hegirienne: page.operatorA?.dateHegirienne || "",
      prenom_pere: page.operatorA?.perePrenom || "",
      prenom_mere: page.operatorA?.merePrenom || "",
      ville: "Fès Medina",
      status: page.status || "Identifié",
      // Keep structural compatibility with PageScan
      operatorA: page.operatorA,
      operatorB: page.operatorB,
      piecesJointes: page.piecesJointes,
      filename: page.filename,
    }));

    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Actes_Identifies_Lot_${Date.now().toString().slice(-6)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  // Rotation and zoom controllers for active viewport
  const handleRotation = () => {
    if (!page) return;
    const nextRot = (page.rotation + 90) % 360;
    updatePage({ rotation: nextRot });
  };

  const handleZoom = (amount: number) => {
    if (!page) return;
    const nextZoom = Math.min(Math.max(page.zoom + amount, 0.8), 2.0);
    updatePage({ zoom: parseFloat(nextZoom.toFixed(1)) });
  };

  const toggleBinarized = () => {
    if (!page) return;
    updatePage({ binarized: !page.binarized });
  };

  const toggleDeskew = () => {
    if (!page) return;
    updatePage({ deskew: !page.deskew });
  };

  if (scannedPages.length === 0) {
    return (
      <div className="bg-[#f0f0f0] border-2 border-stone-400 rounded-xl p-8 text-center text-stone-700 shadow-md">
        <Landmark className="w-12 h-12 text-stone-400 mx-auto mb-3" />
        <h4 className="font-mono text-sm font-bold text-stone-800">Aucun lot de registres chargé</h4>
        <p className="text-xs font-sans text-stone-500 max-w-md mx-auto mt-1">
          Veuillez importer des scans de pages ou restaurer les lots par défaut pour démarrer la préparation.
        </p>
        <button
          onClick={() => {
            setScannedPages(JSON.parse(JSON.stringify(getPresetPool(resetCounter))));
          }}
          className="mt-4 px-6 py-2 bg-stone-700 text-white rounded font-mono text-xs border border-stone-600 hover:bg-stone-800"
        >
          📂 Charger les lots prédéfinis du BEC Fès/Marrakech
        </button>
      </div>
    );
  }

  // Render simulated document image with current binarized/rotated properties
  const renderDocumentView = () => {
    if (!page) return null;
    let filterClass = "";
    if (page.binarized) {
      filterClass = "grayscale contrast-200 brightness-150";
    }
    let rotClass = "rotate-0";
    if (page.rotation === 90) rotClass = "rotate-90";
    if (page.rotation === 180) rotClass = "rotate-180";
    if (page.rotation === 270) rotClass = "rotate-270";

    const styleObj = {
      transform: `scale(${page.zoom}) ${page.deskew ? 'rotate(0deg)' : 'rotate(-2deg)'}`,
      transition: 'all 0.2s ease-in-out',
    };

    return (
      <div className="w-full h-full relative overflow-hidden bg-[#faf4ea] rounded-xs border border-[#decbb0] flex flex-col justify-between p-4 shadow-inner">
        {page.customPreview ? (
          <div style={styleObj} className={`w-full h-full flex items-center justify-center ${filterClass} ${rotClass}`}>
            <img 
              src={page.customPreview} 
              className="max-h-full max-w-full object-contain mx-auto" 
              alt="Scan Registre" 
              referrerPolicy="no-referrer"
            />
          </div>
        ) : (
          <div style={styleObj} className={`w-full h-full flex flex-col justify-between ${filterClass} ${rotClass} text-stone-800`}>
            {/* Header */}
            <div className="flex justify-between items-start border-b border-[#c8b495] pb-1.5 text-[8px] font-sans">
              <div className="text-stone-600 font-bold leading-tight">
                ROYAUME DU MAROC<br />
                COMMUNE DE FÈS
              </div>
              <div className="text-right text-stone-600 leading-tight">
                BUREAU D'ÉTAT CIVIL<br />
                {page.numBEC}
              </div>
            </div>

            {/* Core certificate details */}
            <div className="grid grid-cols-12 gap-1 my-2 h-full items-stretch">
              <div className="col-span-3 border-r border-[#decbb0] pr-1 flex flex-col justify-between text-[7px] text-[#c9184a] font-bold text-center">
                <div>
                  <span className="block font-serif">الملاحظات الهامشية</span>
                  <span className="block text-[5px] text-stone-400">Mentions Marginales</span>
                </div>
                <div className="bg-red-50 p-1 rounded border border-red-200 my-1 text-[6px]">
                  {page.isOpeningPage && "📚 PO Actif"}
                  {page.isClosingPage && "🔒 PF Actif"}
                  {page.isFoldedText && "⚠️ Twya (Pliure)"}
                  {page.isStrikethrough && "⚠️ Acte Barré"}
                </div>
                <div className="text-[6px] font-mono text-stone-400">TOME: {page.numTome}</div>
              </div>

              <div className="col-span-9 pl-1 text-right font-serif flex flex-col justify-between">
                <div>
                  <h3 className="text-center font-bold text-xs text-amber-900 border-b border-[#e6cca0] pb-0.5">
                    رسم {page.typeActe === 'Naissance' ? 'الولادة' : page.typeActe === 'Décès' ? 'الوفاة' : page.typeActe === 'Mariage' ? 'الزواج' : 'الطلاق'}
                  </h3>
                  <span className="block text-left text-[6px] text-stone-400 font-sans">Acte de {page.typeActe}</span>
                </div>

                <div className="space-y-1 my-1 text-stone-800 text-[8px] leading-tight">
                  <div className="flex justify-between items-center w-full">
                    <span className="text-stone-400 text-[6px]">N° Acte: {page.numActe}</span>
                    <span className="font-bold">في يوم العاشر من أبريل لعام ألف وتسعمائة وأربعة وتسعون</span>
                  </div>
                  <div className="font-bold flex justify-between items-center text-[8px]">
                    <span className="text-stone-400 text-[6px]">Nom: {page.operatorA.nom}</span>
                    <span className="text-amber-900">ولد من الجنس {page.typeActe === 'Naissance' ? 'الأنثوي' : 'الذكري'}</span>
                  </div>
                  <div className="text-[7px] text-stone-600">
                    والدها {page.operatorA.perePrenom}، والدتها {page.operatorA.merePrenom}، المقيمين بالفاس المدينة
                  </div>
                </div>

                <div className="flex justify-between items-center text-[6px] text-stone-400 border-t border-[#decbb0] pt-0.5">
                  <span className="font-mono">Brut ID: {page.id}</span>
                  <span className="font-bold">القاضي المفوض ببلدية فاس</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="border-t border-[#c8b495] pt-1 text-[6.5px] text-stone-400 flex justify-between font-mono">
              <span>{page.filename}</span>
              <span>MAROC DIRECTION NUMÉRIQUE</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4" id="workflow-preparation-moroccan">
      
      {/* 💻 Windows Classic Client Layout Frame */}
      <div className="bg-[#eaeaea] border-2 border-[#b2b2b2] rounded-xs shadow-md p-1.5 font-sans select-none">
        
        {/* Title Bar with retro icons */}
        <div className="bg-[#0055e5] text-white px-2 py-1.5 flex justify-between items-center font-bold text-xs select-none">
          <div className="flex items-center gap-1.5 font-mono">
            <span>🎨</span>
            <span>Numérisation et Préparation Nationale de l'État Civil v4.6 (BEC: {becFilter})</span>
          </div>
          <div className="flex items-center gap-1">
            <button className="w-4 h-4 bg-[#cccccc] text-black text-[9px] font-bold border border-[#ffffff] flex items-center justify-center hover:bg-[#b2b2b2]">_</button>
            <button className="w-4 h-4 bg-[#cccccc] text-black text-[9px] font-bold border border-[#ffffff] flex items-center justify-center hover:bg-[#b2b2b2]">▢</button>
            <button className="w-4 h-4 bg-[#c80000] text-white text-[9px] font-bold border border-[#ffffff] flex items-center justify-center hover:bg-[#e60000]">X</button>
          </div>
        </div>

        {/* Outer Split Pane: Sidebar Tabs on Left + Work Area on Right */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-1.5 mt-1.5 items-stretch">
          
          {/* LEFT RETRO SIDEBAR PANEL (Width: 3 cols) */}
          <div className="xl:col-span-3 bg-[#dcdcdc] border border-[#7f7f7f] p-2 flex flex-col justify-between gap-3 text-xs select-none">
            
            <div className="space-y-3">
              
              {/* Category 1: Numérisation Folder */}
              {(!forceMode || forceMode === 'scan') && (
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setActiveTab('num');
                      setCurrentSubView('inventaire');
                    }}
                    className={`w-full text-center py-1 font-bold tracking-tight rounded-xs border shadow-xs ${
                      activeTab === 'num'
                        ? "bg-[#6d6d6d] text-white border-black"
                        : "bg-[#cccccc] text-black border-white hover:bg-[#b5b5b5]"
                    }`}
                  >
                    📁 Category 1: Numérisation
                  </button>
                  
                  {activeTab === 'num' && (
                    <div className="bg-[#efefef] p-1.5 border border-[#7f7f7f] rounded-xs space-y-1.5 pl-3">
                      <button
                        onClick={() => setCurrentSubView('inventaire')}
                        className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                          currentSubView === 'inventaire' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                        }`}
                      >
                        📄 Inventaire du BEC
                      </button>
                      <button
                        onClick={() => setCurrentSubView('importer')}
                        className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                          currentSubView === 'importer' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                        }`}
                      >
                        📷 Importer Scan (Caméra)
                      </button>
                      <button
                        onClick={() => setCurrentSubView('controle-images')}
                        className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                          currentSubView === 'controle-images' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                        }`}
                      >
                        🔎 Contrôle d'Image
                      </button>
                      <button
                        onClick={() => setCurrentSubView('rejets-manques')}
                        className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                          currentSubView === 'rejets-manques' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                        }`}
                      >
                        ⚠️ Traitement Rejets/Manques
                      </button>
                      <button
                        onClick={() => setCurrentSubView('affectations')}
                        className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                          currentSubView === 'affectations' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                        }`}
                      >
                        👤 Connecter Agent Scan
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Category 2: Préparation Folder */}
              {(!forceMode || forceMode === 'controle_image' || forceMode === 'identification') && (
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setActiveTab('prep');
                      if (forceMode === 'controle_image') {
                        setCurrentSubView('controle-images');
                      } else {
                        setCurrentSubView('id-rc');
                      }
                    }}
                    className={`w-full text-center py-1 font-bold tracking-tight rounded-xs border shadow-xs ${
                      activeTab === 'prep'
                        ? "bg-[#6d6d6d] text-white border-black"
                        : "bg-[#cccccc] text-black border-white hover:bg-[#b5b5b5]"
                    }`}
                  >
                    📁 Category 2: Préparation
                  </button>
                  
                  {activeTab === 'prep' && (
                    <div className="bg-[#efefef] p-1.5 border border-[#7f7f7f] rounded-xs space-y-1.5 pl-3">
                      {(!forceMode || forceMode === 'controle_image') && (
                        <button
                          onClick={() => setCurrentSubView('controle-images')}
                          className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold flex items-center justify-between ${
                            currentSubView === 'controle-images' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                          }`}
                        >
                          <span>🔍 Controle Images</span>
                          {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) && (
                            <span className="w-2.5 h-2.5 bg-red-600 rounded-full animate-ping" />
                          )}
                        </button>
                      )}
                      {(!forceMode || forceMode === 'identification') && (
                        <>
                          <button
                            onClick={() => setCurrentSubView('id-rc')}
                            className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                              currentSubView === 'id-rc' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                            }`}
                          >
                            🏛️ Identification RC (Registre)
                          </button>
                          <button
                            onClick={() => setCurrentSubView('id-rp')}
                            className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                              currentSubView === 'id-rp' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                            }`}
                          >
                            📂 Identification RP (Pièces)
                          </button>
                          <button
                            onClick={() => setCurrentSubView('rejets-id')}
                            className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                              currentSubView === 'rejets-id' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                            }`}
                          >
                            ⚠️ Rejets Identification
                          </button>
                          <button
                            onClick={() => setCurrentSubView('acte-final')}
                            className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                              currentSubView === 'acte-final' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                            }`}
                          >
                            🖨️ Éditer Acte Final
                          </button>

                          <div className="pt-2 border-t border-stone-300 mt-2">
                            <button
                              onClick={handleDownloadJson}
                              className="w-full text-center py-2 px-2 border rounded-xs font-mono text-[10.5px] font-black bg-amber-600 hover:bg-amber-700 text-white flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                              title="Télécharger l'archive JSON des actes identifiés"
                            >
                              📥 Télécharger Actes (JSON)
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Category 3: Suivi Folder */}
              <div className="space-y-1">
                <button
                  onClick={() => {
                    setActiveTab('suivi');
                    setCurrentSubView('statistiques');
                  }}
                  className={`w-full text-center py-1 font-bold tracking-tight rounded-xs border shadow-xs ${
                    activeTab === 'suivi'
                      ? "bg-[#6d6d6d] text-white border-black"
                      : "bg-[#cccccc] text-black border-white hover:bg-[#b5b5b5]"
                  }`}
                >
                  📊 Category 3: Suivi & Stats
                </button>
                
                {activeTab === 'suivi' && (
                  <div className="bg-[#efefef] p-1.5 border border-[#7f7f7f] rounded-xs space-y-1.5 pl-3">
                    <button
                      onClick={() => setCurrentSubView('statistiques')}
                      className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                        currentSubView === 'statistiques' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                      }`}
                    >
                      📈 Statistiques Nationales
                    </button>
                    <button
                      onClick={() => setCurrentSubView('affectations-suivi')}
                      className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                        currentSubView === 'affectations-suivi' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                      }`}
                    >
                      👥 Gestion Affectations
                    </button>
                    <button
                      onClick={() => setCurrentSubView('utilisateurs')}
                      className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                        currentSubView === 'utilisateurs' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                      }`}
                    >
                      👤 Gestion Utilisateurs
                    </button>
                    <button
                      onClick={() => setCurrentSubView('pvs')}
                      className={`w-full text-left py-1 px-2 border rounded-xs font-mono text-[10.5px] font-bold ${
                        currentSubView === 'pvs' ? 'bg-[#0055e5] text-white' : 'bg-white text-stone-800'
                      }`}
                    >
                      📜 PVs d'Amendement
                    </button>
                  </div>
                )}
              </div>

            </div>

            {/* Quick Connected Info Block */}
            <div className="bg-white border border-[#7f7f7f] p-2 rounded-xs font-mono text-[10px] space-y-1 select-none">
              <div className="text-stone-600 font-bold">📡 ENVIRONNEMENT :</div>
              <div className="font-bold text-[#0055e5]">Circonscription Fès-Médina</div>
              <div className="text-green-700 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-600 rounded-full animate-ping" />
                Double Saisie : En cours
              </div>
            </div>

          </div>

          {/* MAIN SUB-VIEW WORKSPACE (9 cols) */}
          <div className="xl:col-span-9 bg-[#f0f0f0] border border-[#7f7f7f] p-3 flex flex-col justify-between gap-3 text-xs select-none">
            
            {/* RENDER ACTIVE DEKSTOP SUB-VIEW OR WINDOW */}
            <div className="flex-1">
              
              {/* VIEW 1: Inventaire du BEC */}
              {currentSubView === 'inventaire' && (
                <div className="space-y-3">
                  <div className="bg-white border border-[#7f7f7f] p-2 flex justify-between items-center font-bold font-mono">
                    <span>📚 INVENTAIRE DES REGISTRES ET CODES BEC ACTIVE</span>
                    <button 
                      onClick={() => setShowAddRegisterDialog(true)}
                      className="px-2 py-0.5 bg-[#cccccc] border border-white hover:bg-[#b2b2b2] text-[10px]"
                    >
                      ➕ Ajouter Registre
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-[#7f7f7f] text-left font-mono text-[10px]">
                      <thead>
                        <tr className="bg-[#cccccc] text-stone-900 border-b border-[#7f7f7f]">
                          <th className="p-1.5 border border-[#7f7f7f]">Lot Code</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Année</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Tome</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Total Actes</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Naissances</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Décès</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Mariages</th>
                          <th className="p-1.5 border border-[#7f7f7f]">État</th>
                          <th className="p-1.5 border border-[#7f7f7f]">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="bg-white hover:bg-[#efefef]">
                          <td className="p-1.5 border border-[#7f7f7f] font-bold">LOT-341-2026</td>
                          <td className="p-1.5 border border-[#7f7f7f]">1994</td>
                          <td className="p-1.5 border border-[#7f7f7f]">12</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center font-bold">34 491</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">24 110</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">8 920</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">1 461</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-green-700 font-bold">Mûr pour IA</td>
                          <td className="p-1.5 border border-[#7f7f7f]">
                            <button onClick={() => {setBecFilter("BEC-341"); setCurrentSubView("controle-images")}} className="bg-[#0055e5] text-white px-1.5 rounded-xs text-[9px]">Traiter</button>
                          </td>
                        </tr>
                        <tr className="bg-[#fcfcfc] hover:bg-[#efefef]">
                          <td className="p-1.5 border border-[#7f7f7f] font-bold">LOT-220-2026</td>
                          <td className="p-1.5 border border-[#7f7f7f]">2026</td>
                          <td className="p-1.5 border border-[#7f7f7f]">04</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center font-bold">12 400</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">7 301</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">4 010</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">1 089</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-green-700 font-bold">Mûr pour IA</td>
                          <td className="p-1.5 border border-[#7f7f7f]">
                            <button onClick={() => {setBecFilter("BEC-220"); setCurrentSubView("controle-images")}} className="bg-[#0055e5] text-white px-1.5 rounded-xs text-[9px]">Traiter</button>
                          </td>
                        </tr>
                        <tr className="bg-white hover:bg-[#efefef]">
                          <td className="p-1.5 border border-[#7f7f7f] font-bold">LOT-105-2026</td>
                          <td className="p-1.5 border border-[#7f7f7f]">2026</td>
                          <td className="p-1.5 border border-[#7f7f7f]">08</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center font-bold">18 950</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">11 200</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">5 801</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-center">1 949</td>
                          <td className="p-1.5 border border-[#7f7f7f] text-green-700 font-bold">Mûr pour IA</td>
                          <td className="p-1.5 border border-[#7f7f7f]">
                            <button onClick={() => {setBecFilter("BEC-105"); setCurrentSubView("controle-images")}} className="bg-[#0055e5] text-white px-1.5 rounded-xs text-[9px]">Traiter</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="bg-white p-2.5 border border-[#7f7f7f] space-y-1.5 font-mono text-[10px]">
                    <div className="font-bold text-[#ea580c]">⚡ SYNCHRONISATION REGISTRES ACTIFS :</div>
                    <p className="text-stone-600">
                      Les lots listés ci-dessus correspondent aux registres physiques d'actes de l'État Civil numérisés d'origine. Les codes BEC activés débloquent les formulaires correspondants.
                    </p>
                  </div>
                </div>
              )}

              {/* VIEW 2: Importer Scan */}
              {currentSubView === 'importer' && (
                <div className="space-y-2">
                  <div className="bg-white border border-[#7f7f7f] p-1 px-2 font-mono font-bold text-[#0055e5] flex justify-between items-center text-[11px]">
                    <span>📸 CAMERA ZENITHALE : ENREGISTREMENT ET CAPTURE DES ACTES D'ETAT CIVIL</span>
                    <span className="bg-green-700 text-white font-mono px-2 py-0.2 rounded-xs text-[9px]">ONLINE</span>
                  </div>
                  <ZenithalCamera 
                    scannedPages={scannedPages}
                    setScannedPages={setScannedPages}
                    onValidateStep1={() => {
                      setCurrentSubView('controle-images');
                    }}
                    isStep2Unlocked={true}
                    resetCounter={resetCounter}
                  />
                </div>
              )}

              {/* VIEW 3: Traitement Rejets/Manques */}
              {currentSubView === 'rejets-manques' && (
                <div className="space-y-3">
                  <div className="bg-red-900 text-white p-2 border border-black font-bold font-mono text-[11.5px] uppercase">
                    ⚠️ LISTE DES PAGES REJETÉES : CONTRÔLE D'IMAGE INTERROMPU
                  </div>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-[#7f7f7f] text-left font-mono text-[10px]">
                      <thead>
                        <tr className="bg-[#cccccc] text-stone-900">
                          <th className="p-1 border border-[#7f7f7f]">Code Page</th>
                          <th className="p-1 border border-[#7f7f7f]">Image Filename</th>
                          <th className="p-1 border border-[#7f7f7f]">BEC</th>
                          <th className="p-1 border border-[#7f7f7f]">Type Acte</th>
                          <th className="p-1 border border-[#7f7f7f]">Motif de l'anomalie</th>
                          <th className="p-1 border border-[#7f7f7f]">Arbitrage</th>
                        </tr>
                      </thead>
                      <tbody>
                        {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) ? (
                          scannedPages.map((p, idx) => {
                            if (p.isBlurred || p.isFoldedText || p.isStrikethrough) {
                              return (
                                <tr key={p.id} className="bg-red-50 text-red-900 font-bold">
                                  <td className="p-1 border border-[#7f7f7f]">{p.id}</td>
                                  <td className="p-1 border border-[#7f7f7f] text-stone-600 truncate">{p.filename}</td>
                                  <td className="p-1 border border-[#7f7f7f]">{p.numBEC}</td>
                                  <td className="p-1 border border-[#7f7f7f]">{p.typeActe}</td>
                                  <td className="p-1 border border-[#7f7f7f] text-red-700">
                                    {p.isBlurred ? "[Image floue] " : ""}
                                    {p.isFoldedText ? "[Twya - pliure] " : ""}
                                    {p.isStrikethrough ? "[Acte barré] " : ""}
                                  </td>
                                  <td className="p-1 border border-[#7f7f7f]">
                                    <button
                                      onClick={() => {
                                        setScannedPages(prev => prev.map((item, i) => i === idx ? { ...item, isBlurred: false, isFoldedText: false, isStrikethrough: false } : item));
                                      }}
                                      className="bg-green-700 hover:bg-green-800 text-white rounded-xs px-2 py-0.5"
                                    >
                                      Re-scanner
                                    </button>
                                  </td>
                                </tr>
                              );
                            }
                            return null;
                          })
                        ) : (
                          <tr>
                            <td colSpan={6} className="p-4 border border-[#7f7f7f] bg-white text-center text-stone-500 font-sans">
                              Aucune anomalie bloquante active sur le lot. Tout est conforme ! ✅
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-300 p-2 text-stone-800 space-y-1 font-sans">
                    <span className="font-bold">💡 Règle de conformité de l'État Civil :</span>
                    <p className="text-[10.5px]">
                      Si une pliure (Twya) ou un flou de bougé est détecté, l'opérateur de contrôle d'image refuse le scan et ordonne une nouvelle prise de photo zénithale de la page du registre.
                    </p>
                  </div>
                </div>
              )}

              {/* VIEW 4: Connecter Agent Scan */}
              {currentSubView === 'affectations' && (
                <div className="bg-white border border-[#7f7f7f] p-4 space-y-3 font-mono">
                  <div className="font-bold border-b border-stone-300 pb-1.5 uppercase">
                    👤 CONNECTER & AFFECTER DES AGENTS DE NUMÉRISATION
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-stone-500 font-bold mb-1">Agent Station Capture</label>
                      <input type="text" defaultValue="Ait Messaoud Rachid" className="w-full p-1.5 border border-stone-400 bg-[#fbfbfb]" />
                    </div>
                    <div>
                      <label className="block text-stone-500 font-bold mb-1">Adresse IP Station</label>
                      <input type="text" defaultValue="10.12.33.15" className="w-full p-1.5 border border-stone-400 bg-[#fbfbfb]" />
                    </div>
                  </div>
                  <div className="bg-stone-50 p-2.5 border border-[#7f7f7f] rounded-xs text-[10.5px] leading-relaxed">
                    Les scans déclenchés depuis l'appareil photo zénithal seront enregistrés sous la signature électronique de cet agent de saisie.
                  </div>
                </div>
              )}

              {/* VIEW 5: Controle Images (screenshot 6 layout replication) */}
              {currentSubView === 'controle-images' && (
                <div className="space-y-2">
                  
                  {/* Top bar filters */}
                  <div className="bg-white border border-[#7f7f7f] p-1.5 flex flex-wrap justify-between items-center text-[10.5px] font-mono gap-1">
                    <div className="flex items-center gap-1.5">
                      <span>BEC:</span>
                      <select 
                        value={becFilter} 
                        onChange={(e) => setBecFilter(e.target.value)}
                        className="p-0.5 border border-stone-400"
                        id="ctrlimg-bec-sel"
                      >
                        <option value="BEC-341">Fès Médina (BEC-341)</option>
                        <option value="BEC-220">Marrakech Gueliz (BEC-220)</option>
                        <option value="BEC-105">Rabat Agdal (BEC-105)</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-1">
                      <span>Type Acte :</span>
                      <select 
                        value={typeFilter} 
                        onChange={(e) => setTypeFilter(e.target.value)}
                        className="p-0.5 border border-stone-400"
                        id="ctrlimg-type-sel"
                      >
                        <option value="Naissance">Naissance (الولادة)</option>
                        <option value="Décès">Décès (الوفاة)</option>
                        <option value="Mariage">Mariage (الزواج)</option>
                        <option value="Divorce">Divorce (الطلاق)</option>
                      </select>
                    </div>

                    <div className="bg-stone-200 border border-stone-400 px-2 font-bold text-stone-700">
                      N° Acte : {page?.numActe || "N/A"}
                    </div>
                  </div>

                  {/* Main Screen layout block: Table on left, status center, image on right */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-1.5 items-stretch">
                    
                    {/* Left Column: List of Images (3 cols) */}
                    <div className="lg:col-span-3 bg-white border border-[#7f7f7f] p-1 flex flex-col justify-between h-[360px] select-none">
                      <div className="space-y-1 overflow-y-auto max-h-[310px]">
                        <div className="bg-[#cccccc] text-stone-900 p-0.5 font-bold font-mono text-[9px] text-center border-b border-[#7f7f7f]">
                          Filtres & Scans
                        </div>
                        {scannedPages.map((p, idx) => {
                          const hasIssue = p.isBlurred || p.isFoldedText || p.isStrikethrough;
                          return (
                            <button
                              key={p.id}
                              onClick={() => setSelectedPageIndex(idx)}
                              className={`w-full text-left p-1 text-[9.5px] font-mono border rounded-xs leading-tight truncate ${
                                selectedPageIndex === idx 
                                  ? 'bg-[#0055e5] text-white font-bold' 
                                  : hasIssue
                                    ? 'bg-red-50 border-red-500 text-red-900 font-bold animate-pulse'
                                    : 'bg-[#fcf8f2] text-stone-700 hover:bg-[#eaeaea]'
                              }`}
                              id={`imglist-btn-${idx}`}
                            >
                              ▶ {hasIssue ? "📷⚠️ [RE-SCAN] " : ""}{p.filename.substring(0, 16)}...
                              <span className="block text-[8px] opacity-75">
                                N° {p.numActe} ({p.typeActe}) {hasIssue ? "🚨 IMPERFECTION" : ""}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                      
                      <div className="bg-stone-100 border-t border-stone-400 p-1 text-center font-bold font-mono text-[9px]">
                        Tél. Actes: {scannedPages.length}
                      </div>
                    </div>

                    {/* Reworked Quality Options Panel (4 cols) */}
                    <div className="lg:col-span-4 bg-white border border-[#7f7f7f] p-2 flex flex-col justify-between h-[360px] font-mono text-[10px] select-none">
                      
                      {/* State and Led block */}
                      <div className="space-y-2">
                        <div className="bg-black text-green-500 font-mono p-1 text-center rounded-xs">
                          <span className="text-[10px] uppercase font-bold block">Compteur Digital Lot</span>
                          <span className="text-xl tracking-widest font-black block">000{selectedPageIndex + 1} / 60000</span>
                        </div>

                        {/* Rejection Buttons layout replicating screenshot 6 */}
                        <div className="border border-stone-250 p-1.5 rounded-xs space-y-1">
                          <span className="text-[9px] font-bold text-red-700 block uppercase border-b border-rose-100 pb-0.5">
                            🚨 Signaler rejets qualité :
                          </span>
                          
                          <label className="flex items-center gap-1.5 cursor-pointer py-0.5">
                            <input 
                              type="checkbox" 
                              checked={page?.isBlurred || false}
                              onChange={(e) => updatePage({ isBlurred: e.target.checked })}
                              className="accent-red-600Scale"
                            />
                            <span className="text-[#c80000] font-bold">Image floue</span>
                          </label>

                          <label className="flex items-center gap-1.5 cursor-pointer py-0.5">
                            <input 
                              type="checkbox" 
                              checked={page?.isFoldedText || false}
                              onChange={(e) => updatePage({ isFoldedText: e.target.checked })}
                            />
                            <span className="text-[#c80000] font-bold">Texte plié / Twya</span>
                          </label>

                          <label className="flex items-center gap-1.5 cursor-pointer py-0.5">
                            <input 
                              type="checkbox" 
                              checked={page?.isStrikethrough || false}
                              onChange={(e) => updatePage({ isStrikethrough: e.target.checked })}
                            />
                            <span className="text-stone-700">Acte annulé / barré</span>
                          </label>
                        </div>

                        {/* Validation Checkbox markers */}
                        <div className="border border-stone-250 p-1.5 rounded-xs space-y-1 bg-[#fcfbf9]">
                          <span className="text-[9px] font-bold text-green-700 block uppercase border-b border-stone-200 pb-0.5">
                            ✅ Valider Image :
                          </span>

                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={page?.isOpeningPage || false}
                              onChange={(e) => updatePage({ isOpeningPage: e.target.checked })}
                            />
                            <span>Pas de Page d'Ouverture</span>
                          </label>

                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={page?.isClosingPage || false}
                              onChange={(e) => updatePage({ isClosingPage: e.target.checked })}
                            />
                            <span>Pas de Page de Clôture</span>
                          </label>
                        </div>
                      </div>

                      {/* Decisive Actions Bottom Buttons of Screenshot 6 */}
                      <div className="space-y-1 font-sans">
                        <button
                          onClick={() => {
                            if (page) {
                              updatePage({ isBlurred: false, isFoldedText: false, isStrikethrough: false });
                            }
                          }}
                          className="w-full py-1.5 bg-[#4caf50] hover:bg-[#43a047] text-white font-bold border border-green-600 rounded-sm text-[10.5px] uppercase tracking-wide flex items-center justify-center gap-1"
                        >
                          Conforme & Valider ✔
                        </button>
                        
                        <button
                          onClick={() => {
                            if (page) {
                              updatePage({ isBlurred: true });
                            }
                          }}
                          className="w-full py-1 bg-[#f44336] hover:bg-[#e53935] text-white font-bold border border-red-650 rounded-sm text-[10px] uppercase flex items-center justify-center gap-1"
                        >
                          Ressaisir / Rejeter ✖
                        </button>
                      </div>

                    </div>

                    {/* Image canvas Viewport (5 cols) */}
                    <div className="lg:col-span-5 h-[360px] bg-white border border-[#7f7f7f] p-1.5 relative select-none">
                      <div className="absolute top-1 right-1 z-10 flex gap-1 text-[8px] font-mono">
                        <button onClick={handleRotation} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">ROT</button>
                        <button onClick={() => handleZoom(0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">+</button>
                        <button onClick={() => handleZoom(-0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">-</button>
                        <button onClick={toggleBinarized} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">N&B</button>
                        <button onClick={toggleDeskew} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">REDR</button>
                      </div>
                      
                      {renderDocumentView()}
                    </div>

                  </div>

                </div>
              )}

              {/* VIEW 6: Identification RC (Moroccan Central registry primary indexing layout) */}
              {currentSubView === 'id-rc' && (
                <div className="bg-white border border-[#7f7f7f] p-3 space-y-3 font-mono text-xs select-none animate-fade-in">
                  
                  <div className="bg-stone-200 p-1.5 border border-[#7f7f7f] font-bold text-[#0055e5] flex justify-between items-center text-[10.5px]">
                    <span>🏛️ CENTRAL INDEXATION DES REGISTRES (IDENTIFICATION RC)</span>
                    <span className="bg-[#0055e5] text-white px-2 py-0.2">INDEXATION EN DIRECT</span>
                  </div>

                  {page ? (
                    <div className="grid grid-cols-1 xl:grid-cols-12 gap-3 items-stretch">
                      
                      {/* Left Block (Form Inputs): 7 cols */}
                      <div className="xl:col-span-7 bg-white p-3 border border-stone-300 rounded-sm space-y-3 flex flex-col justify-between">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 leading-tight">
                          
                          {/* Sub-Left Column */}
                          <div className="space-y-2 border-r border-[#7f7f7f]/30 pr-3">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold col-span-1">Année d'Enregistrement</label>
                                <input 
                                  type="text" 
                                  value={page.anneeEnregistrement !== undefined ? page.anneeEnregistrement : (page.numTome === "12" ? "1994" : "2026")} 
                                  onChange={(e) => updatePage({ anneeEnregistrement: e.target.value })}
                                  className="w-full p-1 border border-stone-400 font-bold bg-white" 
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold">Type de Document</label>
                                <select 
                                  value={page.typeActe}
                                  onChange={(e) => updatePage({ typeActe: e.target.value as ActeType })}
                                  className="w-full p-1 border border-stone-400 font-bold"
                                >
                                  <option value="Naissance">Naissance (الولادة)</option>
                                  <option value="Décès">Décès (الوفاة)</option>
                                  <option value="Mariage">Mariage (الزواج)</option>
                                  <option value="Divorce">Divorce (الطلاق)</option>
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] text-stone-500 font-bold col-span-1">Nom Complet (Français)</label>
                              <input 
                                type="text" 
                                value={`${page.operatorA.prenom} ${page.operatorA.nom}`} 
                                className="w-full p-1 border border-stone-400 bg-white"
                                onChange={(e) => {
                                  const parts = e.target.value.split(' ');
                                  updatePage({
                                    operatorA: {
                                      ...page.operatorA,
                                      prenom: parts[0] || "",
                                      nom: parts[1] || ""
                                    }
                                  });
                                }}
                              />
                            </div>

                            <div className="text-right">
                              <label className="block text-[10px] text-stone-500 font-bold text-right" dir="rtl">الاسم العائلي والشخصي بالعربية</label>
                              <input 
                                type="text" 
                                dir="rtl"
                                value={page.operatorA.prenomAr ? `${page.operatorA.prenomAr} ${page.operatorA.nomAr}` : "فاطمة خلوى"} 
                                className="w-full p-1 border border-stone-400 bg-white text-right font-display text-xs" 
                                onChange={(e) => {
                                  const parts = e.target.value.split(' ');
                                  updatePage({
                                    operatorA: {
                                      ...page.operatorA,
                                      prenomAr: parts[0] || "",
                                      nomAr: parts[1] || ""
                                    }
                                  });
                                }}
                              />
                            </div>
                          </div>

                          {/* Sub-Right Column */}
                          <div className="space-y-2">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold">N° d'Acte d'origine</label>
                                <input 
                                  type="text" 
                                  value={page.numActe} 
                                  onChange={(e) => updatePage({ numActe: e.target.value })}
                                  className="w-full p-1 border border-stone-400 font-bold" 
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold">État de l'acte (Dropdown)</label>
                                <select className="w-full p-1 border border-stone-400">
                                  <option value="Normal">Normal (عادي)</option>
                                  <option value="SansN">Acte sans N°</option>
                                  <option value="VideN">Acte vide avec N°</option>
                                  <option value="Annule">Acte Annulé/barré</option>
                                  <option value="Collectif">Acte collectif (jugement)</option>
                                  <option value="Incomplet">Incomplet (غير كامل)</option>
                                </select>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold">Date Grégorienne</label>
                                <input 
                                  type="text" 
                                  value={page.operatorA.dateGregoirienne} 
                                  onChange={(e) => updatePage({
                                    operatorA: { ...page.operatorA, dateGregoirienne: e.target.value }
                                  })}
                                  className="w-full p-1 border border-stone-400" 
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-stone-500 font-bold">Date Hégirienne</label>
                                <input 
                                  type="text" 
                                  value={page.operatorA.dateHegirienne} 
                                  onChange={(e) => updatePage({
                                    operatorA: { ...page.operatorA, dateHegirienne: e.target.value }
                                  })}
                                  className="w-full p-1 border border-stone-400" 
                                />
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] text-stone-500 font-bold">Déclaration (Dropdown)</label>
                              <select className="w-full p-1 border border-stone-400">
                                <option value="Directe">Directe (تصريح مباشر)</option>
                                <option value="Jugement">Jugement (حكم قضائي)</option>
                                <option value="Transcription">Transcription (نقل رسمي)</option>
                              </select>
                            </div>
                          </div>

                        </div>

                        <div className="bg-[#f2f4fb] p-2 border border-stone-300 text-[10px] leading-relaxed mt-4">
                          ⚙️ <strong>Index d'identification de l'État :</strong> Le croisement des dates permet l'encodage correct dans la base centrale.
                        </div>
                      </div>

                      {/* Right Block (Image Preview Canvas): 5 cols */}
                      <div className="xl:col-span-5 h-[410px] bg-white border border-[#7f7f7f] p-1.5 relative select-none">
                        <div className="absolute top-1 right-1 z-10 flex gap-1 text-[8px] font-mono">
                          <button onClick={handleRotation} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">ROT</button>
                          <button onClick={() => handleZoom(0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">+</button>
                          <button onClick={() => handleZoom(-0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">-</button>
                          <button onClick={toggleBinarized} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">N&B</button>
                          <button onClick={toggleDeskew} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">REDR</button>
                        </div>
                        {renderDocumentView()}
                      </div>

                    </div>
                  ) : (
                    <p className="text-stone-400 text-center">Aucune page active</p>
                  )}

                </div>
              )}

              {/* VIEW 7: Identification RP (attached documents) */}
              {currentSubView === 'id-rp' && (
                <div className="bg-white border border-[#7f7f7f] p-3 space-y-3 font-mono text-xs select-none animate-fade-in">
                  
                  <div className="bg-stone-200 p-1 px-2 font-bold text-[#0055e5] border border-[#7f7f7f] flex justify-between items-center text-[10.5px]">
                    <span>📂 IDENTIFICATION COMPLÉMENTAIRE (RP - DOCUMENTS ATTACHÉS)</span>
                    <span className="text-[9.5px]">N° ACTE ASSOCIE : {page?.numActe}</span>
                  </div>

                  {page ? (
                    <div className="grid grid-cols-1 xl:grid-cols-12 gap-3 items-stretch">
                      
                      {/* Left Block (Table & Sections): 7 cols */}
                      <div className="xl:col-span-7 bg-white p-3 border border-stone-300 rounded-sm space-y-4">
                        <p className="text-stone-500 text-[10.5px]">
                          Veuillez déclarer et valider les pièces jointes d'accompagnement légal (par exemple : jugements rectificatifs, attestations médicales, autorisations de mariage d'adouls) :
                        </p>

                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse border border-[#7f7f7f] text-left text-[10px]">
                            <thead>
                              <tr className="bg-[#cccccc] text-stone-900 border-b border-[#7f7f7f]">
                                <th className="p-1 border border-[#7f7f7f]">Type de Pièce Jointe</th>
                                <th className="p-1 border border-[#7f7f7f]">Référence Pièce</th>
                                <th className="p-1 border border-[#7f7f7f]">Date Délivrance</th>
                                <th className="p-1 border border-[#7f7f7f]">Autorité Émettrice</th>
                              </tr>
                            </thead>
                            <tbody>
                              {page.piecesJointes && page.piecesJointes.length > 0 ? (
                                page.piecesJointes.map(pj => (
                                  <tr key={pj.id} className="hover:bg-stone-50">
                                    <td className="p-1.5 border border-[#7f7f7f] font-bold">{pj.typePiece}</td>
                                    <td className="p-1.5 border border-[#7f7f7f] font-mono">{pj.reference}</td>
                                    <td className="p-1.5 border border-[#7f7f7f] font-mono">{pj.dateDelivrance}</td>
                                    <td className="p-1.5 border border-[#7f7f7f] text-stone-600">{pj.autoriteEmettrice}</td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan={4} className="p-4 text-center border border-[#7f7f7f] text-stone-400 bg-stone-50/30">
                                    Aucun justificatif de tribunal requis pour cet acte normal d'État Civil.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>

                        <div className="bg-stone-50 p-2 border border-stone-300">
                          <span className="font-bold text-[#ea580c] block text-[9.5px]">📝 SECTION AJOUTS PIECES COMPLEMENTAIRES :</span>
                          <p className="text-[10px] text-stone-600 mt-1">
                            Les pièces saisies dans l'onglet RP de la phase "Préparation" sont automatiquement cataloguées sous le lot pour relecture par le superviseur.
                          </p>
                        </div>
                      </div>

                      {/* Right Block (Image Preview Canvas): 5 cols */}
                      <div className="xl:col-span-5 h-[410px] bg-white border border-[#7f7f7f] p-1.5 relative select-none">
                        <div className="absolute top-1 right-1 z-10 flex gap-1 text-[8px] font-mono">
                          <button onClick={handleRotation} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">ROT</button>
                          <button onClick={() => handleZoom(0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">+</button>
                          <button onClick={() => handleZoom(-0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">-</button>
                          <button onClick={toggleBinarized} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">N&B</button>
                          <button onClick={toggleDeskew} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">REDR</button>
                        </div>
                        {renderDocumentView()}
                      </div>

                    </div>
                  ) : (
                    <p className="text-stone-400 text-center">Aucune page active</p>
                  )}

                </div>
              )}

              {/* VIEW 8: Rejets Identification */}
              {currentSubView === 'rejets-id' && (
                <div className="bg-white border border-[#7f7f7f] p-4 text-center text-stone-600 py-8 font-mono space-y-2 select-none">
                  <ShieldAlert className="w-12 h-12 text-[#ea580c] mx-auto" />
                  <h4 className="font-bold text-stone-800 uppercase">Traitement des Rejets d'Identification (Vierge)</h4>
                  <p className="max-w-md mx-auto text-[11px]">
                    Aucune page indexée n'a été rejetée par le service d'état civil national pour le moment. Toutes les données RC/RP concordent avec le lot scanné.
                  </p>
                </div>
              )}

              {/* VIEW 9: Editer Acte Final */}
              {currentSubView === 'acte-final' && (
                <div className="bg-white border border-[#7f7f7f] p-4 font-mono select-none space-y-4 animate-fade-in">
                  <div className="bg-[#cccccc] text-stone-900 border-b border-[#7f7f7f] p-1 font-bold text-[11px] uppercase">
                    🖨️ APERÇU ET EDITION POUR EXTRACTION DE L'ACTE FINAL CONFORME
                  </div>
                  
                  {page ? (
                    <div className="grid grid-cols-1 xl:grid-cols-12 gap-3 items-stretch">
                      
                      {/* Left Block (Acte Final): 7 cols */}
                      <div className="xl:col-span-7 bg-white p-3 border border-stone-300 rounded-sm space-y-3">
                        <div className="border border-[#7f7f7f] p-4 bg-amber-50/5 text-stone-800 rounded-sm space-y-4 font-serif text-sm">
                          <div className="text-center font-bold border-b pb-2">
                            <span className="block text-xs uppercase font-sans tracking-wide">Royaume du Maroc</span>
                            <span className="block text-sm">وزارة الداخلية - جماعة فاس الكبرى</span>
                            <span className="block text-base text-amber-900 mt-1">نسخة موجزة من رسم {page.typeActe === "Naissance" ? "الولادة" : page.typeActe}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                            <div className="space-y-1">
                              <div><strong>N° Acte :</strong> {page.numActe}</div>
                              <div><strong>BEC :</strong> {page.numBEC} - Fès Medina</div>
                              <div><strong>Nom Complet :</strong> {page.operatorA.prenom} {page.operatorA.nom}</div>
                              <div><strong>Date de Naissance :</strong> {page.operatorA.dateGregoirienne} ({page.operatorA.dateHegirienne})</div>
                            </div>
                            <div className="space-y-1 text-right" dir="rtl">
                              <div className="font-display"><strong>رقم الرسم :</strong> {page.numActe}</div>
                              <div className="font-display"><strong>مكتب ع ج :</strong> فاس المدينة</div>
                              <div className="font-display"><strong>الاسم الكامل :</strong> {page.operatorA.prenomAr} {page.operatorA.nomAr}</div>
                              <div className="font-display"><strong>تاريخ الولادة :</strong> {page.operatorA.dateGregoirienne} هجرية ({page.operatorA.dateHegirienne})</div>
                            </div>
                          </div>

                          <div className="border-t pt-2 font-sans text-[10px] text-stone-500 text-center">
                            Ce justificatif est conforme aux données encodées lors de la phase de Préparation.
                          </div>
                        </div>
                      </div>

                      {/* Right Block (Image Preview Canvas): 5 cols */}
                      <div className="xl:col-span-5 h-[410px] bg-white border border-[#7f7f7f] p-1.5 relative select-none">
                        <div className="absolute top-1 right-1 z-10 flex gap-1 text-[8px] font-mono">
                          <button onClick={handleRotation} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">ROT</button>
                          <button onClick={() => handleZoom(0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">+</button>
                          <button onClick={() => handleZoom(-0.1)} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">-</button>
                          <button onClick={toggleBinarized} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">N&B</button>
                          <button onClick={toggleDeskew} className="bg-stone-200 p-1 border border-stone-400 hover:bg-stone-300">REDR</button>
                        </div>
                        {renderDocumentView()}
                      </div>

                    </div>
                  ) : (
                    <p className="text-stone-400 text-center">Aucune page active</p>
                  )}

                </div>
              )}

              {/* VIEW 10: Statistiques */}
              {currentSubView === 'statistiques' && (
                <div className="space-y-3 font-mono">
                  <div className="bg-white border border-[#7f7f7f] p-1.5 font-bold text-[#0055e5]">
                    📈 TABLEAU DE BORD DE SUIVI DE LA ZONE NUMÉRISATION FÈS
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-2 leading-tight">
                    <div className="bg-white border border-[#7f7f7f] p-2 text-center text-xs">
                      <span className="text-stone-400 font-bold block uppercase text-[9px]">Total Indexés</span>
                      <strong className="text-lg text-[#0055e5] font-black tracking-normal">34 491</strong>
                    </div>
                    <div className="bg-white border border-[#7f7f7f] p-2 text-center text-xs">
                      <span className="text-stone-400 font-bold block uppercase text-[9px]">Taux de Rejets Image</span>
                      <strong className="text-lg text-amber-700 font-black">0,24 %</strong>
                    </div>
                    <div className="bg-white border border-[#7f7f7f] p-2 text-center text-xs">
                      <span className="text-stone-400 font-bold block uppercase text-[9px]">Anomalies (Twya)</span>
                      <strong className="text-lg text-red-700 font-black">15 cas</strong>
                    </div>
                    <div className="bg-white border border-[#7f7f7f] p-2 text-center text-xs">
                      <span className="text-stone-400 font-bold block uppercase text-[9px]">Stations Actives</span>
                      <strong className="text-lg text-green-700 font-black">12</strong>
                    </div>
                  </div>

                  {/* High quality statistics table */}
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-[#7f7f7f] text-left text-[9.5px]">
                      <thead>
                        <tr className="bg-[#cccccc]">
                          <th className="p-1 border border-[#7f7f7f]">Date opération</th>
                          <th className="p-1 border border-[#7f7f7f]">Station</th>
                          <th className="p-1 border border-[#7f7f7f]">Scannés</th>
                          <th className="p-1 border border-[#7f7f7f]">Validés</th>
                          <th className="p-1 border border-[#7f7f7f]">Anomalie Qualité</th>
                          <th className="p-1 border border-[#7f7f7f]">Rapport final</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="bg-white">
                          <td className="p-1 border border-[#7f7f7f]">23/06/2026</td>
                          <td className="p-1 border border-[#7f7f7f]">STAT-01 (Zénithale)</td>
                          <td className="p-1 border border-[#7f7f7f] text-center font-bold">1 240</td>
                          <td className="p-1 border border-[#7f7f7f] text-center text-green-700 font-bold">1 235</td>
                          <td className="p-1 border border-[#7f7f7f] text-center text-red-600">5 cas flous</td>
                          <td className="p-1 border border-[#7f7f7f] text-stone-500">Lot de Fès conforme</td>
                        </tr>
                        <tr className="bg-stone-50/40">
                          <td className="p-1 border border-[#7f7f7f]">22/06/2026</td>
                          <td className="p-1 border border-[#7f7f7f]">STAT-02 (Scanner plat)</td>
                          <td className="p-1 border border-[#7f7f7f] text-center font-bold">980</td>
                          <td className="p-1 border border-[#7f7f7f] text-center text-green-700 font-bold">965</td>
                          <td className="p-1 border border-[#7f7f7f] text-center text-red-600">15 cas Twya</td>
                          <td className="p-1 border border-[#7f7f7f] text-stone-500">Pliures détectées & redressées</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* VIEW 11: Other non-implemented pages view default fallback */}
              {!['inventaire', 'importer', 'rejets-manques', 'affectations', 'controle-images', 'id-rc', 'id-rp', 'rejets-id', 'acte-final', 'statistiques'].includes(currentSubView) && (
                <div className="bg-white border border-[#7f7f7f] p-4 text-stone-500 text-center py-10 font-mono">
                  🔎 Onglet non configuré pour ce lot spécifique.
                </div>
              )}

            </div>

            {/* 🔟 PAGINATION DE PASSAGE DE PAGE DE 1 A 10 TOUT DANS LE BAS */}
            {(currentSubView === 'controle-images' || currentSubView === 'id-rc' || currentSubView === 'id-rp' || currentSubView === 'acte-final') && (
              <div className="bg-white p-2.5 border border-[#7f7f7f] flex flex-col md:flex-row justify-between items-center gap-3 select-none font-sans mt-2">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-stone-600">
                  <span className="w-2 h-2 bg-blue-700 rounded-full animate-pulse" />
                  <span>Feuillets numérisés du Registre : Feuillet {selectedPageIndex + 1} / {scannedPages.length}</span>
                </div>

                {/* List of 10 pages selection buttons */}
                <div className="flex flex-wrap gap-1 items-center justify-center">
                  <button
                    type="button"
                    onClick={() => setSelectedPageIndex(prev => Math.max(0, prev - 1))}
                    disabled={selectedPageIndex === 0}
                    className="p-1 px-2.5 bg-stone-100 hover:bg-stone-200 border border-stone-400 rounded-xs disabled:opacity-40 text-[10px] font-bold flex items-center gap-0.5 text-stone-700"
                    id="feuillets-prev-btn"
                  >
                    ◀ Préc.
                  </button>

                  {scannedPages.map((p, idx) => {
                    const hasIssue = p.isBlurred || p.isFoldedText;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setSelectedPageIndex(idx)}
                        className={`w-7 h-6 rounded-xs text-[10px] font-bold transition-all border flex items-center justify-center gap-0.5 ${
                          selectedPageIndex === idx
                            ? "bg-[#0055e5] text-white border-blue-800 scale-105 font-black"
                            : hasIssue
                              ? "bg-red-50 text-red-700 border-red-500 hover:bg-red-100 animate-pulse font-extrabold"
                              : "bg-white text-stone-600 border-stone-300 hover:bg-stone-100"
                        }`}
                        id={`feuillets-btn-${idx}`}
                        title={hasIssue ? "Re-scan Requis ⚠️" : ""}
                      >
                        {idx + 1}{hasIssue ? "⚠️" : ""}
                      </button>
                    );
                  })}

                  <button
                    type="button"
                    onClick={() => setSelectedPageIndex(prev => Math.min(scannedPages.length - 1, prev + 1))}
                    disabled={selectedPageIndex === scannedPages.length - 1}
                    className="p-1 px-2.5 bg-stone-100 hover:bg-stone-200 border border-stone-400 rounded-xs disabled:opacity-40 text-[10px] font-bold flex items-center gap-0.5 text-stone-700"
                    id="feuillets-next-btn"
                  >
                    Suiv. ▶
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Outer control panel bottom: Proceed next step */}
        <div className="mt-2.5 p-2 bg-[#dcdcdc] border border-[#7f7f7f] flex flex-col sm:flex-row justify-between items-center gap-2 select-none text-xs">
          
          <div className="flex items-center gap-1.5 text-[#0055e5] font-mono font-bold text-[10.5px]">
            {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) ? (
              <span className="text-red-750 flex items-center gap-1 animate-pulse">
                ⚠️ [ PAGE BLOQUÉE : RÉSOUDRE LES ANOMALIES DE PLIURE/FLOU SIGNALÉES DANS L'ONGLET REJETS ]
              </span>
            ) : (
              <span className="text-green-800 flex items-center gap-1.5">
                🌟 TOUS LES INDEX SONT SAISIS ET LES SCANS SONT APICULÉS ET CONFORMES !
              </span>
            )}
          </div>

          <div className="flex gap-2 font-mono">
            {scannedPages.some(p => p.isBlurred || p.isFoldedText || p.isStrikethrough) && (
              <button
                onClick={() => {
                  setScannedPages(prev => prev.map(p => ({
                    ...p,
                    isBlurred: false,
                    isFoldedText: false,
                    isStrikethrough: false
                  })));
                }}
                className="px-3 py-1 bg-green-700 text-white font-bold border border-green-800 hover:bg-green-800 rounded-xs text-[10.5px]"
              >
                ⚡ Tout Conformer d'un clic
              </button>
            )}

            {forceMode === 'identification' && (
              <button
                onClick={handleDownloadJson}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold border border-amber-800 shadow-sm rounded-xs text-[11px] uppercase tracking-wide flex items-center gap-1 cursor-pointer"
              >
                📥 Télécharger Fichier JSON des Actes
              </button>
            )}

            <button
              onClick={onValidatePreparation}
              className="px-5 py-1.5 font-bold border rounded-xs shadow-xs text-[11px] uppercase tracking-wide flex items-center gap-1 bg-[#0055e5] text-white border-blue-900 shadow-sm cursor-pointer hover:bg-blue-800"
              id="btn-validate-prep-stage"
            >
              {forceMode === 'scan' ? "Terminer la Capture & Passer au Contrôle d'Image ➡️" :
               forceMode === 'controle_image' ? "Valider le Contrôle & Analyser les Rejets ➡️" :
               forceMode === 'identification' ? "Valider l'Identification & Passer au Moteur IA ➡️" :
               "Passer à l'Étape Suivante ➡️"}
            </button>
          </div>

        </div>

      </div>

      {/* Retro Add Register Dialog Modal */}
      {showAddRegisterDialog && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#eaeaea] border-2 border-stone-400 p-2 rounded-xs max-w-sm w-full shadow-2xl font-mono text-xs">
            <div className="bg-[#0055e5] text-white px-2 py-1 flex justify-between items-center font-bold text-[11px]">
              <span>📁 Ajouter un Nouveau Registre</span>
              <button 
                onClick={() => setShowAddRegisterDialog(false)}
                className="w-4 h-4 bg-red-600 text-white flex items-center justify-center text-[9px] font-bold border"
              >
                X
              </button>
            </div>

            <div className="p-3 bg-[#dcdcdc] space-y-3">
              <div>
                <label className="block text-[10px] text-stone-500 font-bold mb-1">Code Bureau d'État Civil (BEC)</label>
                <input 
                  type="text" 
                  value={newRegisterBEC} 
                  onChange={(e) => setNewRegisterBEC(e.target.value)}
                  className="w-full p-1 border bg-white text-stone-800" 
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-stone-500 font-bold mb-1">Année</label>
                  <input 
                    type="text" 
                    value={newRegisterYear} 
                    onChange={(e) => setNewRegisterYear(e.target.value)}
                    className="w-full p-1 border bg-white" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-stone-500 font-bold mb-1">Type d'actes</label>
                  <select 
                    value={newRegisterType} 
                    onChange={(e) => setNewRegisterType(e.target.value)}
                    className="w-full p-1.5 border bg-white"
                  >
                    <option value="Naissance">Naissance (الولادة)</option>
                    <option value="Décès">Décès (الوفاة)</option>
                    <option value="Mariage">Mariage (الزواج)</option>
                    <option value="Divorce">Divorce (الطلاق)</option>
                  </select>
                </div>
              </div>

              <div className="bg-white p-2 border border-stone-300 text-[10px] leading-tight text-stone-500">
                L'arborescence du BEC `/bec/registres/{newRegisterYear}/{newRegisterBEC}/` sera de suite synchronisée.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowAddRegisterDialog(false)}
                  className="px-3 py-1 bg-[#cccccc] border text-black hover:bg-stone-300 text-[10.5px]"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    // Create simulated page for the new register
                    const samplePage: PageScan = {
                      id: `SCAN-${newRegisterYear}-NEW001`,
                      imageIndex: 0,
                      filename: `REG_${newRegisterBEC}_TOME01_ACTE_NEW_1.jpg`,
                      status: 'Brut',
                      captureTime: new Date().toLocaleDateString('fr-FR') + " " + new Date().toLocaleTimeString('fr-FR'),
                      rotation: 0,
                      zoom: 1,
                      deskew: true,
                      binarized: false,
                      typeActe: newRegisterType as ActeType,
                      numBEC: newRegisterBEC,
                      numTome: "01",
                      numActe: "1",
                      isOpeningPage: true,
                      isClosingPage: false,
                      isBlurred: false,
                      isFoldedText: false,
                      isStrikethrough: false,
                      partsCount: 1,
                      isActeBis: false,
                      marginalMentionsCount: 0,
                      statutDeclarative: "Nouveau registre d'État Civil",
                      declarationDetails: "Nouveau",
                      piecesJointes: [],
                      operatorA: {
                        prenom: "Nouveau",
                        nom: "Acte",
                        prenomAr: "جديد",
                        nomAr: "رسم",
                        dateGregoirienne: "01/01/" + newRegisterYear,
                        dateHegirienne: "01/01/1447",
                        perePrenom: "Mehdi",
                        merePrenom: "Halima",
                        numActe: "1",
                        typeActe: newRegisterType as ActeType
                      },
                      operatorB: {
                        prenom: "Nouveau",
                        nom: "Acte",
                        prenomAr: "جديد",
                        nomAr: "رسم",
                        dateGregoirienne: "01/01/" + newRegisterYear,
                        dateHegirienne: "01/01/1447",
                        perePrenom: "Mehdi",
                        merePrenom: "Halima",
                        numActe: "1",
                        typeActe: newRegisterType as ActeType
                      },
                      isConflictResolved: false
                    };
                    setScannedPages(prev => [samplePage, ...prev]);
                    setShowAddRegisterDialog(false);
                  }}
                  className="px-4 py-1 bg-[#0055e5] text-white font-bold hover:bg-blue-800 text-[10.5px]"
                >
                  Créer Dossier 📁
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
