import React, { useState, useEffect } from 'react';
import { PageScan } from '../types';
import { 
  Camera, AlertTriangle, CheckCircle, RefreshCw, Eye, ArrowRight, 
  ShieldAlert, Upload, Check, RefreshCcw, ShieldCheck, Sliders, CheckSquare, XCircle
} from 'lucide-react';

interface RescanCorrectWorkspaceProps {
  scannedPages: PageScan[];
  setScannedPages: React.Dispatch<React.SetStateAction<PageScan[]>>;
  onValidate: () => void;
}

export default function RescanCorrectWorkspace({
  scannedPages,
  setScannedPages,
  onValidate
}: RescanCorrectWorkspaceProps) {
  // Get all pages that have active issues OR were recently rescanned in this workspace
  const problematicPages = scannedPages.filter(p => 
    p.isBlurred || p.isFoldedText || p.isStrikethrough || p.wasRescanned
  );

  // Default selected ID to the first bad or newly rescanned page
  const [selectedId, setSelectedId] = useState<string>(() => {
    return problematicPages[0]?.id || "";
  });

  // Ensure selectedId is valid if problematicPages list changes
  useEffect(() => {
    if (problematicPages.length > 0 && !problematicPages.some(p => p.id === selectedId)) {
      setSelectedId(problematicPages[0].id);
    }
  }, [scannedPages]);

  const [isShutterFlashing, setIsShutterFlashing] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Quality control sliders for mock realism
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [sharpness, setSharpness] = useState<number>(100);

  // Mock checklist state for post-rescan image control
  const [checklistNettete, setChecklistNettete] = useState(false);
  const [checklistCadrage, setChecklistCadrage] = useState(false);
  const [checklistLisibilite, setChecklistLisibilite] = useState(false);

  const selectedPage = scannedPages.find(p => p.id === selectedId) || problematicPages[0] || null;
  const selectedIdx = scannedPages.findIndex(p => p.id === (selectedPage?.id || ""));

  // Reset checkmarks when page selection changes
  useEffect(() => {
    setChecklistNettete(selectedPage?.isRescanApproved || false);
    setChecklistCadrage(selectedPage?.isRescanApproved || false);
    setChecklistLisibilite(selectedPage?.isRescanApproved || false);
    setBrightness(100);
    setContrast(100);
    setSharpness(100);
  }, [selectedId]);

  const hasIssues = (p: PageScan) => p.isBlurred || p.isFoldedText || p.isStrikethrough;

  // Remaining pages with active physical anomalies (not yet rescanned)
  const rejectedCount = scannedPages.filter(hasIssues).length;

  // Pages that are rescanned but pending final image control approval
  const pendingApprovalCount = scannedPages.filter(p => p.wasRescanned && !p.isRescanApproved).length;

  const handleSimulateCapture = () => {
    if (!selectedPage || selectedIdx === -1) return;
    setIsShutterFlashing(true);
    
    setTimeout(() => {
      setIsShutterFlashing(false);
      
      const updatedPages = [...scannedPages];
      updatedPages[selectedIdx] = {
        ...selectedPage,
        isBlurred: false,
        isFoldedText: false,
        isStrikethrough: false,
        wasRescanned: true,
        isRescanApproved: false, // Must be approved by image control
        customPreview: selectedPage.customPreview || "https://images.unsplash.com/photo-1586075010923-2dd4570fb338?w=800&auto=format&fit=crop&q=80"
      };
      
      setScannedPages(updatedPages);
      setSuccessToast(`L'acte N° ${selectedPage.numActe} a été re-numérisé ! Effectuez maintenant le contrôle de l'image. 🔎`);
      setTimeout(() => setSuccessToast(null), 4000);
    }, 600);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0] && selectedPage && selectedIdx !== -1) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        const updatedPages = [...scannedPages];
        updatedPages[selectedIdx] = {
          ...selectedPage,
          isBlurred: false,
          isFoldedText: false,
          isStrikethrough: false,
          wasRescanned: true,
          isRescanApproved: false,
          customPreview: result
        };
        setScannedPages(updatedPages);
        setSuccessToast(`Fichier correctif importé pour l'acte N° ${selectedPage.numActe} ! Passez au contrôle de l'image. 🔎`);
        setTimeout(() => setSuccessToast(null), 4000);
      };
      reader.readAsDataURL(files[0]);
    }
  };

  // Approve rescan image quality
  const handleApproveRescan = () => {
    if (!selectedPage || selectedIdx === -1) return;
    
    const updatedPages = [...scannedPages];
    updatedPages[selectedIdx] = {
      ...selectedPage,
      isRescanApproved: true
    };
    
    setScannedPages(updatedPages);
    setSuccessToast(`Conformité d'image approuvée pour l'acte N° ${selectedPage.numActe} ! ✅`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  // Reject the corrected image and force a new capture
  const handleRejectRescan = () => {
    if (!selectedPage || selectedIdx === -1) return;
    
    const updatedPages = [...scannedPages];
    updatedPages[selectedIdx] = {
      ...selectedPage,
      isBlurred: true, // Mark bad again
      wasRescanned: false,
      isRescanApproved: false
    };
    
    setScannedPages(updatedPages);
    setChecklistNettete(false);
    setChecklistCadrage(false);
    setChecklistLisibilite(false);
    setSuccessToast(`Image désapprouvée. L'acte N° ${selectedPage.numActe} est renvoyé en attente de capture. ↩️`);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="rescan-correct-targeted-workspace">
      {/* Toast Alert Success */}
      {successToast && (
        <div className="fixed top-4 right-4 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2 border border-emerald-500 animate-bounce text-xs font-bold">
          <CheckCircle className="w-5 h-5 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Retro Title Bar Info */}
      <div className="bg-gradient-to-r from-stone-900 to-stone-850 p-6 rounded-3xl text-white shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-stone-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-rose-400 text-xs font-mono font-bold uppercase tracking-wider px-2 py-0.5 bg-rose-950/50 rounded-md border border-rose-900/40">
              Étape 2 • Rescan Ciblé & Contrôle d'Image
            </span>
          </div>
          <h3 className="font-display font-black text-lg text-rose-400 mt-1">
            Atelier Correctif & Contrôle Qualité Post-Rescan
          </h3>
          <p className="text-xs text-stone-300 max-w-xl font-medium leading-relaxed">
            Seuls les actes signalés comme défectueux (flous, pliés ou barrés) sont traités ici. Re-scannez puis effectuez le <span className="text-emerald-400 font-bold">contrôle d'image individuel</span> de chaque acte avant de passer à l'identification légale.
          </p>
        </div>

        {/* Dynamic Badges Block */}
        <div className="flex gap-3 shrink-0">
          <div className="bg-stone-800 border border-stone-700 px-4 py-2.5 rounded-2xl text-center">
            <div className="text-[9px] text-stone-400 uppercase font-mono tracking-wider font-bold">Attente Re-Scan</div>
            <div className={`text-lg font-black font-mono ${rejectedCount > 0 ? 'text-red-500 animate-pulse' : 'text-emerald-500'}`}>
              {rejectedCount} Acte(s)
            </div>
          </div>
          <div className="bg-stone-800 border border-stone-700 px-4 py-2.5 rounded-2xl text-center">
            <div className="text-[9px] text-stone-400 uppercase font-mono tracking-wider font-bold">Attente Contrôle d'Image</div>
            <div className={`text-lg font-black font-mono ${pendingApprovalCount > 0 ? 'text-amber-500' : 'text-emerald-500'}`}>
              {pendingApprovalCount} Acte(s)
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Column: List of Only Affected Acts (No all acts) */}
        <div className="lg:col-span-4 bg-white border border-stone-200 p-4 rounded-3xl space-y-3 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-black text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-150 mb-3 flex items-center justify-between">
              <span>Actes Défectueux Signalés</span>
              <span className="text-[10px] text-red-600 bg-red-50 px-2 py-0.5 rounded-full font-mono font-bold border border-red-100">
                {problematicPages.length} à corriger
              </span>
            </h4>

            {problematicPages.length === 0 ? (
              <div className="p-8 text-center bg-emerald-50/50 border border-emerald-100 rounded-2xl space-y-2 select-none">
                <CheckSquare className="w-10 h-10 text-emerald-600 mx-auto" />
                <h5 className="text-xs font-bold text-emerald-900">Aucun acte à corriger</h5>
                <p className="text-[10px] text-emerald-700 leading-relaxed">
                  Le lot ne contient aucune anomalie physique. Vous pouvez continuer vers l'étape d'identification.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
                {problematicPages.map((page) => {
                  const bad = hasIssues(page);
                  const isSelected = selectedId === page.id;
                  const approved = page.isRescanApproved;
                  
                  // Compute original sheet order
                  const originalIdx = scannedPages.findIndex(p => p.id === page.id);

                  return (
                    <button
                      key={page.id}
                      onClick={() => setSelectedId(page.id)}
                      className={`w-full p-3 rounded-2xl border text-left transition-all duration-200 flex items-center justify-between gap-2 cursor-pointer ${
                        isSelected
                          ? "bg-rose-50/60 border-rose-500 ring-1 ring-rose-500 shadow-2xs"
                          : bad
                          ? "bg-red-50/40 border-red-200 hover:bg-red-50/60"
                          : approved
                          ? "bg-emerald-50/30 border-emerald-200 hover:bg-emerald-50/50"
                          : "bg-amber-50/40 border-amber-200 hover:bg-amber-50/60"
                      }`}
                      id={`rescan-item-${page.id}`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold font-mono ${
                          bad ? 'bg-red-100 text-red-800' : approved ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {originalIdx + 1}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-stone-900 truncate">
                            N° {page.numActe} — {page.typeActe}
                          </div>
                          <div className="text-[9.5px] text-stone-500 font-mono uppercase tracking-wider mt-0.5 truncate flex items-center gap-1.5">
                            <span>{page.filename}</span>
                          </div>
                        </div>
                      </div>

                      <div className="shrink-0">
                        {bad ? (
                          <span className="text-[8px] bg-red-100 text-red-700 font-bold px-1.5 py-0.5 rounded-full border border-red-200 flex items-center gap-1 uppercase tracking-tight">
                            <AlertTriangle className="w-2.5 h-2.5 text-red-600 animate-pulse" />
                            Rejeté
                          </span>
                        ) : approved ? (
                          <span className="text-[8px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-0.5 uppercase tracking-tight">
                            <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" />
                            Approuvé
                          </span>
                        ) : (
                          <span className="text-[8px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded-full border border-amber-200 flex items-center gap-0.5 uppercase tracking-tight">
                            <RefreshCw className="w-2.5 h-2.5 text-amber-600 animate-spin" style={{ animationDuration: '3s' }} />
                            Contrôle
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-stone-150 mt-4">
            <div className="bg-stone-50 p-3 rounded-2xl border border-stone-150 space-y-2 text-[10px] text-stone-600 font-medium">
              <div className="font-bold text-stone-850">Légende de conformité :</div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0" />
                <span>Rejeté : Flou détecté ou pliure Twya (attente re-scan)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0 animate-pulse" />
                <span>Contrôle : Image re-capturée, en attente d'évaluation de qualité</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                <span>Approuvé : Qualité certifiée conforme</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Active Capture & Quality Control Area */}
        <div className="lg:col-span-8 bg-white border border-stone-200 p-6 rounded-3xl space-y-6 flex flex-col justify-between">
          {selectedPage ? (
            <div className="space-y-6">
              
              {/* Header metadata */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-stone-150 gap-2">
                <div>
                  <h4 className="text-[10px] text-rose-800 uppercase font-bold tracking-wider">Atelier de Saisie Corrective</h4>
                  <div className="text-base font-black text-stone-900 mt-0.5">
                    Acte N° {selectedPage.numActe} ({selectedPage.typeActe}) — Registre {selectedPage.numBEC}
                  </div>
                </div>
                <div className="text-[10px] bg-stone-100 text-stone-600 px-2.5 py-1 rounded-xl font-mono">
                  Code Page: {selectedPage.id}
                </div>
              </div>

              {/* Grid Layout depending on whether the page has been rescanned */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* LEFT: Current Image View with live CSS filters for interactive control */}
                <div className="space-y-3">
                  <div className="text-[11px] font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5 text-stone-500" />
                      Visualisation d'Image
                    </span>
                    {selectedPage.wasRescanned && (
                      <span className="text-[9px] text-emerald-700 bg-emerald-50 border border-emerald-200 font-bold px-2 py-0.5 rounded-md uppercase">
                        Nouvel Image Re-capturée
                      </span>
                    )}
                  </div>
                  
                  <div className="relative border border-stone-200 bg-stone-50 rounded-2xl overflow-hidden aspect-4/3 flex items-center justify-center p-2 group shadow-2xs">
                    {selectedPage.customPreview ? (
                      <img 
                        src={selectedPage.customPreview} 
                        alt="Aperçu d'acte civil" 
                        style={{
                          filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${sharpness}%)`,
                          transition: 'filter 0.15s ease-out'
                        }}
                        className={`w-full h-full object-contain rounded-xl ${
                          hasIssues(selectedPage) ? 'blur-[1.5px]' : ''
                        }`}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-stone-300 flex flex-col items-center gap-2">
                        <Camera className="w-12 h-12 stroke-1" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Aucun scan physique chargé</span>
                      </div>
                    )}

                    {/* Badge alert overlay for still-rejected acts */}
                    {hasIssues(selectedPage) && (
                      <div className="absolute inset-x-0 bottom-0 bg-red-900/90 text-white p-3 backdrop-blur-xs flex flex-col gap-1 z-10">
                        <span className="text-[9.5px] font-bold uppercase tracking-wider flex items-center gap-1 text-red-200">
                          <AlertTriangle className="w-3 h-3 text-red-400 animate-pulse" /> Anomalie physique bloquante :
                        </span>
                        <div className="flex flex-wrap gap-1 mt-0.5">
                          {selectedPage.isBlurred && (
                            <span className="text-[8.5px] bg-red-800 text-red-100 px-2 py-0.5 rounded-md font-bold uppercase border border-red-700">Image Floue</span>
                          )}
                          {selectedPage.isFoldedText && (
                            <span className="text-[8.5px] bg-red-800 text-red-100 px-2 py-0.5 rounded-md font-bold uppercase border border-red-700">Texte plié / Twya</span>
                          )}
                          {selectedPage.isStrikethrough && (
                            <span className="text-[8.5px] bg-red-800 text-red-100 px-2 py-0.5 rounded-md font-bold uppercase border border-red-700">Acte Barré / Rayé</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Mock Image adjustment sliders for interactive control */}
                  {selectedPage.wasRescanned && (
                    <div className="bg-stone-50 border border-stone-200 p-3 rounded-2xl space-y-2.5 font-mono text-[9px] text-stone-700">
                      <div className="font-bold flex items-center gap-1 text-stone-900 uppercase text-[9.5px]">
                        <Sliders className="w-3 h-3 text-rose-800" /> Ajustements d'Image (Contrôle) :
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span>Luminosité :</span>
                          <span className="font-bold">{brightness}%</span>
                        </div>
                        <input 
                          type="range" min="50" max="150" value={brightness} 
                          onChange={(e) => setBrightness(Number(e.target.value))}
                          className="w-full accent-rose-700 h-1 bg-stone-200 rounded-lg cursor-pointer"
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span>Contraste :</span>
                          <span className="font-bold">{contrast}%</span>
                        </div>
                        <input 
                          type="range" min="50" max="150" value={contrast} 
                          onChange={(e) => setContrast(Number(e.target.value))}
                          className="w-full accent-rose-700 h-1 bg-stone-200 rounded-lg cursor-pointer"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* RIGHT: Dynamic Panel - Camera if bad, Quality Control checklist if rescanned */}
                <div className="space-y-4">
                  {!selectedPage.wasRescanned ? (
                    // Camera capture workspace
                    <div className="space-y-3">
                      <div className="text-[11px] font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1">
                        <Camera className="w-3.5 h-3.5 text-blue-500" />
                        Simulateur Caméra Zénithale Fès
                      </div>

                      <div className="relative border-2 border-dashed border-stone-300 bg-stone-950 rounded-2xl overflow-hidden aspect-4/3 flex flex-col items-center justify-center p-4">
                        <div className="absolute inset-0 opacity-15 pointer-events-none z-0">
                          <div className="w-full h-[2px] bg-green-500 absolute top-1/3 left-0 animate-pulse-glow" style={{ animation: 'bounce 4s infinite' }}></div>
                          <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>
                        </div>

                        {isShutterFlashing && (
                          <div className="absolute inset-0 bg-white z-40 animate-fade-in flex items-center justify-center">
                            <div className="text-stone-900 font-bold uppercase text-xs tracking-widest font-mono">DECLENCHEMENT OBTURATEUR...</div>
                          </div>
                        )}

                        <div className="text-center space-y-3 relative z-10 text-stone-200">
                          <div className="w-11 h-11 bg-stone-900/85 border border-stone-800 text-rose-500 rounded-full flex items-center justify-center mx-auto shadow-md animate-pulse">
                            <Camera className="w-5 h-5" />
                          </div>
                          <div className="space-y-1">
                            <h5 className="text-xs font-black text-stone-100 tracking-wide uppercase">Visée Zénithale alignée</h5>
                            <p className="text-[9.5px] text-stone-400 max-w-[200px] mx-auto leading-relaxed">
                              Positionnez correctement la page physique sans pliure sous l'objectif de numérisation.
                            </p>
                          </div>

                          <div className="pt-2 flex flex-col gap-2 items-center">
                            <button
                              type="button"
                              onClick={handleSimulateCapture}
                              className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white text-[10px] font-bold uppercase rounded-xl transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                            >
                              <RefreshCw className="w-3.5 h-3.5 text-rose-200" /> Capturer & Remplacer
                            </button>
                            
                            <div className="text-stone-500 text-[8.5px] uppercase font-mono font-bold">OU IMPORTER :</div>

                            <label className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-[9.5px] font-bold rounded-lg border border-stone-700 flex items-center gap-1 cursor-pointer transition-colors">
                              <Upload className="w-3 h-3 text-stone-400" />
                              Choisir scan JPEG/PNG
                              <input 
                                type="file" 
                                accept="image/*" 
                                onChange={handleFileUpload} 
                                className="hidden" 
                              />
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    // Dedicated quality control for just this rescanned page
                    <div className="bg-amber-50/40 border border-amber-200 rounded-2xl p-4 space-y-4">
                      <div className="flex items-center gap-2 border-b border-amber-100 pb-2">
                        <div className="w-7 h-7 rounded-full bg-amber-500 flex items-center justify-center text-white font-bold text-xs">
                          🔎
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-amber-950 uppercase">CONTRÔLE D'IMAGE RE-SCANNÉE</h4>
                          <p className="text-[9px] text-amber-800 font-medium font-sans">
                            Évaluez la nouvelle capture de l'acte avant validation réglementaire.
                          </p>
                        </div>
                      </div>

                      {/* Control Checkmarks Checklist */}
                      <div className="space-y-2.5">
                        <div className="text-[9.5px] font-mono font-bold text-stone-500 uppercase">
                          Critères de conformité physique :
                        </div>

                        <label className="flex items-start gap-2.5 p-2 bg-white rounded-xl border border-stone-200/60 hover:bg-stone-50 cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            checked={checklistNettete}
                            onChange={(e) => setChecklistNettete(e.target.checked)}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-stone-300 mt-0.5"
                          />
                          <div>
                            <span className="text-[10.5px] font-bold text-stone-850 block">Netteté d'écriture</span>
                            <span className="text-[9px] text-stone-500 font-sans block leading-normal">L'écriture manuscrite arabe est parfaitement nette et lisible par l'IA.</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-2.5 p-2 bg-white rounded-xl border border-stone-200/60 hover:bg-stone-50 cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            checked={checklistCadrage}
                            onChange={(e) => setChecklistCadrage(e.target.checked)}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-stone-300 mt-0.5"
                          />
                          <div>
                            <span className="text-[10.5px] font-bold text-stone-850 block">Cadrage & Alignement</span>
                            <span className="text-[9px] text-stone-500 font-sans block leading-normal">Aucune pliure Twya n'empiète sur le texte d'acte. La page est plane.</span>
                          </div>
                        </label>

                        <label className="flex items-start gap-2.5 p-2 bg-white rounded-xl border border-stone-200/60 hover:bg-stone-50 cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            checked={checklistLisibilite}
                            onChange={(e) => setChecklistLisibilite(e.target.checked)}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-stone-300 mt-0.5"
                          />
                          <div>
                            <span className="text-[10.5px] font-bold text-stone-850 block">Absence d'anomalies de cadrage</span>
                            <span className="text-[9px] text-stone-500 font-sans block leading-normal">Les mentions marginales et le sceau originel sont entièrement visibles.</span>
                          </div>
                        </label>
                      </div>

                      {/* Approval buttons */}
                      <div className="pt-3 border-t border-amber-100 flex gap-2">
                        <button
                          type="button"
                          onClick={handleApproveRescan}
                          disabled={!(checklistNettete && checklistCadrage && checklistLisibilite)}
                          className={`flex-1 py-2 rounded-xl text-[10.5px] font-bold uppercase flex items-center justify-center gap-1 shadow-2xs ${
                            (checklistNettete && checklistCadrage && checklistLisibilite)
                              ? "bg-green-700 hover:bg-green-800 text-white cursor-pointer"
                              : "bg-stone-200 text-stone-400 border border-stone-300 cursor-not-allowed"
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          Approuver l'image ✔
                        </button>
                        
                        <button
                          type="button"
                          onClick={handleRejectRescan}
                          className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold border border-red-200 rounded-xl text-[10.5px] uppercase flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Rejeter
                        </button>
                      </div>
                    </div>
                  )}
                </div>

              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-stone-400 select-none">
              <Camera className="w-16 h-16 stroke-1 mb-2 animate-bounce text-stone-350" />
              <div className="text-xs font-bold uppercase text-stone-650">Tout est en ordre</div>
              <p className="text-[10.5px] text-stone-400 max-w-xs mt-1">
                Tous les actes défectueux ont été re-scannés et contrôlés avec succès !
              </p>
            </div>
          )}

          {/* Action validation footer */}
          <div className="pt-4 border-t border-stone-150 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-center sm:text-left">
              {rejectedCount > 0 ? (
                <div className="text-[10.5px] text-red-700 font-bold flex items-center gap-1.5 bg-red-50 border border-red-150 px-3 py-1.5 rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-red-600 animate-pulse" />
                  <span>Il reste {rejectedCount} acte(s) à re-scanner avec la caméra zénithale.</span>
                </div>
              ) : pendingApprovalCount > 0 ? (
                <div className="text-[10.5px] text-amber-800 font-bold flex items-center gap-1.5 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-amber-600 animate-pulse" />
                  <span>Il reste {pendingApprovalCount} acte(s) corrigés à évaluer au contrôle d'image.</span>
                </div>
              ) : (
                <div className="text-[10.5px] text-emerald-800 font-bold flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Tous les actes défectueux ont été ré-capturés, contrôlés et validés conformes !</span>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={onValidate}
              disabled={rejectedCount > 0 || pendingApprovalCount > 0}
              className={`px-5 py-3 rounded-2xl text-xs font-bold uppercase transition-all flex items-center gap-1.5 shadow-sm ${
                (rejectedCount === 0 && pendingApprovalCount === 0)
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer hover:shadow-lg"
                  : "bg-stone-100 text-stone-400 border border-stone-200 cursor-not-allowed"
              }`}
            >
              Passer à l'Étape 3 (Identification d'Actes)
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
